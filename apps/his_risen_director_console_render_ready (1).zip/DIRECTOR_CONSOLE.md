# HIS RISEN Director Console

This is the private, mobile-first Director interface for the HIS RISEN Controller.

## Current safe mode

The Render deployment currently uses the **MockComfyUIAdapter**. Mock Mode never calls RunPod, ComfyUI, LTX-2.5, or another external generation service.

Use **RUN ONE MOCK SHOT** to exercise the controller lifecycle safely. The test fixture is an 8-second 1440p/16:9/24fps request and returns a tiny bundled MP4 so Director review, browser playback, approval, rejection, regeneration, export, and film-readiness can all be exercised end-to-end.

Repeated clicks while a mock job is active reuse the active test instead of creating duplicate jobs.

## Director lifecycle

```text
RUN ONE MOCK SHOT
    -> SUBMITTED
    -> RUNNING (25% / 75%)
    -> COMPLETED (100%)
    -> Director reviews video
    -> APPROVE -> VERIFIED EXPORT
       or
    -> REJECT -> REGENERATE -> new child take
```

Creative approval is never automatic.

## First/Last Frame

The console displays the selected `generation_mode` and frame-conditioning descriptions when those fields exist in a completed take. The controller supports:

- `AUTO`
- `TEXT_TO_VIDEO`
- `IMAGE_TO_VIDEO`
- `FIRST_FRAME`
- `FIRST_LAST_FRAME`
- `EXTENSION`

Frame conditioning remains specialist-only. The controller never invents or silently substitutes frame assets. Real frame-conditioned execution stays disabled until the actual approved ComfyUI/LTX workflow files are installed and marked `ready=true`.

## Security

- PIN is read from `HRF_DIRECTOR_PIN`; it is not stored in source code.
- Authenticated sessions use an HttpOnly, SameSite=Strict cookie and Secure is enabled behind HTTPS.
- Failed logins are rate limited.
- State-changing requests reject cross-origin `Origin` values that do not match the console host.
- Request bodies are capped at 256 KiB.
- Video preview is available for a completed take so the Director can review before approval; local file paths are constrained to the project root.
- Approved output preview prefers verified exported files.
- ComfyUI should not be exposed directly to the public internet.

## Natural-language command box

The Director Command box is intentionally **not executable yet**. It is reserved for the future AI-agent/MCP bridge. Text entered there is not forwarded to the controller.

## Local mock run

```bash
export HRF_DIRECTOR_PIN=12345678
python director_console.py --host 127.0.0.1 --port 8080 --backend mock
```

Open `http://127.0.0.1:8080`.

## Real backend boundary

The controller has a separate ComfyUI adapter with REST/HTTP and WebSocket monitoring support. Real workflow graphs are selected only through registered presets. The current workflow files are still contract fixtures and remain `ready=false`, so the Render console must stay in Mock Mode until the approved LTX-2.5 ComfyUI workflow is installed and tested.
