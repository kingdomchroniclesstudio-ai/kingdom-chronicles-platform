from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import tempfile
import urllib.request
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Protocol


class OutputRetriever(Protocol):
    def retrieve(self, media: dict[str, Any], destination: Path) -> dict[str, Any]: ...


class ExportError(RuntimeError):
    pass


@dataclass(frozen=True)
class ExportResult:
    export_id: str
    take_id: str
    status: str
    path: str | None
    filename: str | None
    bytes: int
    sha256: str | None
    kind: str | None
    message: str | None = None


_SAFE = re.compile(r"[^A-Za-z0-9._-]+")


def safe_part(value: str) -> str:
    cleaned = _SAFE.sub("_", str(value)).strip("._")
    return cleaned or "unknown"


class FileOutputRetriever:
    """Retrieves media from a local source_path or an HTTP URL."""

    def retrieve(self, media: dict[str, Any], destination: Path) -> dict[str, Any]:
        source_path = media.get("source_path")
        url = media.get("url")
        destination.parent.mkdir(parents=True, exist_ok=True)
        if source_path:
            src = Path(source_path).resolve()
            if not src.is_file():
                raise ExportError(f"output source file does not exist: {src}")
            shutil.copyfile(src, destination)
        elif url:
            try:
                with urllib.request.urlopen(str(url), timeout=120) as response, destination.open("wb") as out:
                    shutil.copyfileobj(response, out)
            except Exception as exc:
                destination.unlink(missing_ok=True)
                raise ExportError(f"failed to retrieve output from {url}: {exc}") from exc
        else:
            raise ExportError("media descriptor has neither source_path nor url")
        size = destination.stat().st_size
        digest = sha256_file(destination)
        return {"path": str(destination), "bytes": size, "sha256": digest}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


class ApprovedOutputExportManager:
    """Find -> retrieve -> save -> verify -> register approved media."""

    def __init__(self, root: Path, store: Any, retriever: OutputRetriever, workspace_root: Path | None = None):
        self.root = root.resolve()
        self.store = store
        self.retriever = retriever
        self.workspace_root = (workspace_root or (self.root / "outputs" / "production")).resolve()
        self.workspace_root.mkdir(parents=True, exist_ok=True)

    def _destination(self, take: dict[str, Any], media: dict[str, Any], index: int) -> Path:
        film = safe_part(take["film_id"])
        scene = safe_part(take["scene_id"])
        shot = safe_part(take["shot_id"])
        take_id = safe_part(take["take_id"])
        original = safe_part(Path(str(media.get("filename") or f"output_{index:03d}.bin")).name)
        stem = Path(original).stem or f"output_{index:03d}"
        suffix = Path(original).suffix or ".bin"
        filename = f"{shot}_{take_id}_{index:02d}{suffix}"
        return self.workspace_root / film / scene / shot / take_id / filename

    def export_take(self, take_id: str, *, allow_status: tuple[str, ...] = ("APPROVED",)) -> list[dict[str, Any]]:
        take = self.store.get_take(take_id)
        if take["status"] not in allow_status:
            raise ExportError(f"take {take_id} must be APPROVED before export; current status is {take['status']}")
        metadata = take.get("output_metadata") or {}
        media = metadata.get("media_files") if isinstance(metadata, dict) else None
        if not isinstance(media, list) or not media:
            result = ExportResult(take_id + ":NO_MEDIA", take_id, "SKIPPED_NO_MEDIA", None, None, 0, None, None, "No media files were reported by the generation adapter.")
            self.store.record_export(asdict(result))
            return [asdict(result)]

        results: list[dict[str, Any]] = []
        for index, item in enumerate(media, start=1):
            if not isinstance(item, dict):
                continue
            kind = item.get("kind") if isinstance(item.get("kind"), str) else None
            if kind != "video":
                continue
            destination = self._destination(take, item, index)
            existing = self.store.find_export(take_id, index)
            if existing and existing.get("status") == "VERIFIED" and existing.get("path"):
                path = Path(existing["path"])
                if path.is_file() and sha256_file(path) == existing.get("sha256"):
                    results.append(existing)
                    continue
            export_id = f"{take_id}:VIDEO:{index:02d}"
            self.store.record_export({"export_id": export_id, "take_id": take_id, "media_index": index, "kind": kind, "status": "RETRIEVING", "path": str(destination), "filename": destination.name, "bytes": 0, "sha256": None, "message": None})
            try:
                retrieved = self.retriever.retrieve(item, destination)
                if not destination.is_file() or destination.stat().st_size <= 0:
                    raise ExportError("retrieved output is missing or empty")
                verified_hash = sha256_file(destination)
                if verified_hash != retrieved["sha256"]:
                    raise ExportError("output checksum changed during verification")
                result = ExportResult(export_id, take_id, "VERIFIED", str(destination), destination.name, destination.stat().st_size, verified_hash, kind, "Approved output retrieved and verified.")
                self.store.record_export({**asdict(result), "media_index": index})
                results.append(asdict(result))
            except Exception as exc:
                destination.unlink(missing_ok=True)
                self.store.record_export({"export_id": export_id, "take_id": take_id, "media_index": index, "kind": kind, "status": "FAILED", "path": None, "filename": destination.name, "bytes": 0, "sha256": None, "message": f"{type(exc).__name__}: {exc}"})
                raise
        if not results:
            result = ExportResult(take_id + ":NO_VIDEO", take_id, "SKIPPED_NO_VIDEO", None, None, 0, None, None, "Generation completed without a video media file.")
            self.store.record_export({**asdict(result), "media_index": 0})
            results.append(asdict(result))
        return results

    def status(self, take_id: str) -> list[dict[str, Any]]:
        return self.store.export_records(take_id)

    def film_readiness(self, film_id: str) -> dict[str, Any]:
        takes = self.store.film_takes(film_id)
        approved = [t for t in takes if t["status"] == "APPROVED"]
        pending = [t for t in takes if t["status"] in {"PENDING", "SUBMITTED", "RUNNING", "COMPLETED"}]
        rejected = [t for t in takes if t["status"] == "REJECTED"]
        failed = [t for t in takes if t["status"] == "FAILED"]
        exports = self.store.film_exports(film_id)
        verified_take_ids = {e["take_id"] for e in exports if e.get("status") == "VERIFIED"}
        missing_exports = [t["take_id"] for t in approved if t["take_id"] not in verified_take_ids]
        return {
            "film_id": film_id,
            "takes_total": len(takes),
            "approved": len(approved),
            "pending_or_review": len(pending),
            "rejected": len(rejected),
            "failed": len(failed),
            "approved_with_verified_export": len([t for t in approved if t["take_id"] in verified_take_ids]),
            "missing_approved_exports": missing_exports,
            "ready_for_editing": bool(approved) and not pending and not failed and not missing_exports,
            "exports": exports,
        }
