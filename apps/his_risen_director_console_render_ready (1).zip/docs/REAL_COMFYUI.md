# Real ComfyUI Connection Checklist

The real adapter is already implemented. It is intentionally gated from accidental use until real workflow files are installed.

## What is required outside the controller

1. A reachable ComfyUI instance on RunPod.
2. LTX-2.5 model files and required custom nodes/components installed in that ComfyUI instance.
3. One or more exported ComfyUI API-format workflow JSON files matching the installed LTX-2.5 workflows.
4. A mapping file for each workflow describing which ComfyUI node/input receives the controller's prompt, duration, input image, continuation source, seed, or other approved values.
5. Set `ready: true` for a verified workflow preset in `workflows/real_presets.json`.
6. Set the ComfyUI base URL in `config/runtime.json` (or pass the backend explicitly).
7. Run one real end-to-end shot and validate the actual output.

## Controller-side behavior already implemented

- HTTP `/prompt` queueing
- `/history/{prompt_id}` lookup
- `/view` output URLs
- `/upload/image` input-file upload
- `/system_stats` connectivity check
- WebSocket monitoring at `/ws?clientId=...`
- normalized output discovery
- timeout and connection/protocol error classes
- explicit workflow loading and mapping
- I2V/reference asset upload path
- real-adapter readiness gate

The actual LTX workflow graph and its node/input IDs cannot be invented before the installed workflow is available. Once supplied, they are configuration artifacts rather than a controller redesign.
