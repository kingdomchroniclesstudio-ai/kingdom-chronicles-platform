# HIS RISEN Controller Interface

## Console-only mock test

`POST /api/mock-test` is a protected Director Console endpoint. It creates one fixed 8-second mock shot and never accepts arbitrary generation parameters. It is available only while the backend adapter is `MockComfyUIAdapter`.

## Local REST API

Start the controller API with:

    python3 serve.py --port 8189

### Generate a shot

`POST /shots/generate`

Body:

```json
{"specification": {"...": "approved shot specification"}}
```

### Inspect a take

`GET /takes/{take_id}`

### Poll progress

`POST /takes/{take_id}/advance`

### Read progress history

`GET /takes/{take_id}/progress`

### Director review

`POST /takes/{take_id}/approve`

or

`POST /takes/{take_id}/reject`

with:

```json
{"reason": "Director's reason"}
```

### Regenerate

`POST /takes/{take_id}/regenerate`

The controller preserves the original snapshot and creates a new child take.

## First/Last Frame conditioning (specialist capability)

The controller supports explicit frame-conditioning modes without making them the default.

- `generation_mode`: `AUTO`, `TEXT_TO_VIDEO`, `IMAGE_TO_VIDEO`, `FIRST_FRAME`, `FIRST_LAST_FRAME`, or `EXTENSION`.
- `frame_conditioning.first_frame`: required for `FIRST_FRAME` and `FIRST_LAST_FRAME`.
- `frame_conditioning.last_frame`: additionally required for `FIRST_LAST_FRAME`.
- Each frame object requires an approved `description` and may include an explicit `asset_id` for an existing image reference.
- `IMAGE_TO_VIDEO` requires an explicit `input_image`.
- Frame-conditioning and image-to-video modes are restricted to `SINGLE-SHOT`.
- The controller never creates, selects, or silently substitutes frame assets merely because a shot might benefit from them.
- `POST /shots/recommend-generation` returns a recommendation only. It never queues a job and explicitly reports that Director authorization is required.
- Real first/last-frame execution remains disabled until the approved ComfyUI/LTX workflow files and mappings are installed and marked `ready=true` in `workflows/real_presets.json`.
