# HIS RISEN Controller MCP Bridge

The MCP bridge is a thin AI-facing command surface over the HIS RISEN Controller. It does **not** bypass the controller and it does **not** command ComfyUI directly.

## Architecture

`AI production manager -> MCP -> HIS RISEN Controller -> generation adapter -> ComfyUI -> LTX`

The MCP bridge exposes:

- `controller_health`
- `generate_shot`
- `advance_generation`
- `get_take`
- `get_take_progress`
- `approve_take`
- `reject_take`
- `regenerate_take`
- `export_approved_take`
- `film_readiness`

Director approval remains an explicit operation. Approved export can be triggered from approval by the controller policy or by the dedicated export tool.

## HTTP endpoint

The bridge exposes a stateless JSON MCP endpoint at:

`POST /mcp`

Default bind:

`http://127.0.0.1:8190/mcp`

The server supports the current MCP 2026-07-28 discovery flow and the 2025-11-25 initialize flow for backward compatibility.

## Start locally

```bash
python mcp_server.py --root . --host 127.0.0.1 --port 8190 --backend mock
```

For a real ComfyUI deployment:

```bash
python mcp_server.py --root . --host 0.0.0.0 --port 8190 --backend comfyui
```

Set `HRF_MCP_BEARER_TOKEN` before exposing the service remotely. For production, use HTTPS and preferably an OAuth 2.1 resource-server setup or a trusted secure gateway rather than an ad-hoc token.

## ChatGPT / OpenAI connection

The MCP endpoint must be remotely reachable by the MCP host. OpenAI's current API supports remote MCP servers using Streamable HTTP, and ChatGPT custom MCP apps support remote endpoints in supported plans/workspaces. The exact connection/authentication UI depends on the OpenAI product and account plan.

This package therefore provides the server endpoint and tool definitions now; the final ChatGPT registration/authentication step is deployment configuration, not ComfyUI code.
