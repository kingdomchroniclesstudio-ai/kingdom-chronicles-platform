from __future__ import annotations

import copy
import uuid
from pathlib import Path
from typing import Any

from adapters.base import GenerationUpdate

MOCK_NOTICE = "MOCK OUTPUT — NO REAL LTX GENERATION PERFORMED"


class MockComfyUI:
    """Deterministic in-process mock of the generation backend.

    It intentionally never calls RunPod, ComfyUI, LTX, or any external service.
    A tiny bundled MP4 is returned as mock media so the full review/export/preview
    lifecycle can be exercised safely.
    """

    def __init__(self, root: Path):
        self.root = root.resolve()
        self._jobs: dict[str, dict[str, Any]] = {}

    def submit(self, request: dict[str, Any], client_request_id: str) -> str:
        job_id = "mock-" + uuid.uuid5(
            uuid.NAMESPACE_URL, "his-risen-films:" + client_request_id
        ).hex
        existing = self._jobs.get(job_id)
        if existing is not None:
            if existing["request"] != request:
                raise ValueError("Mock submission ID reused with another request.")
            return job_id
        self._jobs[job_id] = {"request": copy.deepcopy(request), "step": 0}
        return job_id

    def poll(self, job_id: str) -> GenerationUpdate:
        if job_id not in self._jobs:
            raise LookupError(
                "Mock job unavailable in this process. Mock jobs do not survive "
                "adapter restarts; persisted take records remain in SQLite."
            )

        job = self._jobs[job_id]
        job["step"] = min(job["step"] + 1, 3)
        progress = (25, 75, 100)[job["step"] - 1]
        if progress < 100:
            return GenerationUpdate(state="RUNNING", progress=progress)

        request = job["request"]
        mock_video = self.root / "refs" / "mock_test.mp4"
        media_files: list[dict[str, Any]] = []
        media_generated = False
        if mock_video.is_file():
            media_files.append(
                {
                    "kind": "video",
                    "filename": "mock_test.mp4",
                    "source_path": str(mock_video),
                    "mime_type": "video/mp4",
                }
            )
            media_generated = True

        return GenerationUpdate(
            state="COMPLETED",
            progress=100,
            output_metadata={
                "notice": MOCK_NOTICE,
                "is_mock": True,
                "media_generated": media_generated,
                "media_files": media_files,
                "job_id": job_id,
                "preset_id": request["workflow"]["preset_id"],
                "requested_duration_seconds": request["specification"]["duration"],
            },
        )
