from __future__ import annotations

import argparse
import json
import os
import secrets
import threading
import uuid
from dataclasses import asdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlparse

from config.bootstrap import build_controller
from models.specification import ValidationError

SERVER_NAME = "HIS RISEN Controller MCP"
SERVER_VERSION = "0.3.0"
MODERN_PROTOCOL = "2026-07-28"
LEGACY_PROTOCOL = "2025-11-25"


def _json_schema_tool_defs() -> list[dict[str, Any]]:
    return [
        {
            "name": "controller_health",
            "title": "Controller health",
            "description": "Read the HIS RISEN controller health and backend readiness state. Use before production operations when you need to verify that the controller is reachable and configured.",
            "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
            "annotations": {"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        },
        {
            "name": "generate_shot",
            "title": "Generate shot",
            "description": "Submit one approved HIS RISEN shot specification to the controller for generation. The specification must contain the complete creative and technical shot requirements, including resolution, duration, shot type, characters, environment, action, camera, lighting, audio, continuity, and any required assets. This tool never approves creative output.",
            "inputSchema": {
                "type": "object",
                "properties": {"specification": {"type": "object", "description": "Complete validated HIS RISEN shot specification."}},
                "required": ["specification"],
                "additionalProperties": False,
            },
            "annotations": {"readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": False},
        },
        {
            "name": "advance_generation",
            "title": "Advance generation",
            "description": "Poll exactly one submitted or running take once and return its current status, progress, job ID, and output metadata when completed.",
            "inputSchema": {
                "type": "object",
                "properties": {"take_id": {"type": "string", "description": "HIS RISEN take ID."}},
                "required": ["take_id"],
                "additionalProperties": False,
            },
            "annotations": {"readOnlyHint": False, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        },
        {
            "name": "get_take",
            "title": "Get take",
            "description": "Read the complete stored state of a HIS RISEN take, including the immutable generation snapshot and output metadata.",
            "inputSchema": {
                "type": "object",
                "properties": {"take_id": {"type": "string", "description": "HIS RISEN take ID."}},
                "required": ["take_id"],
                "additionalProperties": False,
            },
            "annotations": {"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        },
        {
            "name": "get_take_progress",
            "title": "Get take progress",
            "description": "Read the persisted progress-event history for one HIS RISEN take.",
            "inputSchema": {
                "type": "object",
                "properties": {"take_id": {"type": "string", "description": "HIS RISEN take ID."}},
                "required": ["take_id"],
                "additionalProperties": False,
            },
            "annotations": {"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        },
        {
            "name": "approve_take",
            "title": "Approve take",
            "description": "Record the Director's explicit approval of a completed take. Approval never happens automatically. When auto_export is true, the controller immediately retrieves and verifies the approved output through the configured export manager.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "take_id": {"type": "string", "description": "HIS RISEN take ID."},
                    "auto_export": {"type": "boolean", "description": "Override the controller's approval-export policy for this approval. Omit to use the configured policy."},
                },
                "required": ["take_id"],
                "additionalProperties": False,
            },
            "annotations": {"readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": False},
        },
        {
            "name": "reject_take",
            "title": "Reject take",
            "description": "Record the Director's explicit rejection of a completed take. A non-empty rejection reason is required and is preserved for regeneration history.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "take_id": {"type": "string", "description": "HIS RISEN take ID."},
                    "reason": {"type": "string", "description": "Director's rejection reason."},
                },
                "required": ["take_id", "reason"],
                "additionalProperties": False,
            },
            "annotations": {"readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": False},
        },
        {
            "name": "regenerate_take",
            "title": "Regenerate take",
            "description": "Create a new take from a rejected parent while preserving the original immutable generation snapshot and parent/rejection history. The parent must already be REJECTED.",
            "inputSchema": {
                "type": "object",
                "properties": {"rejected_take_id": {"type": "string", "description": "Rejected HIS RISEN take ID."}},
                "required": ["rejected_take_id"],
                "additionalProperties": False,
            },
            "annotations": {"readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": False},
        },
        {
            "name": "export_approved_take",
            "title": "Export approved take",
            "description": "Retrieve and verify the video output for an APPROVED take and place it into the configured HIS RISEN production workspace. Repeating the operation is safe and does not duplicate an already verified export.",
            "inputSchema": {
                "type": "object",
                "properties": {"take_id": {"type": "string", "description": "APPROVED HIS RISEN take ID."}},
                "required": ["take_id"],
                "additionalProperties": False,
            },
            "annotations": {"readOnlyHint": False, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        },
        {
            "name": "film_readiness",
            "title": "Film readiness",
            "description": "Inspect a film's persisted take and approved-export state and report whether its approved outputs are ready for editing.",
            "inputSchema": {
                "type": "object",
                "properties": {"film_id": {"type": "string", "description": "HIS RISEN film ID."}},
                "required": ["film_id"],
                "additionalProperties": False,
            },
            "annotations": {"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        },
    ]


class MCPToolError(RuntimeError):
    pass


class StaticBearerAuth:
    """Optional simple bearer-token gate for the remote MCP endpoint.

    For production deployments, prefer OAuth 2.1 or a trusted access gateway.
    """

    def __init__(self, token: str | None):
        self.token = token.strip() if token else None

    def check(self, headers: dict[str, str]) -> bool:
        if not self.token:
            return True
        value = headers.get("Authorization", "")
        if not value.lower().startswith("bearer "):
            return False
        presented = value[7:].strip()
        return bool(presented) and secrets.compare_digest(presented, self.token)


class HISRisENMCP:
    def __init__(self, controller: Any):
        self.controller = controller
        self.tools = _json_schema_tool_defs()
        self._handlers: dict[str, Callable[[dict[str, Any]], Any]] = {
            "controller_health": self._controller_health,
            "generate_shot": self._generate_shot,
            "advance_generation": self._advance_generation,
            "get_take": self._get_take,
            "get_take_progress": self._get_take_progress,
            "approve_take": self._approve_take,
            "reject_take": self._reject_take,
            "regenerate_take": self._regenerate_take,
            "export_approved_take": self._export_approved_take,
            "film_readiness": self._film_readiness,
        }

    def _require_keys(self, args: dict[str, Any], required: set[str]) -> None:
        if not isinstance(args, dict):
            raise MCPToolError("tool arguments must be an object")
        missing = required - set(args)
        unexpected = set(args) - next((set(t["inputSchema"]["properties"]) for t in self.tools if t["name"] == "__none__"), set())
        if missing:
            raise MCPToolError(f"missing required arguments: {', '.join(sorted(missing))}")

    @staticmethod
    def _take_id(args: dict[str, Any]) -> str:
        value = args.get("take_id")
        if not isinstance(value, str) or not value.strip():
            raise MCPToolError("take_id must be a non-empty string")
        return value.strip()

    def _controller_health(self, args: dict[str, Any]) -> dict[str, Any]:
        backend = type(self.controller.adapter).__name__
        is_mock = backend == "MockComfyUIAdapter"
        return {
            "service": "his-risen-controller",
            "mcp_server": SERVER_NAME,
            "status": "ok",
            "backend_adapter": backend,
            "real_generation_enabled": not is_mock,
            "approval_required": True,
            "automatic_approved_export_supported": self.controller.export_manager is not None,
        }

    def _generate_shot(self, args: dict[str, Any]) -> dict[str, Any]:
        spec = args.get("specification")
        if not isinstance(spec, dict):
            raise MCPToolError("specification must be an object")
        return self.controller.generate(spec)

    def _advance_generation(self, args: dict[str, Any]) -> dict[str, Any]:
        return self.controller.advance(self._take_id(args))

    def _get_take(self, args: dict[str, Any]) -> dict[str, Any]:
        return self.controller.get_take(self._take_id(args))

    def _get_take_progress(self, args: dict[str, Any]) -> list[dict[str, Any]]:
        return self.controller.get_progress_events(self._take_id(args))

    def _approve_take(self, args: dict[str, Any]) -> dict[str, Any]:
        take_id = self._take_id(args)
        auto_export = args.get("auto_export")
        if auto_export is not None and not isinstance(auto_export, bool):
            raise MCPToolError("auto_export must be boolean when provided")
        return self.controller.director_approve(take_id, auto_export=auto_export)

    def _reject_take(self, args: dict[str, Any]) -> dict[str, Any]:
        take_id = self._take_id(args)
        reason = args.get("reason")
        if not isinstance(reason, str) or not reason.strip():
            raise MCPToolError("reason must be a non-empty string")
        return self.controller.director_reject(take_id, reason.strip())

    def _regenerate_take(self, args: dict[str, Any]) -> dict[str, Any]:
        value = args.get("rejected_take_id")
        if not isinstance(value, str) or not value.strip():
            raise MCPToolError("rejected_take_id must be a non-empty string")
        return self.controller.regenerate(value.strip())

    def _export_approved_take(self, args: dict[str, Any]) -> list[dict[str, Any]]:
        return self.controller.export_approved(self._take_id(args))

    def _film_readiness(self, args: dict[str, Any]) -> dict[str, Any]:
        film_id = args.get("film_id")
        if not isinstance(film_id, str) or not film_id.strip():
            raise MCPToolError("film_id must be a non-empty string")
        return self.controller.film_readiness(film_id.strip())

    def discover(self) -> dict[str, Any]:
        return {
            "resultType": "complete",
            "supportedVersions": [MODERN_PROTOCOL, LEGACY_PROTOCOL],
            "capabilities": {"tools": {"listChanged": False}},
            "_meta": {"io.modelcontextprotocol/serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION}},
            "instructions": (
                "HIS RISEN Controller is the command bridge between an AI production manager and the HIS RISEN production controller. "
                "It never connects the model directly to ComfyUI. Use read-only tools to inspect state. Use generate_shot to submit one fully specified shot. "
                "Never infer or silently change creative requirements. Director approval is explicit. Rejected takes can be regenerated. Approved video outputs can be exported and verified."
            ),
            "ttlMs": 300000,
            "cacheScope": "private",
        }

    def initialize(self, requested: str | None) -> dict[str, Any]:
        version = requested if requested in {LEGACY_PROTOCOL} else LEGACY_PROTOCOL
        return {
            "protocolVersion": version,
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
            "instructions": "HIS RISEN Controller MCP bridge. Director approval is explicit; the MCP layer never directly commands ComfyUI.",
        }

    def call_tool(self, name: str, arguments: dict[str, Any]) -> tuple[bool, dict[str, Any] | str]:
        handler = self._handlers.get(name)
        if handler is None:
            return False, f"unknown tool: {name}"
        try:
            result = handler(arguments if isinstance(arguments, dict) else {})
            return True, result
        except (ValidationError, MCPToolError, LookupError, ValueError, KeyError, RuntimeError) as exc:
            return True, {"error": f"{type(exc).__name__}: {exc}"}
        except Exception as exc:
            return True, {"error": f"internal_error: {type(exc).__name__}: {exc}"}


def jsonrpc_result(request_id: Any, result: Any) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": request_id, "result": result}


def jsonrpc_error(request_id: Any, code: int, message: str, data: Any | None = None) -> dict[str, Any]:
    payload = {"jsonrpc": "2.0", "id": request_id, "error": {"code": code, "message": message}}
    if data is not None:
        payload["error"]["data"] = data
    return payload


def tool_call_result(payload: Any) -> dict[str, Any]:
    if isinstance(payload, dict) and set(payload) == {"error"}:
        text = payload["error"]
        return {"resultType": "complete", "content": [{"type": "text", "text": str(text)}], "structuredContent": payload, "isError": True}
    serialized = json.dumps(payload, ensure_ascii=False, default=str)
    return {"resultType": "complete", "content": [{"type": "text", "text": serialized}], "structuredContent": payload, "isError": False}


class MCPHTTPServer:
    def __init__(self, controller: Any, host: str = "127.0.0.1", port: int = 8190, token: str | None = None):
        self.controller = controller
        self.mcp = HISRisENMCP(controller)
        self.host = host
        self.port = port
        self.auth = StaticBearerAuth(token)
        owner = self

        class Handler(BaseHTTPRequestHandler):
            server_version = f"{SERVER_NAME}/{SERVER_VERSION}"

            def _send(self, status: int, payload: dict[str, Any] | None, headers: dict[str, str] | None = None, body: bytes | None = None) -> None:
                data = body if body is not None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(data)))
                for key, value in (headers or {}).items():
                    self.send_header(key, value)
                self.end_headers()
                self.wfile.write(data)

            def _authorized(self) -> bool:
                headers = {k: v for k, v in self.headers.items()}
                if owner.auth.check(headers):
                    return True
                self._send(401, {"error": "unauthorized"}, {"WWW-Authenticate": "Bearer"})
                return False

            def do_GET(self) -> None:
                path = urlparse(self.path).path.rstrip("/") or "/"
                if path == "/health":
                    result = owner.mcp._controller_health({})
                    return self._send(200, result)
                if path == "/mcp":
                    return self._send(405, {"error": "GET is not used by the HIS RISEN stateless JSON MCP transport; send POST requests to /mcp."}, {"Allow": "POST"})
                return self._send(404, {"error": "route not found"})

            def do_DELETE(self) -> None:
                path = urlparse(self.path).path.rstrip("/") or "/"
                if path == "/mcp":
                    return self._send(405, {"error": "session deletion is not supported because the modern MCP transport is stateless"}, {"Allow": "POST"})
                return self._send(404, {"error": "route not found"})

            def do_POST(self) -> None:
                path = urlparse(self.path).path.rstrip("/") or "/"
                if path != "/mcp":
                    return self._send(404, {"error": "route not found"})
                if not self._authorized():
                    return
                length = int(self.headers.get("Content-Length", "0"))
                if length <= 0 or length > 4 * 1024 * 1024:
                    return self._send(400, {"error": "request body must be between 1 byte and 4 MiB"})
                try:
                    request = json.loads(self.rfile.read(length).decode("utf-8"))
                except Exception as exc:
                    return self._send(400, jsonrpc_error(None, -32700, f"parse error: {exc}"))
                response = owner.handle(request)
                if response is None:
                    self.send_response(202)
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                else:
                    session_id = response.pop("__legacy_session_id", None)
                    extra = {"Mcp-Session-Id": session_id} if session_id else None
                    self._send(200, response, extra)

            def log_message(self, fmt: str, *args: object) -> None:
                return

        self._legacy_sessions: set[str] = set()
        self._session_lock = threading.RLock()
        self._server = ThreadingHTTPServer((host, port), Handler)

    @property
    def server_address(self) -> tuple[str, int]:
        return self._server.server_address

    def handle(self, request: Any) -> dict[str, Any] | None:
        if not isinstance(request, dict) or request.get("jsonrpc") != "2.0":
            return jsonrpc_error(request.get("id") if isinstance(request, dict) else None, -32600, "invalid request")
        request_id = request.get("id")
        method = request.get("method")
        params = request.get("params") or {}

        if method == "server/discover":
            return jsonrpc_result(request_id, self.mcp.discover())
        if method == "initialize":
            requested = params.get("protocolVersion") if isinstance(params, dict) else None
            session_id = str(uuid.uuid4())
            with self._session_lock:
                self._legacy_sessions.add(session_id)
            response = jsonrpc_result(request_id, self.mcp.initialize(requested))
            response["__legacy_session_id"] = session_id
            return response
        if method == "notifications/initialized" or method == "notifications/cancelled":
            return None
        if method == "tools/list":
            return jsonrpc_result(request_id, {"resultType": "complete", "tools": self.mcp.tools, "nextCursor": None, "ttlMs": 300000, "cacheScope": "private"})
        if method == "tools/call":
            if not isinstance(params, dict):
                return jsonrpc_error(request_id, -32602, "params must be an object")
            name = params.get("name")
            arguments = params.get("arguments") or {}
            if not isinstance(name, str):
                return jsonrpc_error(request_id, -32602, "params.name must be a string")
            exists = any(t["name"] == name for t in self.mcp.tools)
            if not exists:
                return jsonrpc_error(request_id, -32602, f"unknown tool: {name}")
            if not isinstance(arguments, dict):
                return jsonrpc_error(request_id, -32602, "params.arguments must be an object")
            _, payload = self.mcp.call_tool(name, arguments)
            return jsonrpc_result(request_id, tool_call_result(payload))
        if method == "ping":
            return jsonrpc_result(request_id, {})
        return jsonrpc_error(request_id, -32601, f"method not found: {method}")

    def serve_forever(self) -> None:
        self._server.serve_forever()

    def shutdown(self) -> None:
        self._server.shutdown()
        self._server.server_close()


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the HIS RISEN Controller MCP bridge")
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--host", default=os.getenv("HRF_MCP_HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.getenv("HRF_MCP_PORT", "8190")))
    parser.add_argument("--backend", choices=["mock", "comfyui"], default=os.getenv("HRF_BACKEND"))
    parser.add_argument("--token", default=os.getenv("HRF_MCP_BEARER_TOKEN"))
    args = parser.parse_args()

    controller = build_controller(args.root.resolve(), backend=args.backend)
    server = MCPHTTPServer(controller, host=args.host, port=args.port, token=args.token)
    print(f"HIS RISEN Controller MCP listening on http://{args.host}:{server.server_address[1]}/mcp")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        return 0
    finally:
        server.shutdown()
        controller.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
