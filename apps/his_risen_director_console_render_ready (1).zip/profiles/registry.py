from __future__ import annotations
import copy,json
from pathlib import Path
from typing import Any
from models.specification import ValidationError, nonempty_text, valid_id, validate_assets
class ProfileRegistry:
    def __init__(self, character_file: Path, voice_file: Path, root: Path):
        self.root=root.resolve(); self.characters=self._load(character_file); self.voices=self._load(voice_file)
    @staticmethod
    def _load(path: Path)->dict[str,Any]:
        with path.open("r",encoding="utf-8") as handle: data=json.load(handle)
        if not isinstance(data,dict): raise ValidationError([f"{path.name}: registry must be an object."])
        return data
    def ensure_available(self,snapshot:dict[str,Any])->None:
        errors=[]
        for character_id in snapshot["characters"]:
            if character_id not in self.characters: errors.append(f"character registry: missing {character_id}.")
        for voice_id in snapshot["voices"]:
            if voice_id not in self.voices: errors.append(f"voice registry: missing {voice_id}.")
        if errors: raise ValidationError(errors)
    def resolve(self,spec:dict[str,Any])->dict[str,Any]:
        errors=[]; characters={}; voices={}; assets=validate_assets(spec["reference_assets"],self.root,"reference_assets",errors)
        for character_id in spec["character_ids"]:
            profile=self.characters.get(character_id)
            if not isinstance(profile,dict): errors.append(f"character registry: missing {character_id}."); continue
            if not nonempty_text(profile.get("name")): errors.append(f"{character_id}.name: required character name.")
            for field in ("appearance","costume"):
                if field in profile and not nonempty_text(profile[field]): errors.append(f"{character_id}.{field}: if supplied, needs approved text.")
            rules=profile.get("visual_continuity_rules",[])
            if not isinstance(rules,list) or any(not nonempty_text(rule) for rule in rules): errors.append(f"{character_id}.visual_continuity_rules: invalid list.")
            profile_assets=validate_assets(profile.get("reference_assets",[]),self.root,f"{character_id}.reference_assets",errors)
            for asset_id,asset in profile_assets.items():
                if asset_id in assets and assets[asset_id]!=asset: errors.append(f"reference_assets: conflicting definition of {asset_id}.")
                else: assets[asset_id]=asset
            characters[character_id]=copy.deepcopy(profile)
        for voice_id in spec["voice_profile_ids"]:
            profile=self.voices.get(voice_id)
            if not isinstance(profile,dict): errors.append(f"voice registry: missing {voice_id}."); continue
            if not nonempty_text(profile.get("description")): errors.append(f"{voice_id}.description: required saved voice description.")
            voices[voice_id]=copy.deepcopy(profile)
        for index,line in enumerate(spec["dialogue"]):
            character_id=line["character_id"]; profile=characters.get(character_id)
            if profile is None: continue
            voice_id=profile.get("voice_profile_id")
            if not valid_id(voice_id,"voice"): errors.append(f"{character_id}.voice_profile_id: required for dialogue.")
            elif voice_id not in spec["voice_profile_ids"]: errors.append(f"voice_profile_ids: missing {voice_id}, required by dialogue[{index}] character {character_id}.")
            elif voice_id not in voices: errors.append(f"dialogue[{index}]: registered voice {voice_id} unavailable.")
        image_id=spec.get("input_image")
        if image_id is not None:
            image=assets.get(image_id)
            if image is None: errors.append(f"input_image: reference {image_id} is not registered in shot or character reference_assets.")
            elif image["kind"]!="image": errors.append(f"input_image: {image_id} is not an image reference.")
        frame_conditioning = spec.get("frame_conditioning")
        if frame_conditioning:
            for frame_name, frame in frame_conditioning.items():
                asset_id = frame.get("asset_id") if isinstance(frame, dict) else None
                if asset_id is None:
                    continue
                asset = assets.get(asset_id)
                if asset is None:
                    errors.append(f"frame_conditioning.{frame_name}.asset_id: reference {asset_id} is not registered in shot or character reference_assets.")
                elif asset.get("kind") != "image":
                    errors.append(f"frame_conditioning.{frame_name}.asset_id: {asset_id} is not an image reference.")
        if errors: raise ValidationError(errors)
        return {"characters":characters,"voices":voices,"reference_assets":copy.deepcopy(list(assets.values()))}
