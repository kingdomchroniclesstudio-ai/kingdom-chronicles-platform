from __future__ import annotations

import argparse
import json
from pathlib import Path

from config.bootstrap import build_controller
from models.specification import ValidationError


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="hisrisen", description="HIS RISEN FILMS controller CLI")
    parser.add_argument("--root", type=Path, default=None, help="controller project root")
    sub = parser.add_subparsers(dest="command", required=True)

    p_generate = sub.add_parser("generate")
    p_generate.add_argument("spec", type=Path)

    p_status = sub.add_parser("status")
    p_status.add_argument("take_id")

    p_progress = sub.add_parser("progress")
    p_progress.add_argument("take_id")

    p_advance = sub.add_parser("advance")
    p_advance.add_argument("take_id")

    p_approve = sub.add_parser("approve")
    p_approve.add_argument("take_id")

    p_reject = sub.add_parser("reject")
    p_reject.add_argument("take_id")
    p_reject.add_argument("--reason", required=True)

    p_regen = sub.add_parser("regenerate")
    p_regen.add_argument("take_id")

    p_export = sub.add_parser("export")
    p_export.add_argument("take_id")

    p_export_status = sub.add_parser("export-status")
    p_export_status.add_argument("take_id")

    p_readiness = sub.add_parser("film-readiness")
    p_readiness.add_argument("film_id")

    args = parser.parse_args(argv)
    root = (args.root or Path.cwd()).resolve()
    controller = build_controller(root)
    try:
        if args.command == "generate":
            spec_path = args.spec if args.spec.is_absolute() else (root / args.spec)
            spec = json.loads(spec_path.resolve().read_text(encoding="utf-8"))
            result = controller.generate(spec)
        elif args.command == "status":
            result = controller.get_take(args.take_id)
        elif args.command == "progress":
            result = controller.get_progress_events(args.take_id)
        elif args.command == "advance":
            result = controller.advance(args.take_id)
        elif args.command == "approve":
            result = controller.director_approve(args.take_id)
        elif args.command == "reject":
            result = controller.director_reject(args.take_id, args.reason)
        elif args.command == "regenerate":
            result = controller.regenerate(args.take_id)
        elif args.command == "export":
            result = controller.export_approved(args.take_id)
        elif args.command == "export-status":
            result = controller.export_status(args.take_id)
        elif args.command == "film-readiness":
            result = controller.film_readiness(args.film_id)
        else:
            raise AssertionError(args.command)
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    except ValidationError as exc:
        print(json.dumps({"ok": False, "error": "validation_error", "details": list(exc.errors)}, indent=2))
        return 2
    except Exception as exc:
        print(json.dumps({"ok": False, "error": f"{type(exc).__name__}: {exc}"}, indent=2))
        return 1
    finally:
        controller.close()


if __name__ == "__main__":
    raise SystemExit(main())
