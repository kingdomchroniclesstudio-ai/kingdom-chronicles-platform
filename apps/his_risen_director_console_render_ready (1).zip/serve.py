from __future__ import annotations

import argparse
from pathlib import Path

from api.server import ControllerHTTPServer
from config.bootstrap import build_controller


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the HIS RISEN local controller API")
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8189)
    parser.add_argument("--backend", choices=["mock", "comfyui"], default=None)
    args = parser.parse_args()
    controller = build_controller(args.root.resolve(), backend=args.backend)
    server = ControllerHTTPServer(controller, host=args.host, port=args.port)
    print(f"HIS RISEN Controller API listening on http://{args.host}:{server.server_address[1]}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        return 0
    finally:
        server.shutdown()
        controller.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
