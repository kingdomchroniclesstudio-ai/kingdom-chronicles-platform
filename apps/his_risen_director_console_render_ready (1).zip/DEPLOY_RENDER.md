# HIS RISEN Director Console — Render Free Deployment

This deployment target is intentionally the **mock controller**. It gives the Director a real HTTPS dashboard now, while the real RunPod/ComfyUI/LTX-2.5 backend remains a later connection.

## Required settings

Set `HRF_DIRECTOR_PIN` in the Render service environment to your own 6–12 digit PIN. Do not commit the PIN to source control.

The app reads Render's `PORT` environment variable and binds to `0.0.0.0`. Render provides a public `onrender.com` URL and managed TLS/HTTPS.

## Important free-tier behavior

Render's free web service may sleep after 15 minutes without inbound traffic, then wake on the next request. The free filesystem is ephemeral, so local SQLite/demo data can be lost on restart or sleep. For this reason this free deployment is a **Director Console preview/bridge**, not the permanent source of production state. Production state should live with the controller/RunPod environment (or another persistent database).
