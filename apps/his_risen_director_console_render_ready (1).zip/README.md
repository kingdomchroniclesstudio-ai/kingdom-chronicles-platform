# HIS RISEN FILMS — Phase 1 Controller

## Authority

GOD FIRST

The human CEO / Director retains final creative authority.
The Controller is an execution system. It does not make creative decisions or automatically approve generated takes.

## Current implementation

Phase 1 is a local, mock-backed controller foundation.

Controller → GenerationAdapter → MockComfyUIAdapter → MockComfyUI

The production engine target remains LTX-2.5 Fast through a future real ComfyUI adapter.

ChatGPT is currently handling the controller architecture, implementation, debugging, testing, and packaging. GPT-6 Astra is optional and is not a project dependency.

## Phase 1 capabilities

- Approved shot specification validation
- SINGLE-SHOT / MULTI-SHOT / EXTENSION routing
- Character and voice registries
- Reference-asset validation
- Director-approved prompt construction without rewriting approved action text
- Generation adapter abstraction
- Deterministic mock job simulation
- 25% → 75% → 100% progress
- Completion metadata with explicit mock/no-media notice
- Director approval/rejection lifecycle
- Explicit rejection reasons
- Exact-snapshot regeneration with parent/child relationships
- SQLite persistence
- Progress-event history
- Mock restart limitation is explicit rather than hidden

## Workflow presets

- `L25-T2V-SINGLE`
- `L25-I2V-SINGLE`
- `L25-MULTI-TESTED`
- `L25-CONTINUE-TESTED`

These are internal HIS RISEN identifiers, not official LTX or ComfyUI workflow identifiers. Phase 1 stores workflow metadata only; executable ComfyUI graphs are not included yet.

## Verification

Verified locally on 2026-10-03 using Python 3.13 and SQLite with no external generation service.

The test suite now covers:

- Controller lifecycle, prompt preservation, approval, rejection and regeneration
- T2V / I2V / MULTI / EXTENSION routing
- Explicit First Frame / First + Last Frame rules and advisory recommendations
- Technical shot fields such as resolution, aspect ratio, frame rate and quality preset
- Required workflow mapping values
- SQLite persistence and the known in-process mock-job limitation
- Real-adapter contracts against a fake ComfyUI server
- MCP protocol/tool lifecycle tests
- Director Console authentication and rate-limit behavior
- Mock Test button endpoint
- Completed-take video review before approval
- Approval → verified export → browser preview
- Rejection → regeneration → child take → approval
- Cross-origin state-change protection and request-body limits

Result: **30 tests passed, 0 failed, 6 subtests passed.**

The checked-in `config/test_shot.json` is now a runnable safe fixture with an 8-second duration and explicit 1440p / 16:9 / 24fps test settings.

## Reconstruction note

The surviving source artifact contained a malformed `profiles/voices.json` entry: the saved Moses voice description text was truncated at the end of the JSON string. The Phase 1 project makes only the minimal structural repair needed for valid JSON while preserving the recovered wording exactly; no new voice characteristics are invented.

## Not implemented yet

- Real ComfyUI API connection
- RunPod deployment/connection
- Real LTX-2.5 generation
- Real workflow graph submission
- Cloud credentials/configuration
- External voice-generation services
- GUI
- Autonomous creative control
- Distributed job recovery

Those belong to the later real-environment integration stage after the controller foundation is accepted.


## Phase 1.1 local interface + ComfyUI integration layer

The project now includes a local CLI and REST API surface plus a real ComfyUI adapter boundary.

### CLI

Run from the project root:

    python3 cli.py generate config/test_shot.json
    python3 cli.py status TAKE_ID
    python3 cli.py progress TAKE_ID
    python3 cli.py advance TAKE_ID
    python3 cli.py approve TAKE_ID
    python3 cli.py reject TAKE_ID --reason "Director rejection reason"
    python3 cli.py regenerate TAKE_ID

### REST API

Run:

    python3 serve.py --port 8189

Endpoints:

    GET  /health
    POST /shots/generate
    GET  /takes/{take_id}
    GET  /takes/{take_id}/progress
    POST /takes/{take_id}/advance
    POST /takes/{take_id}/approve
    POST /takes/{take_id}/reject
    POST /takes/{take_id}/regenerate

### Real ComfyUI adapter

`comfyui.adapter.RealComfyUIAdapter` communicates through ComfyUI's HTTP contract and optional WebSocket progress monitoring. It supports prompt queueing, history lookup, input-file upload, explicit workflow loading/mapping, output discovery, timeout handling, and connection/protocol errors.

The HTTP client targets the standard local ComfyUI routes used by the project's integration boundary: `/prompt`, `/history/{prompt_id}`, `/view`, `/upload/image`, and `/system_stats`. ComfyUI's official example demonstrates `/prompt`, `/history/{prompt_id}`, `/view`, and `/ws?clientId=...`. See the project's web research notes/source citations rather than treating these as LTX-specific endpoints.

### Real workflow gate

The files under `workflows/real/` in this repository are **contract-test fixtures, not LTX-2.5 workflows**. `workflows/real_presets.json` intentionally has `ready: false` for all four presets. The real adapter will refuse to submit until the corresponding exported API-format ComfyUI workflow JSON and mapping are supplied and explicitly marked ready.

This prevents a placeholder graph from ever being mistaken for a production LTX workflow.

### External dependency remaining

The controller-side software foundation is now built and tested without RunPod. The remaining environment-specific work is:

1. RunPod GPU/server.
2. ComfyUI installed and reachable.
3. LTX-2.5 model components installed.
4. Actual exported LTX-2.5 ComfyUI API-format workflow(s), with node/input mappings matching the installed workflow.
5. One real end-to-end generation test and any model/workflow-specific fixes that test reveals.

`websocket-client` is a normal Python package dependency for WebSocket monitoring; it is listed in `requirements.txt` and `pyproject.toml`. It is not a cloud/service dependency.

## Approved Output Export Manager

When a Director approves a completed take, the controller can retrieve the reported video output, save it under `outputs/production/<film>/<scene>/<shot>/<take>/`, verify the saved file with SHA-256, and register the export in SQLite. Export is idempotent: an already verified export is reused rather than downloaded again.

Available controller operations:
- `export <take_id>` — retrieve and verify an approved take
- `export-status <take_id>` — inspect export records
- `film-readiness <film_id>` — report approved/pending/failed takes and missing verified exports

REST equivalents:
- `POST /takes/<take_id>/export`
- `GET /takes/<take_id>/exports`
- `GET /films/<film_id>`
- `POST /takes/<take_id>/approve` accepts optional `{"auto_export": true}`

The runtime setting `auto_export_approved` controls whether Director approval automatically triggers export. It defaults to `false` in the mock environment; the production RunPod configuration can enable it.

This layer is transport-agnostic. Current retrieval supports a local `source_path` or HTTP `url`, which matches the ComfyUI `/view` output URL already discovered by the real adapter.


### Specialist generation capability: First/Last Frame
The controller is equipped for explicit `FIRST_FRAME` and `FIRST_LAST_FRAME` generation modes. These are optional specialist modes, not defaults. A recommendation endpoint can suggest a mode but never submits a job. The Director must explicitly authorize the mode and provide/approve frame conditioning assets. Real FLF execution is intentionally disabled until an approved LTX-2.5 ComfyUI workflow is installed and marked ready.
