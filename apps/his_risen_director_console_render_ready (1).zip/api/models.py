from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any


@dataclass(frozen=True)
class GenerateRequest:
    specification: dict[str, Any]

    @classmethod
    def from_dict(cls, data: Any) -> "GenerateRequest":
        if not isinstance(data, dict) or set(data) != {"specification"}:
            raise ValueError("request requires exactly the 'specification' object")
        if not isinstance(data["specification"], dict):
            raise ValueError("specification must be an object")
        return cls(specification=data["specification"])


@dataclass(frozen=True)
class DecisionRequest:
    reason: str | None = None
    auto_export: bool | None = None

    @classmethod
    def from_dict(cls, data: Any) -> "DecisionRequest":
        if data is None:
            return cls()
        if not isinstance(data, dict):
            raise ValueError("request body must be an object")
        unexpected = set(data) - {"reason", "auto_export"}
        if unexpected:
            raise ValueError(f"unsupported request fields: {', '.join(sorted(unexpected))}")
        reason = data.get("reason")
        if reason is not None and not isinstance(reason, str):
            raise ValueError("reason must be a string or null")
        auto_export = data.get("auto_export")
        if auto_export is not None and not isinstance(auto_export, bool):
            raise ValueError("auto_export must be a boolean or null")
        return cls(reason=reason, auto_export=auto_export)


@dataclass(frozen=True)
class APIResponse:
    ok: bool
    data: Any = None
    error: str | None = None
    details: Any = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
