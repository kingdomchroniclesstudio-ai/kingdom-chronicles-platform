from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def load_runtime(root: Path) -> dict[str, Any]:
    path = root / "config" / "runtime.json"
    return json.loads(path.read_text(encoding="utf-8"))
