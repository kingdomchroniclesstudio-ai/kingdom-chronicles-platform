from __future__ import annotations

import copy
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from config.bootstrap import build_controller
from models.specification import ValidationError


def fresh_project() -> Path:
    temp = Path(tempfile.mkdtemp(prefix="his-risen-flf-test-"))
    project = temp / "project"
    shutil.copytree(ROOT, project, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.sqlite3"))
    for db in project.glob("storage/*.sqlite3"):
        db.unlink()
    return project


class FrameConditioningTests(unittest.TestCase):
    def test_recommendation_is_advisory_only(self):
        project = fresh_project()
        controller = build_controller(project)
        try:
            spec = json.loads((project / "config" / "test_shot.json").read_text(encoding="utf-8"))
            spec["duration"] = 8
            result = controller.recommend_generation(spec)
            self.assertEqual(result["recommended_generation_mode"], "TEXT_TO_VIDEO")
            self.assertFalse(result["action_taken"])
            self.assertTrue(result["requires_director_authorization"])
            self.assertEqual(result["character_reference_options"][0]["character_id"], "CHR-MOS")
            self.assertEqual(controller.list_takes() if hasattr(controller, "list_takes") else [], [])
        finally:
            controller.close()

    def test_explicit_first_last_frame_routes_without_silent_asset_creation(self):
        project = fresh_project()
        controller = build_controller(project)
        try:
            spec = json.loads((project / "config" / "test_shot.json").read_text(encoding="utf-8"))
            spec.update({
                "duration": 8,
                "generation_mode": "FIRST_LAST_FRAME",
                "reference_assets": [
                    {"asset_id": "REF-FIRST", "kind": "image", "path": "refs/test_image.bin"},
                    {"asset_id": "REF-LAST", "kind": "image", "path": "refs/test_image.bin"},
                ],
                "frame_conditioning": {
                    "first_frame": {"asset_id": "REF-FIRST", "description": "Moses stands with the staff lowered."},
                    "last_frame": {"asset_id": "REF-LAST", "description": "Moses stands with the staff fully raised toward the sea."},
                },
            })
            take = controller.generate(spec)
            self.assertEqual(take["snapshot"]["workflow"]["preset_id"], "L25-FIRST-LAST-FRAME-SINGLE")
            self.assertEqual(take["snapshot"]["specification"]["generation_mode"], "FIRST_LAST_FRAME")
            self.assertIn("FRAME CONDITIONING", take["snapshot"]["prompt"])
            self.assertEqual(take["status"], "SUBMITTED")
        finally:
            controller.close()

    def test_frame_conditioning_requires_explicit_mode_and_both_frames(self):
        project = fresh_project()
        controller = build_controller(project)
        try:
            base = json.loads((project / "config" / "test_shot.json").read_text(encoding="utf-8"))
            base["duration"] = 8
            candidate = copy.deepcopy(base)
            candidate["frame_conditioning"] = {"first_frame": {"description": "Start state."}}
            with self.assertRaisesRegex(ValidationError, "frame_conditioning: permitted only"):
                controller.generate(candidate)

            candidate = copy.deepcopy(base)
            candidate["generation_mode"] = "FIRST_LAST_FRAME"
            with self.assertRaisesRegex(ValidationError, "frame_conditioning: required"):
                controller.generate(candidate)
        finally:
            controller.close()


if __name__ == "__main__":
    unittest.main()
