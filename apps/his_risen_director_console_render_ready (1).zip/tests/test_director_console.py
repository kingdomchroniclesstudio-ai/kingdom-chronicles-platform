from __future__ import annotations

import json
import shutil
import tempfile
import threading
import time
import urllib.error
import urllib.request
from http.cookies import SimpleCookie
from pathlib import Path
import unittest
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from config.bootstrap import build_controller
from director_console import DirectorConsole, Handler
from http.server import ThreadingHTTPServer


def fresh_project() -> Path:
    temp = Path(tempfile.mkdtemp(prefix="his-risen-console-test-"))
    project = temp / "project"
    shutil.copytree(ROOT, project, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.sqlite3"))
    for db in project.glob("storage/*.sqlite3"):
        db.unlink()
    return project


class DirectorConsoleHTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.project = fresh_project()
        cls.controller = build_controller(cls.project, backend="mock")
        cls.console = DirectorConsole(cls.controller, "12345678", cls.project)
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.server.console = cls.console
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_address[1]}"
        cls.cookies = SimpleCookie()

    @classmethod
    def tearDownClass(cls):
        cls.console.stop()
        cls.controller.close()
        cls.server.shutdown()
        cls.server.server_close()

    @classmethod
    def request(cls, method: str, path: str, payload=None):
        body = None if payload is None else json.dumps(payload).encode("utf-8")
        headers = {"Accept": "application/json"}
        if body is not None:
            headers["Content-Type"] = "application/json"
        cookie_header = "; ".join(f"{m.key}={m.value}" for m in cls.cookies.values())
        if cookie_header:
            headers["Cookie"] = cookie_header
        req = urllib.request.Request(cls.base + path, data=body, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=3) as resp:
                set_cookie = resp.headers.get("Set-Cookie")
                if set_cookie:
                    cls.cookies.load(set_cookie)
                raw = resp.read()
                ctype = resp.headers.get("Content-Type", "")
                return resp.status, ctype, raw
        except urllib.error.HTTPError as exc:
            return exc.code, exc.headers.get("Content-Type", ""), exc.read()

    @classmethod
    def json_request(cls, method: str, path: str, payload=None):
        status, ctype, raw = cls.request(method, path, payload)
        return status, ctype, json.loads(raw.decode("utf-8"))

    def setUp(self):
        self.json_request("POST", "/api/login", {"pin": "12345678"})

    def test_auth_and_empty_console(self):
        # The class-level login from setUp establishes an authenticated baseline.
        self.request("POST", "/api/logout", {})
        status, _, body = self.json_request("GET", "/api/status")
        self.assertEqual(status, 401)

        status, _, body = self.json_request("POST", "/api/login", {"pin": "12345678"})
        self.assertEqual(status, 200)
        self.assertTrue(body["ok"])

        status, _, body = self.json_request("GET", "/api/status")
        self.assertEqual(status, 200)
        self.assertEqual(body["data"]["backend_adapter"], "MockComfyUIAdapter")
        self.assertTrue(body["data"]["mock_mode"])

        status, _, body = self.json_request("GET", "/api/films")
        self.assertEqual(status, 200)
        self.assertEqual(body["data"], [])

    def test_mock_generation_review_regeneration_export_and_preview(self):
        status, _, created = self.json_request("POST", "/api/mock-test", {})
        self.assertEqual(status, 200)
        take = created["data"]["take"]
        self.assertTrue(created["data"]["created"])
        take_id = take["take_id"]
        self.assertEqual(take["status"], "SUBMITTED")

        # Repeat click while the job is active must not create a duplicate.
        status, _, reused = self.json_request("POST", "/api/mock-test", {})
        self.assertEqual(status, 200)
        self.assertTrue(reused["data"]["reused"])
        self.assertEqual(reused["data"]["take"]["take_id"], take_id)

        for _ in range(3):
            self.controller.advance(take_id)
        time.sleep(0.1)

        status, ctype, raw = self.request("GET", f"/api/takes/{take_id}/preview")
        self.assertEqual(status, 200)
        self.assertTrue(ctype.startswith("video/mp4"))
        self.assertGreater(len(raw), 100)

        status, _, approved = self.json_request("POST", f"/api/takes/{take_id}/approve", {"auto_export": True})
        self.assertEqual(status, 200)
        self.assertEqual(approved["data"]["status"], "APPROVED")

        status, _, readiness = self.json_request("GET", "/api/films/HRF-MOCK-TEST/readiness")
        self.assertEqual(status, 200)
        self.assertEqual(readiness["data"]["approved"], 1)
        self.assertEqual(readiness["data"]["missing_approved_exports"], [])
        self.assertTrue(readiness["data"]["ready_for_editing"])

        # A second test generation is possible after the first is approved.
        status, _, second = self.json_request("POST", "/api/mock-test", {})
        self.assertEqual(status, 200)
        second_id = second["data"]["take"]["take_id"]
        self.assertNotEqual(second_id, take_id)
        for _ in range(3):
            self.controller.advance(second_id)

        status, _, rejected = self.json_request("POST", f"/api/takes/{second_id}/reject", {"reason": "Mock rejection for lifecycle test."})
        self.assertEqual(status, 200)
        self.assertEqual(rejected["data"]["status"], "REJECTED")

        status, _, regenerated = self.json_request("POST", f"/api/takes/{second_id}/regenerate", {})
        self.assertEqual(status, 200)
        child_id = regenerated["data"]["take_id"]
        self.assertEqual(regenerated["data"]["parent_take_id"], second_id)
        for _ in range(3):
            self.controller.advance(child_id)

        status, _, final = self.json_request("POST", f"/api/takes/{child_id}/approve", {"auto_export": True})
        self.assertEqual(status, 200)
        self.assertEqual(final["data"]["status"], "APPROVED")

    def test_untrusted_origin_is_blocked(self):
        body = json.dumps({}).encode()
        cookie_header = "; ".join(f"{m.key}={m.value}" for m in self.cookies.values())
        request = urllib.request.Request(
            self.base + "/api/mock-test",
            data=body,
            headers={"Content-Type": "application/json", "Cookie": cookie_header, "Origin": "https://evil.example"},
            method="POST",
        )
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(request, timeout=3)
        self.assertEqual(ctx.exception.code, 403)

    def test_large_json_body_is_rejected(self):
        body = json.dumps({"x": "a" * 300000}).encode()
        cookie_header = "; ".join(f"{m.key}={m.value}" for m in self.cookies.values())
        request = urllib.request.Request(
            self.base + "/api/mock-test",
            data=body,
            headers={"Content-Type": "application/json", "Cookie": cookie_header},
            method="POST",
        )
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(request, timeout=3)
        self.assertEqual(ctx.exception.code, 413)

    def test_invalid_json_is_rejected_as_bad_request(self):
        cookie_header = "; ".join(f"{m.key}={m.value}" for m in self.cookies.values())
        request = urllib.request.Request(
            self.base + "/api/mock-test",
            data=b"not-json",
            headers={"Content-Type": "application/json", "Cookie": cookie_header},
            method="POST",
        )
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(request, timeout=3)
        self.assertEqual(ctx.exception.code, 400)


if __name__ == "__main__":
    unittest.main()
