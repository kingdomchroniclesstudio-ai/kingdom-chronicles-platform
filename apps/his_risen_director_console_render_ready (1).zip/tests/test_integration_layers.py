from __future__ import annotations

import copy
import json
import shutil
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

from api.models import GenerateRequest
from api.server import ControllerHTTPServer
from comfyui.adapter import RealComfyUIAdapter
from comfyui.errors import ComfyUIConnectionError, ComfyUIProtocolError
from comfyui.http_client import ComfyUIHTTPClient
from comfyui.output_discovery import discover_outputs
from comfyui.websocket_monitor import parse_progress_event, websocket_url
from workflows.loader import WorkflowLoader, WorkflowTemplateError


class IntegrationLayerTests(unittest.TestCase):
    def test_api_models_strictness(self):
        spec = {"x": 1}
        self.assertEqual(GenerateRequest.from_dict({"specification": spec}).specification, spec)
        with self.assertRaises(ValueError):
            GenerateRequest.from_dict({"specification": spec, "extra": 1})

    def test_workflow_loader_and_mapping(self):
        root = Path(__file__).resolve().parents[1]
        loader = WorkflowLoader(root)
        wf = loader.load("workflows/real/L25-T2V-SINGLE.api.json")
        mapping = json.loads((root / "workflows/real/L25-T2V-SINGLE.mapping.json").read_text())
        out = loader.apply_mapping(wf, mapping, {"prompt": "DIRECTOR PROMPT"})
        self.assertEqual(out["10"]["inputs"]["prompt"], "DIRECTOR PROMPT")
        with self.assertRaises(WorkflowTemplateError):
            loader.load("../outside.json")

    def test_required_mapping_value_cannot_be_silently_omitted(self):
        root = Path(__file__).resolve().parents[1]
        loader = WorkflowLoader(root)
        workflow = {"10": {"class_type": "SaveVideo", "inputs": {"prompt": ""}}}
        mapping = {"prompt": {"node_id": "10", "input": "prompt", "required": True}}
        with self.assertRaisesRegex(WorkflowTemplateError, "required mapping value prompt is missing"):
            loader.validate_required_mappings(workflow, mapping, {})

    def test_output_discovery_preserves_subfolder(self):
        history = {"9": {"outputs": {"node": {"videos": [{"filename": "x.mp4", "subfolder": "clips", "type": "output"}], "images": [{"filename": "x.png"}]}}}}
        files = discover_outputs(history)
        video = next(x for x in files if x["kind"] == "video")
        self.assertEqual(video["subfolder"], "clips")
        self.assertEqual(video["type"], "output")

    def test_websocket_helpers(self):
        self.assertEqual(websocket_url("http://127.0.0.1:8188", "CID"), "ws://127.0.0.1:8188/ws?clientId=CID")
        self.assertEqual(parse_progress_event({"type":"progress","data":{"prompt_id":"P","value":5,"max":10}}, "P"), ("RUNNING", 50))
        self.assertEqual(parse_progress_event({"type":"executing","data":{"prompt_id":"P","node":None}}, "P"), ("COMPLETED", 100))

    def test_http_client_contract_against_fake_server(self):
        from dev.fake_comfyui import FakeComfyUI
        fake = FakeComfyUI(); fake.start()
        try:
            client = ComfyUIHTTPClient(fake.base_url)
            result = client.queue_prompt({"10": {"class_type": "SaveVideo", "inputs": {}}}, client_id="C")
            self.assertIn("prompt_id", result)
            history = client.history(result["prompt_id"])
            self.assertIn(result["prompt_id"], history)
        finally:
            fake.stop()

    def test_real_adapter_contract_against_fake_http_server(self):
        from dev.fake_comfyui import FakeComfyUI
        root = Path(__file__).resolve().parents[1]
        work = Path(tempfile.mkdtemp(prefix="his-risen-real-adapter-")) / "project"
        shutil.copytree(root, work, ignore=shutil.ignore_patterns("*.sqlite3", "__pycache__"))
        cfg_path = work / "workflows" / "real_presets.json"
        cfg = json.loads(cfg_path.read_text())
        cfg["L25-T2V-SINGLE"]["ready"] = True
        cfg_path.write_text(json.dumps(cfg))
        fake = FakeComfyUI(); fake.start()
        try:
            adapter = RealComfyUIAdapter(work, fake.base_url, timeout=2, job_timeout=10)
            request = {"workflow":{"preset_id":"L25-T2V-SINGLE"},"specification":{"duration":8},"prompt":"TEST PROMPT","profiles":{"reference_assets":[]}}
            job = adapter.submit(request, "TAKE-1")
            first = adapter.poll(job)
            self.assertIn(first.state, {"RUNNING", "COMPLETED"})
            second = adapter.poll(job)
            self.assertEqual(second.state, "COMPLETED")
            self.assertFalse(second.output_metadata["is_mock"])
            self.assertTrue(second.output_metadata["media_generated"])
        finally:
            fake.stop()


    def test_real_adapter_uploads_reference_and_maps_returned_name(self):
        from dev.fake_comfyui import FakeComfyUI
        root = Path(__file__).resolve().parents[1]
        work = Path(tempfile.mkdtemp(prefix="his-risen-upload-") ) / "project"
        shutil.copytree(root, work, ignore=shutil.ignore_patterns("*.sqlite3", "__pycache__"))
        cfg_path = work / "workflows" / "real_presets.json"
        cfg = json.loads(cfg_path.read_text())
        cfg["L25-I2V-SINGLE"]["ready"] = True
        cfg_path.write_text(json.dumps(cfg))
        fake = FakeComfyUI(); fake.start()
        try:
            adapter = RealComfyUIAdapter(work, fake.base_url, timeout=2, job_timeout=10)
            asset = work / "refs" / "input.png"
            asset.write_bytes(b"PNG-TEST")
            request = {
                "workflow":{"preset_id":"L25-I2V-SINGLE"},
                "specification":{"film_id":"HRF-MEX-001","duration":8,"input_image":"REF-IN"},
                "prompt":"TEST PROMPT",
                "profiles":{"reference_assets":[{"asset_id":"REF-IN","kind":"image","path":"refs/input.png"}]},
            }
            job = adapter.submit(request, "TAKE-UPLOAD-1")
            self.assertTrue(job)
            applied = adapter.jobs[job]["workflow"]
            self.assertEqual(applied["10"]["inputs"]["input_image"], "uploaded-input.png")
        finally:
            fake.stop()

    def test_real_adapter_blocks_until_real_workflow_is_supplied(self):
        root = Path(__file__).resolve().parents[1]
        adapter = RealComfyUIAdapter(root, "http://127.0.0.1:8188")
        request = {"workflow":{"preset_id":"L25-T2V-SINGLE"},"specification":{"duration":8},"prompt":"TEST","profiles":{"reference_assets":[]}}
        with self.assertRaises(WorkflowTemplateError):
            adapter.submit(request, "TAKE-READY-GATE")

    def test_http_connection_failure_is_explicit(self):
        with self.assertRaises(ComfyUIConnectionError):
            ComfyUIHTTPClient("http://127.0.0.1:1", timeout=0.1).system_stats()

    def test_local_rest_api_full_lifecycle(self):
        from config.bootstrap import build_controller
        root = Path(__file__).resolve().parents[1]
        tmp = Path(tempfile.mkdtemp(prefix="his-risen-api-"))
        shutil.copytree(root, tmp / "project", ignore=shutil.ignore_patterns("*.sqlite3", "__pycache__"))
        controller = build_controller(tmp / "project")
        server = ControllerHTTPServer(controller, port=0)
        thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
        try:
            base = f"http://127.0.0.1:{server.server_address[1]}"
            with urllib.request.urlopen(base + "/health", timeout=2) as response:
                self.assertEqual(json.loads(response.read())["ok"], True)
            spec = json.loads((tmp / "project/config/test_shot.json").read_text()); spec["duration"] = 8
            req = urllib.request.Request(base + "/shots/generate", data=json.dumps({"specification": spec}).encode(), headers={"Content-Type":"application/json"}, method="POST")
            with urllib.request.urlopen(req, timeout=2) as response:
                created = json.loads(response.read())
            tid = created["data"]["take_id"]
            for _ in range(3):
                u = urllib.request.Request(base + f"/takes/{tid}/advance", data=b"{}", headers={"Content-Type":"application/json"}, method="POST")
                with urllib.request.urlopen(u, timeout=2) as response:
                    state = json.loads(response.read())["data"]
            self.assertEqual(state["status"], "COMPLETED")
            approve = urllib.request.Request(base + f"/takes/{tid}/approve", data=b"{}", headers={"Content-Type":"application/json"}, method="POST")
            with urllib.request.urlopen(approve, timeout=2) as response:
                self.assertEqual(json.loads(response.read())["data"]["status"], "APPROVED")
        finally:
            server.shutdown(); controller.close()


if __name__ == "__main__":
    unittest.main()

class ApprovedExportTests(unittest.TestCase):
    def _project_copy(self):
        root = Path(__file__).resolve().parents[1]
        tmp = Path(tempfile.mkdtemp(prefix="his-risen-export-")) / "project"
        shutil.copytree(root, tmp, ignore=shutil.ignore_patterns("*.sqlite3", "__pycache__"))
        return tmp

    def test_approved_take_auto_retrieves_verifies_and_is_idempotent(self):
        from comfyui.adapter import RealComfyUIAdapter
        from config.runtime import load_runtime
        from controller.service import Controller
        from exports import ApprovedOutputExportManager, FileOutputRetriever
        from profiles.registry import ProfileRegistry
        from storage.sqlite_store import SQLiteStore
        from workflows.registry import WorkflowRegistry
        from dev.fake_comfyui import FakeComfyUI

        root = self._project_copy()
        cfg_path = root / "workflows" / "real_presets.json"
        cfg = json.loads(cfg_path.read_text())
        cfg["L25-T2V-SINGLE"]["ready"] = True
        cfg_path.write_text(json.dumps(cfg))
        fake = FakeComfyUI(); fake.start()
        controller = None
        try:
            profiles = ProfileRegistry(root / "profiles" / "characters.json", root / "profiles" / "voices.json", root)
            workflows = WorkflowRegistry(root / "workflows" / "presets.json")
            store = SQLiteStore(root / "storage" / "controller.sqlite3")
            adapter = RealComfyUIAdapter(root, fake.base_url, timeout=2, job_timeout=10)
            manager = ApprovedOutputExportManager(root, store, FileOutputRetriever(), root / "outputs" / "production")
            controller = Controller(root, profiles, workflows, store, adapter, manager, auto_export_approved=True)
            spec = json.loads((root / "config" / "test_shot.json").read_text())
            spec["duration"] = 8
            take = controller.generate(spec)
            for _ in range(5):
                if take["status"] == "COMPLETED":
                    break
                take = controller.advance(take["take_id"])
            self.assertEqual(take["status"], "COMPLETED")
            approved = controller.director_approve(take["take_id"])
            self.assertEqual(approved["status"], "APPROVED")
            records = controller.export_status(take["take_id"])
            self.assertEqual(len(records), 1)
            self.assertEqual(records[0]["status"], "VERIFIED")
            path = Path(records[0]["path"])
            self.assertTrue(path.is_file())
            self.assertGreater(path.stat().st_size, 0)
            first_hash = records[0]["sha256"]
            again = controller.export_approved(take["take_id"])
            self.assertEqual(again[0]["status"], "VERIFIED")
            self.assertEqual(again[0]["sha256"], first_hash)
            self.assertEqual(len(controller.export_status(take["take_id"])), 1)
            readiness = controller.film_readiness(spec["film_id"])
            self.assertTrue(readiness["ready_for_editing"])
            self.assertEqual(readiness["missing_approved_exports"], [])
        finally:
            if controller is not None:
                controller.close()
            fake.stop()

    def test_export_refuses_unapproved_take(self):
        from exports import ApprovedOutputExportManager, FileOutputRetriever, ExportError
        from config.bootstrap import build_controller
        root = self._project_copy()
        controller = build_controller(root)
        try:
            spec = json.loads((root / "config" / "test_shot.json").read_text())
            spec["duration"] = 8
            take = controller.generate(spec)
            with self.assertRaises(ExportError):
                controller.export_approved(take["take_id"])
        finally:
            controller.close()

class MCPBridgeTests(unittest.TestCase):
    def setUp(self):
        import tempfile
        from config.bootstrap import build_controller
        root = Path(__file__).resolve().parents[1]
        self.tmp = Path(tempfile.mkdtemp(prefix="his-risen-mcp-")) / "project"
        shutil.copytree(root, self.tmp, ignore=shutil.ignore_patterns("*.sqlite3", "__pycache__"))
        self.controller = build_controller(self.tmp, backend="mock")

    def tearDown(self):
        if getattr(self, "server", None) is not None:
            self.server.shutdown()
        if getattr(self, "controller", None) is not None:
            self.controller.close()

    def _post(self, payload, headers=None):
        from mcp_server import MCPHTTPServer
        if getattr(self, "server", None) is None:
            token = "mcp-test-token"
            self.server = MCPHTTPServer(self.controller, host="127.0.0.1", port=0, token=token)
            self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
            self.thread.start()
            self.base = f"http://127.0.0.1:{self.server.server_address[1]}"
        final_headers = {"Content-Type": "application/json", "Accept": "application/json", "Authorization": "Bearer mcp-test-token"}
        if headers:
            final_headers.update(headers)
        request = urllib.request.Request(self.base + "/mcp", data=json.dumps(payload).encode(), headers=final_headers, method="POST")
        with urllib.request.urlopen(request, timeout=2) as response:
            return response.status, response.headers, json.loads(response.read())

    def test_modern_discovery_and_tool_listing(self):
        status, _, body = self._post({
            "jsonrpc": "2.0", "id": 1, "method": "server/discover",
            "params": {"_meta": {"io.modelcontextprotocol/protocolVersion": "2026-07-28", "io.modelcontextprotocol/clientInfo": {"name": "test", "version": "1"}, "io.modelcontextprotocol/clientCapabilities": {}}}
        }, {"MCP-Protocol-Version": "2026-07-28", "Mcp-Method": "server/discover", "Mcp-Name": "test"})
        self.assertEqual(status, 200)
        self.assertEqual(body["result"]["supportedVersions"][0], "2026-07-28")

        status, _, body = self._post({
            "jsonrpc": "2.0", "id": 2, "method": "tools/list",
            "params": {"_meta": {"io.modelcontextprotocol/protocolVersion": "2026-07-28", "io.modelcontextprotocol/clientInfo": {"name": "test", "version": "1"}, "io.modelcontextprotocol/clientCapabilities": {}}}
        }, {"MCP-Protocol-Version": "2026-07-28", "Mcp-Method": "tools/list", "Mcp-Name": "test"})
        self.assertEqual(status, 200)
        names = [tool["name"] for tool in body["result"]["tools"]]
        self.assertEqual(names, [
            "controller_health", "generate_shot", "advance_generation", "get_take", "get_take_progress",
            "approve_take", "reject_take", "regenerate_take", "export_approved_take", "film_readiness"
        ])

    def test_modern_tool_call_drives_controller_lifecycle(self):
        spec = json.loads((self.tmp / "config" / "test_shot.json").read_text())
        spec["duration"] = 8
        status, _, created = self._post({
            "jsonrpc": "2.0", "id": 3, "method": "tools/call",
            "params": {"name": "generate_shot", "arguments": {"specification": spec}, "_meta": {"io.modelcontextprotocol/protocolVersion": "2026-07-28", "io.modelcontextprotocol/clientInfo": {"name": "test", "version": "1"}, "io.modelcontextprotocol/clientCapabilities": {}}}
        }, {"MCP-Protocol-Version": "2026-07-28", "Mcp-Method": "tools/call", "Mcp-Name": "generate_shot"})
        self.assertEqual(status, 200)
        take_id = created["result"]["structuredContent"]["take_id"]
        self.assertFalse(created["result"]["isError"])

        current = None
        for i in range(3):
            _, _, result = self._post({
                "jsonrpc": "2.0", "id": 10 + i, "method": "tools/call",
                "params": {"name": "advance_generation", "arguments": {"take_id": take_id}, "_meta": {"io.modelcontextprotocol/protocolVersion": "2026-07-28", "io.modelcontextprotocol/clientInfo": {"name": "test", "version": "1"}, "io.modelcontextprotocol/clientCapabilities": {}}}
            }, {"MCP-Protocol-Version": "2026-07-28", "Mcp-Method": "tools/call", "Mcp-Name": "advance_generation"})
            current = result["result"]["structuredContent"]
        self.assertEqual(current["status"], "COMPLETED")

        _, _, approved = self._post({
            "jsonrpc": "2.0", "id": 20, "method": "tools/call",
            "params": {"name": "approve_take", "arguments": {"take_id": take_id}, "_meta": {"io.modelcontextprotocol/protocolVersion": "2026-07-28", "io.modelcontextprotocol/clientInfo": {"name": "test", "version": "1"}, "io.modelcontextprotocol/clientCapabilities": {}}}
        }, {"MCP-Protocol-Version": "2026-07-28", "Mcp-Method": "tools/call", "Mcp-Name": "approve_take"})
        self.assertEqual(approved["result"]["structuredContent"]["status"], "APPROVED")

    def test_legacy_initialize_returns_session_header(self):
        status, headers, body = self._post({
            "jsonrpc": "2.0", "id": 30, "method": "initialize",
            "params": {"protocolVersion": "2025-11-25", "capabilities": {}, "clientInfo": {"name": "legacy-test", "version": "1"}}
        }, {"Accept": "application/json, text/event-stream", "MCP-Protocol-Version": "2025-11-25", "Mcp-Method": "initialize", "Mcp-Name": "legacy-test"})
        self.assertEqual(status, 200)
        self.assertEqual(body["result"]["protocolVersion"], "2025-11-25")
        self.assertTrue(headers.get("Mcp-Session-Id"))

    def test_missing_bearer_token_is_rejected(self):
        import tempfile
        if getattr(self, "server", None) is None:
            from mcp_server import MCPHTTPServer
            self.server = MCPHTTPServer(self.controller, host="127.0.0.1", port=0, token="secret")
            self.thread = threading.Thread(target=self.server.serve_forever, daemon=True); self.thread.start()
            self.base = f"http://127.0.0.1:{self.server.server_address[1]}"
        request = urllib.request.Request(self.base + "/mcp", data=b'{"jsonrpc":"2.0","id":1,"method":"server/discover","params":{}}', headers={"Content-Type":"application/json"}, method="POST")
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(request, timeout=2)
        self.assertEqual(ctx.exception.code, 401)
