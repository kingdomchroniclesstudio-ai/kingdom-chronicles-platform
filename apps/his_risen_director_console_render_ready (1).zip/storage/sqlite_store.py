from __future__ import annotations
import json,sqlite3
from threading import RLock
from contextlib import contextmanager
from datetime import datetime,timezone
from pathlib import Path
from typing import Any,Iterator
from adapters.base import GenerationUpdate
from models.specification import nonempty_text
SCHEMA="""CREATE TABLE IF NOT EXISTS films (film_id TEXT PRIMARY KEY); CREATE TABLE IF NOT EXISTS scenes (film_id TEXT NOT NULL,scene_id TEXT NOT NULL,PRIMARY KEY(film_id,scene_id),FOREIGN KEY(film_id) REFERENCES films(film_id)); CREATE TABLE IF NOT EXISTS shots (film_id TEXT NOT NULL,scene_id TEXT NOT NULL,shot_id TEXT NOT NULL,PRIMARY KEY(film_id,scene_id,shot_id),FOREIGN KEY(film_id,scene_id) REFERENCES scenes(film_id,scene_id)); CREATE TABLE IF NOT EXISTS takes (take_id TEXT PRIMARY KEY,film_id TEXT NOT NULL,scene_id TEXT NOT NULL,shot_id TEXT NOT NULL,revision INTEGER NOT NULL CHECK(revision>0),take_number INTEGER NOT NULL CHECK(take_number>0),job_id TEXT UNIQUE,status TEXT NOT NULL CHECK(status IN ('PENDING','SUBMITTED','RUNNING','COMPLETED','APPROVED','REJECTED','FAILED')),progress INTEGER NOT NULL CHECK(progress BETWEEN 0 AND 100),snapshot_json TEXT NOT NULL,output_json TEXT,parent_take_id TEXT,parent_rejection_reason TEXT,rejection_reason TEXT,error TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(film_id,scene_id,shot_id,revision),UNIQUE(film_id,scene_id,shot_id,take_number),FOREIGN KEY(film_id,scene_id,shot_id) REFERENCES shots(film_id,scene_id,shot_id),FOREIGN KEY(parent_take_id) REFERENCES takes(take_id)); CREATE TABLE IF NOT EXISTS progress_events (event_id INTEGER PRIMARY KEY AUTOINCREMENT,take_id TEXT NOT NULL,job_id TEXT,state TEXT NOT NULL,progress INTEGER NOT NULL CHECK(progress BETWEEN 0 AND 100),message TEXT,created_at TEXT NOT NULL,FOREIGN KEY(take_id) REFERENCES takes(take_id)); CREATE INDEX IF NOT EXISTS progress_events_take ON progress_events(take_id,event_id); CREATE INDEX IF NOT EXISTS takes_parent ON takes(parent_take_id); CREATE TABLE IF NOT EXISTS exports (export_id TEXT PRIMARY KEY,take_id TEXT NOT NULL,media_index INTEGER NOT NULL,kind TEXT,status TEXT NOT NULL,path TEXT,filename TEXT,bytes INTEGER NOT NULL DEFAULT 0,sha256 TEXT,message TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(take_id,media_index),FOREIGN KEY(take_id) REFERENCES takes(take_id)); CREATE INDEX IF NOT EXISTS exports_take ON exports(take_id);"""
def now(): return datetime.now(timezone.utc).isoformat()
def dump(value): return json.dumps(value,ensure_ascii=False,sort_keys=True,allow_nan=False)
class SQLiteStore:
    def __init__(self,path:Path):
        path.parent.mkdir(parents=True,exist_ok=True); self.connection=sqlite3.connect(path,isolation_level=None,timeout=10,check_same_thread=False); self._lock=RLock(); self.connection.row_factory=sqlite3.Row; self.connection.execute("PRAGMA foreign_keys = ON"); self.connection.executescript(SCHEMA)
    def close(self):
        with self._lock: self.connection.close()
    @contextmanager
    def _transaction(self)->Iterator[None]:
        with self._lock:
            self.connection.execute("BEGIN IMMEDIATE")
            try:
                yield
                self.connection.execute("COMMIT")
            except BaseException:
                self.connection.execute("ROLLBACK")
                raise
    def _row(self,take_id):
        with self._lock:
            row=self.connection.execute("SELECT * FROM takes WHERE take_id = ?",(take_id,)).fetchone()
            if row is None: raise LookupError(f"Take not found: {take_id}")
            return row
    def get_take(self,take_id):
        with self._lock:
            result=dict(self._row(take_id)); result["snapshot"]=json.loads(result.pop("snapshot_json")); output=result.pop("output_json"); result["output_metadata"]=json.loads(output) if output else None; return result
    def progress_events(self,take_id):
        with self._lock:
            self._row(take_id); rows=self.connection.execute("SELECT event_id,take_id,job_id,state,progress,message,created_at FROM progress_events WHERE take_id = ? ORDER BY event_id",(take_id,)).fetchall(); return [dict(row) for row in rows]
    def _event(self,take_id,job_id,state,progress,message=None):
        self.connection.execute("INSERT INTO progress_events (take_id,job_id,state,progress,message,created_at) VALUES (?,?,?,?,?,?)",(take_id,job_id,state,progress,message,now()))
    def reserve_take(self,snapshot,parent_take_id=None):
        snapshot_json=dump(snapshot); spec=snapshot["specification"]; identity=(spec["film_id"],spec["scene_id"],spec["shot_id"])
        with self._transaction():
            parent_reason=None
            if parent_take_id is not None:
                parent=self._row(parent_take_id); parent_identity=(parent["film_id"],parent["scene_id"],parent["shot_id"])
                if parent["status"]!="REJECTED": raise ValueError("Regeneration requires a REJECTED parent.")
                if parent_identity!=identity: raise ValueError("Regeneration must preserve shot identity.")
                if parent["snapshot_json"]!=snapshot_json: raise ValueError("Phase 1 regeneration must preserve the exact snapshot.")
                parent_reason=parent["rejection_reason"]
            self.connection.execute("INSERT OR IGNORE INTO films(film_id) VALUES (?)",(identity[0],)); self.connection.execute("INSERT OR IGNORE INTO scenes(film_id,scene_id) VALUES (?,?)",identity[:2]); self.connection.execute("INSERT OR IGNORE INTO shots(film_id,scene_id,shot_id) VALUES (?,?,?)",identity)
            counter=self.connection.execute("SELECT COALESCE(MAX(revision),0)+1 AS next_revision, COALESCE(MAX(take_number),0)+1 AS next_take FROM takes WHERE film_id=? AND scene_id=? AND shot_id=?",identity).fetchone(); revision=counter["next_revision"]; take_number=counter["next_take"]; take_id=f"{identity[0]}__{identity[2]}_R{revision:03d}_TK{take_number:03d}"; timestamp=now()
            self.connection.execute("INSERT INTO takes (take_id,film_id,scene_id,shot_id,revision,take_number,status,progress,snapshot_json,parent_take_id,parent_rejection_reason,created_at,updated_at) VALUES (?,?,?,?,?,?, 'PENDING',0,?,?,?,?,?)",(take_id,*identity,revision,take_number,snapshot_json,parent_take_id,parent_reason,timestamp,timestamp)); self._event(take_id,None,"PENDING",0); return take_id
    def record_submission(self,take_id,job_id):
        if not nonempty_text(job_id): raise ValueError("Adapter returned an invalid job ID.")
        with self._transaction():
            row=self._row(take_id)
            if row["status"]!="PENDING": raise ValueError("Only PENDING takes may record submission.")
            self.connection.execute("UPDATE takes SET job_id=?,status='SUBMITTED',updated_at=? WHERE take_id=?",(job_id,now(),take_id)); self._event(take_id,job_id,"SUBMITTED",0)
    def record_submission_failure(self,take_id,error):
        with self._transaction():
            row=self._row(take_id)
            if row["status"]!="PENDING": raise ValueError("Only PENDING submissions may fail here.")
            self.connection.execute("UPDATE takes SET status='FAILED',error=?,updated_at=? WHERE take_id=?",(error,now(),take_id)); self._event(take_id,None,"FAILED",0,error)
    def record_update(self,take_id,update:GenerationUpdate):
        if update.state not in {"RUNNING","COMPLETED","FAILED"}: raise ValueError("Adapter returned an unsupported generation state.")
        if type(update.progress) is not int or not 0<=update.progress<=100: raise ValueError("Adapter progress must be an integer from 0 to 100.")
        if update.state=="COMPLETED":
            if update.progress!=100: raise ValueError("COMPLETED requires progress 100.")
            if not isinstance(update.output_metadata,dict) or not update.output_metadata: raise ValueError("COMPLETED requires nonempty output metadata.")
            if update.error is not None: raise ValueError("COMPLETED must not include an error.")
        elif update.output_metadata is not None: raise ValueError("Only COMPLETED may supply output metadata.")
        if update.state=="FAILED" and not nonempty_text(update.error): raise ValueError("FAILED requires an error description.")
        if update.state=="RUNNING" and update.error is not None: raise ValueError("RUNNING must not include an error.")
        output_json=dump(update.output_metadata) if update.output_metadata is not None else None
        with self._transaction():
            row=self._row(take_id)
            if row["status"] not in {"SUBMITTED","RUNNING"}: raise ValueError("Take is not awaiting generation updates.")
            if update.progress<row["progress"]: raise ValueError("Adapter progress must not move backwards.")
            self.connection.execute("UPDATE takes SET status=?,progress=?,output_json=?,error=?,updated_at=? WHERE take_id=?",(update.state,update.progress,output_json,update.error,now(),take_id)); self._event(take_id,row["job_id"],update.state,update.progress,update.error)

    def record_export(self, record):
        with self._transaction():
            timestamp=now()
            self.connection.execute(
                """INSERT INTO exports (export_id,take_id,media_index,kind,status,path,filename,bytes,sha256,message,created_at,updated_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(export_id) DO UPDATE SET status=excluded.status,path=excluded.path,filename=excluded.filename,bytes=excluded.bytes,sha256=excluded.sha256,message=excluded.message,updated_at=excluded.updated_at""",
                (record["export_id"],record["take_id"],record.get("media_index",0),record.get("kind"),record["status"],record.get("path"),record.get("filename"),int(record.get("bytes",0)),record.get("sha256"),record.get("message"),timestamp,timestamp))

    def find_export(self,take_id,media_index):
        with self._lock:
            row=self.connection.execute("SELECT * FROM exports WHERE take_id=? AND media_index=?",(take_id,media_index)).fetchone()
            return dict(row) if row else None

    def export_records(self,take_id):
        with self._lock:
            self._row(take_id)
            return [dict(row) for row in self.connection.execute("SELECT * FROM exports WHERE take_id=? ORDER BY media_index",(take_id,)).fetchall()]

    def film_exports(self,film_id):
        with self._lock:
            return [dict(row) for row in self.connection.execute("SELECT e.* FROM exports e JOIN takes t ON t.take_id=e.take_id WHERE t.film_id=? ORDER BY t.scene_id,t.shot_id,t.take_number,e.media_index",(film_id,)).fetchall()]

    def film_takes(self,film_id):
        with self._lock:
            return [self.get_take(row["take_id"]) for row in self.connection.execute("SELECT take_id FROM takes WHERE film_id=? ORDER BY scene_id,shot_id,take_number",(film_id,)).fetchall()]

    def director_review(self,take_id,decision,reason=None):
        if decision not in {"APPROVED","REJECTED"}: raise ValueError("Director decision must be APPROVED or REJECTED.")
        if decision=="REJECTED" and not nonempty_text(reason): raise ValueError("Director rejection requires a nonempty reason.")
        if decision=="APPROVED" and reason is not None: raise ValueError("Approval does not accept a rejection reason.")
        with self._transaction():
            row=self._row(take_id)
            if row["status"]!="COMPLETED": raise ValueError("Only COMPLETED takes await Director review.")
            self.connection.execute("UPDATE takes SET status=?,rejection_reason=?,updated_at=? WHERE take_id=?",(decision,reason,now(),take_id))
