from __future__ import annotations

import json
import threading
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any


class FakeComfyUI:
    """HTTP-only fake used for adapter contract testing. No AI/model execution."""

    def __init__(self, host: str = "127.0.0.1", port: int = 0):
        state = {"jobs": {}}

        class Handler(BaseHTTPRequestHandler):
            def _json(self, status: int, obj: Any) -> None:
                body = json.dumps(obj).encode()
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_POST(self):
                if self.path == "/upload/image":
                    length = int(self.headers.get("Content-Length", "0"))
                    self.rfile.read(length)
                    return self._json(200, {"name": "uploaded-input.png", "subfolder": "his_risen/HRF-MEX-001", "type": "input"})
                if self.path != "/prompt":
                    return self._json(404, {})
                length = int(self.headers.get("Content-Length", "0"))
                payload = json.loads(self.rfile.read(length).decode())
                prompt_id = str(uuid.uuid4())
                state["jobs"][prompt_id] = {"prompt": payload.get("prompt", {}), "polls": 0}
                return self._json(200, {"prompt_id": prompt_id})

            def do_GET(self):
                if self.path.startswith("/history/"):
                    prompt_id = self.path.rsplit("/", 1)[-1]
                    job = state["jobs"].get(prompt_id)
                    if not job:
                        return self._json(200, {})
                    job["polls"] += 1
                    if job["polls"] < 2:
                        return self._json(200, {prompt_id: {"outputs": {}}})
                    return self._json(200, {prompt_id: {"status": {"status_str": "success", "completed": True}, "outputs": {"9": {"videos": [{"filename": "mock-real-adapter.mp4", "subfolder": "", "type": "output"}]}}}})
                if self.path == "/system_stats":
                    return self._json(200, {"system": {"os": "fake"}})
                if self.path.startswith("/view"):
                    self.send_response(200)
                    body = b"FAKE MEDIA"
                    self.send_header("Content-Type", "application/octet-stream")
                    self.send_header("Content-Length", str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                    return
                return self._json(404, {})

            def log_message(self, fmt: str, *args: object) -> None:
                return

        self.server = ThreadingHTTPServer((host, port), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)

    @property
    def base_url(self) -> str:
        return f"http://{self.server.server_address[0]}:{self.server.server_address[1]}"

    def start(self):
        self.thread.start()

    def stop(self):
        self.server.shutdown()
        self.server.server_close()
