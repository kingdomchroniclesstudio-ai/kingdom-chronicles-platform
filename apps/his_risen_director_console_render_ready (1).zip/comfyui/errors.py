from __future__ import annotations


class ComfyUIError(RuntimeError):
    pass


class ComfyUIConnectionError(ComfyUIError):
    pass


class ComfyUITimeoutError(ComfyUIError):
    pass


class ComfyUIProtocolError(ComfyUIError):
    pass
