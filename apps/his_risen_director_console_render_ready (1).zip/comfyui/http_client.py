from __future__ import annotations

import json
import mimetypes
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from comfyui.errors import ComfyUIConnectionError, ComfyUIProtocolError, ComfyUITimeoutError


class ComfyUIHTTPClient:
    def __init__(self, base_url: str, timeout: float = 30.0, headers: dict[str, str] | None = None):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.headers = {"Accept": "application/json", **(headers or {})}

    def _request(self, method: str, path: str, data: bytes | None, headers: dict[str, str] | None = None, timeout: float | None = None) -> tuple[int, bytes]:
        req_headers = dict(self.headers)
        if headers:
            req_headers.update(headers)
        req = urllib.request.Request(self.base_url + path, data=data, method=method, headers=req_headers)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout if timeout is None else timeout) as response:
                return response.status, response.read()
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise ComfyUIProtocolError(f"ComfyUI HTTP {exc.code} for {path}: {body[:500]}") from exc
        except TimeoutError as exc:
            raise ComfyUITimeoutError(f"ComfyUI request timed out: {method} {path}") from exc
        except urllib.error.URLError as exc:
            raise ComfyUIConnectionError(f"Cannot connect to ComfyUI at {self.base_url}: {exc.reason}") from exc

    def _request_json(self, method: str, path: str, payload: dict[str, Any] | None = None, timeout: float | None = None) -> Any:
        data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
        _, raw = self._request(method, path, data, {"Content-Type": "application/json"} if data is not None else {}, timeout)
        try:
            return json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ComfyUIProtocolError(f"ComfyUI returned non-JSON from {path}") from exc

    def queue_prompt(self, prompt: dict[str, Any], client_id: str | None = None) -> dict[str, Any]:
        payload = {"prompt": prompt}
        if client_id:
            payload["client_id"] = client_id
        result = self._request_json("POST", "/prompt", payload)
        if not isinstance(result, dict) or not isinstance(result.get("prompt_id"), str) or not result["prompt_id"]:
            raise ComfyUIProtocolError("/prompt response missing prompt_id")
        return result

    def history(self, prompt_id: str) -> dict[str, Any]:
        result = self._request_json("GET", f"/history/{prompt_id}")
        if not isinstance(result, dict):
            raise ComfyUIProtocolError("/history response must be an object")
        return result

    def system_stats(self) -> dict[str, Any]:
        result = self._request_json("GET", "/system_stats")
        if not isinstance(result, dict):
            raise ComfyUIProtocolError("/system_stats response must be an object")
        return result

    def upload_file(self, file_path: Path, subfolder: str = "his_risen", folder_type: str = "input", overwrite: bool = True) -> dict[str, Any]:
        file_path = file_path.resolve()
        if not file_path.is_file():
            raise ComfyUIProtocolError(f"local upload file does not exist: {file_path}")
        boundary = "----HISRisenBoundary7d3f"
        mime = mimetypes.guess_type(file_path.name)[0] or "application/octet-stream"
        fields = [
            ("type", folder_type),
            ("subfolder", subfolder),
            ("overwrite", "true" if overwrite else "false"),
        ]
        chunks: list[bytes] = []
        for name, value in fields:
            chunks.extend([
                f"--{boundary}\r\n".encode(),
                f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode(),
                value.encode(),
                b"\r\n",
            ])
        chunks.extend([
            f"--{boundary}\r\n".encode(),
            f'Content-Disposition: form-data; name="image"; filename="{file_path.name}"\r\n'.encode(),
            f"Content-Type: {mime}\r\n\r\n".encode(),
            file_path.read_bytes(),
            b"\r\n",
            f"--{boundary}--\r\n".encode(),
        ])
        _, raw = self._request("POST", "/upload/image", b"".join(chunks), {"Content-Type": f"multipart/form-data; boundary={boundary}"})
        try:
            result = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ComfyUIProtocolError("/upload/image returned non-JSON") from exc
        if not isinstance(result, dict) or not isinstance(result.get("name"), str):
            raise ComfyUIProtocolError("/upload/image response missing name")
        return result

    def view_url(self, filename: str, subfolder: str = "", folder_type: str = "output") -> str:
        from urllib.parse import urlencode
        query = urlencode({"filename": filename, "subfolder": subfolder, "type": folder_type})
        return f"{self.base_url}/view?{query}"
