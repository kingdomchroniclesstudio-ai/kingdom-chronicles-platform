from __future__ import annotations

from typing import Any


def _kind_from_key(key: str) -> str | None:
    key = key.lower()
    if "video" in key:
        return "video"
    if "image" in key or key in {"gifs", "gif"}:
        return "image"
    if "audio" in key:
        return "audio"
    return None


def discover_outputs(history: dict[str, Any], view_url_factory=None) -> list[dict[str, Any]]:
    """Normalize ComfyUI history output descriptors without downloading media."""
    found: list[dict[str, Any]] = []

    def add_descriptor(desc: dict[str, Any], kind: str, node_id: str | None) -> None:
        filename = desc.get("filename")
        if not isinstance(filename, str) or not filename:
            return
        subfolder = desc.get("subfolder", "") if isinstance(desc.get("subfolder", ""), str) else ""
        folder_type = desc.get("type", "output") if isinstance(desc.get("type", "output"), str) else "output"
        item = {"kind": kind, "filename": filename, "subfolder": subfolder, "type": folder_type, "node_id": node_id}
        if view_url_factory:
            item["url"] = view_url_factory(filename, subfolder, folder_type)
        found.append(item)

    def visit(value: Any, node_id: str | None = None, key_hint: str | None = None) -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                child_node = node_id
                if node_id is None and str(key).isdigit():
                    child_node = str(key)
                kind = _kind_from_key(str(key))
                if kind and isinstance(child, list):
                    for item in child:
                        if isinstance(item, dict):
                            add_descriptor(item, kind, child_node)
                        else:
                            visit(item, child_node, str(key))
                else:
                    visit(child, child_node, str(key))
            return
        if isinstance(value, list):
            for child in value:
                visit(child, node_id, key_hint)
            return
        if not isinstance(value, str) or not value:
            return
        suffix = value.lower().split("?")[0]
        kind = _kind_from_key(key_hint or "")
        if kind is None:
            if suffix.endswith((".mp4", ".webm", ".mov", ".mkv")):
                kind = "video"
            elif suffix.endswith((".png", ".jpg", ".jpeg", ".gif", ".webp")):
                kind = "image"
            elif suffix.endswith((".wav", ".mp3", ".flac", ".ogg")):
                kind = "audio"
        if kind:
            found.append({"kind": kind, "filename": value, "subfolder": "", "type": "output", "node_id": node_id})

    visit(history)
    unique: list[dict[str, Any]] = []
    seen = set()
    for item in found:
        marker = (item["kind"], item["filename"], item.get("subfolder", ""), item.get("type", "output"), item.get("node_id"))
        if marker in seen:
            continue
        seen.add(marker)
        unique.append(item)
    return unique
