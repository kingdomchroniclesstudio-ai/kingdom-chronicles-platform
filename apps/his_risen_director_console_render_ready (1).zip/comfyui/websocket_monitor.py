from __future__ import annotations

import json
import time
import uuid
from typing import Any, Callable, Protocol
from urllib.parse import urlencode, urlsplit, urlunsplit

from comfyui.errors import ComfyUIConnectionError, ComfyUIProtocolError, ComfyUITimeoutError


class WebSocketLike(Protocol):
    def connect(self, url: str, timeout: float | None = None) -> None: ...
    def recv(self) -> str | bytes: ...
    def close(self) -> None: ...


def websocket_url(base_url: str, client_id: str) -> str:
    parsed = urlsplit(base_url)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    query = urlencode({"clientId": client_id})
    return urlunsplit((scheme, parsed.netloc, "/ws", query, ""))


def parse_progress_event(message: dict[str, Any], prompt_id: str) -> tuple[str, int] | None:
    kind = message.get("type")
    data = message.get("data")
    if not isinstance(data, dict) or data.get("prompt_id") not in (None, prompt_id):
        return None
    if kind == "progress":
        value = data.get("value")
        maximum = data.get("max", 0)
        if isinstance(value, int) and isinstance(maximum, int) and maximum > 0:
            return "RUNNING", max(0, min(99, round(value / maximum * 100)))
    if kind == "executing" and data.get("node") is None and data.get("prompt_id") == prompt_id:
        return "COMPLETED", 100
    if kind == "execution_error" and data.get("prompt_id") == prompt_id:
        return "FAILED", 0
    return None


class ComfyUIWebSocketMonitor:
    def __init__(self, base_url: str, socket_factory: Callable[[], WebSocketLike] | None = None, connect_timeout: float = 10.0):
        self.base_url = base_url
        self.connect_timeout = connect_timeout
        self._socket_factory = socket_factory or self._default_factory

    @staticmethod
    def _default_factory() -> WebSocketLike:
        try:
            import websocket
        except ImportError as exc:
            raise ComfyUIConnectionError("websocket-client is required for real ComfyUI WebSocket monitoring") from exc
        return websocket.WebSocket()

    def wait_for_completion(self, prompt_id: str, timeout: float) -> list[dict[str, Any]]:
        client_id = str(uuid.uuid4())
        ws = self._socket_factory()
        url = websocket_url(self.base_url, client_id)
        events: list[dict[str, Any]] = []
        started = time.monotonic()
        try:
            ws.connect(url, timeout=self.connect_timeout)
            while True:
                if time.monotonic() - started >= timeout:
                    raise ComfyUITimeoutError(f"ComfyUI WebSocket timed out waiting for {prompt_id}")
                try:
                    raw = ws.recv()
                except TimeoutError as exc:
                    raise ComfyUITimeoutError(f"ComfyUI WebSocket timed out waiting for {prompt_id}") from exc
                if isinstance(raw, bytes):
                    continue
                try:
                    message = json.loads(raw)
                except json.JSONDecodeError as exc:
                    raise ComfyUIProtocolError("ComfyUI WebSocket emitted invalid JSON") from exc
                if not isinstance(message, dict):
                    continue
                if message.get("data", {}).get("prompt_id") != prompt_id:
                    continue
                events.append(message)
                parsed = parse_progress_event(message, prompt_id)
                if parsed and parsed[0] in {"COMPLETED", "FAILED"}:
                    return events
        except (ComfyUIConnectionError, ComfyUITimeoutError, ComfyUIProtocolError):
            raise
        except OSError as exc:
            raise ComfyUIConnectionError(f"ComfyUI WebSocket connection failed: {exc}") from exc
        finally:
            try:
                ws.close()
            except Exception:
                pass
