from __future__ import annotations
from abc import ABC,abstractmethod
from dataclasses import dataclass
from typing import Any
@dataclass(frozen=True)
class GenerationUpdate:
    state:str
    progress:int
    output_metadata:dict[str,Any]|None=None
    error:str|None=None
class GenerationAdapter(ABC):
    @abstractmethod
    def submit(self,request:dict[str,Any],client_request_id:str)->str: raise NotImplementedError
    @abstractmethod
    def poll(self,job_id:str)->GenerationUpdate: raise NotImplementedError
