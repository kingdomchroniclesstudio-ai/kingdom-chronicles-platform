from __future__ import annotations

import argparse
import hashlib
import os
import sqlite3
import tempfile
from datetime import datetime, timezone
from pathlib import Path


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _integrity_check(path: Path) -> None:
    connection = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=15)
    try:
        result = connection.execute("PRAGMA integrity_check").fetchone()
        if not result or result[0] != "ok":
            raise ValueError(f"SQLite integrity check failed: {result[0] if result else 'no result'}")
    finally:
        connection.close()


def backup_database(source: Path, backup_dir: Path, keep: int = 10) -> Path:
    source = source.resolve()
    backup_dir = backup_dir.resolve()
    if not source.is_file():
        raise FileNotFoundError(f"SQLite database does not exist: {source}")
    if keep < 1:
        raise ValueError("backup retention must be at least one")
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    destination = backup_dir / f"controller-{stamp}.sqlite3"
    fd, temp_name = tempfile.mkstemp(prefix=".controller-backup-", suffix=".sqlite3", dir=backup_dir)
    os.close(fd)
    temporary = Path(temp_name)
    try:
        src = sqlite3.connect(f"file:{source}?mode=ro", uri=True, timeout=15)
        dst = sqlite3.connect(temporary, timeout=15)
        try:
            src.backup(dst)
            dst.commit()
        finally:
            dst.close()
            src.close()
        _integrity_check(temporary)
        os.replace(temporary, destination)
        digest = sha256_file(destination)
        manifest_tmp = destination.with_suffix(destination.suffix + ".sha256.tmp")
        manifest_tmp.write_text(f"{digest}  {destination.name}\n", encoding="utf-8")
        os.replace(manifest_tmp, destination.with_suffix(destination.suffix + ".sha256"))
    finally:
        temporary.unlink(missing_ok=True)
    backups = sorted(backup_dir.glob("controller-*.sqlite3"), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in backups[keep:]:
        old.unlink(missing_ok=True)
        old.with_suffix(old.suffix + ".sha256").unlink(missing_ok=True)
    return destination


def verify_database(backup: Path) -> str:
    backup = backup.resolve()
    if not backup.is_file():
        raise FileNotFoundError(backup)
    manifest = backup.with_suffix(backup.suffix + ".sha256")
    if not manifest.is_file():
        raise ValueError("backup checksum manifest is missing")
    expected, filename = manifest.read_text(encoding="utf-8").strip().split(maxsplit=1)
    if filename != backup.name:
        raise ValueError("backup checksum manifest filename does not match")
    actual = sha256_file(backup)
    if actual != expected:
        raise ValueError("backup SHA-256 verification failed")
    _integrity_check(backup)
    return actual


def restore_database(backup: Path, destination: Path, *, confirm_stopped: bool = False) -> None:
    if not confirm_stopped:
        raise ValueError("restore requires confirm_stopped=True; stop the controller before replacing its live database")
    backup = backup.resolve()
    destination = destination.resolve()
    verify_database(backup)
    destination.parent.mkdir(parents=True, exist_ok=True)
    # Preserve the current live database before replacing it, when one exists.
    if destination.is_file():
        backup_database(destination, destination.parent / "pre-restore-backups", keep=5)
    fd, temp_name = tempfile.mkstemp(prefix=".controller-restore-", suffix=".sqlite3", dir=destination.parent)
    os.close(fd)
    temporary = Path(temp_name)
    try:
        src = sqlite3.connect(f"file:{backup}?mode=ro", uri=True, timeout=15)
        dst = sqlite3.connect(temporary, timeout=15)
        try:
            src.backup(dst)
            dst.commit()
        finally:
            dst.close()
            src.close()
        _integrity_check(temporary)
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="Back up, verify or restore the HIS RISEN controller SQLite database.")
    parser.add_argument("action", choices=("backup", "verify", "restore"))
    parser.add_argument("--database", type=Path, default=None)
    parser.add_argument("--backup-dir", type=Path, default=None)
    parser.add_argument("--backup", type=Path, default=None)
    parser.add_argument("--keep", type=int, default=10)
    parser.add_argument("--confirm-stopped", action="store_true", help="required for restore; stop the Director Console first")
    args = parser.parse_args()
    data_root_raw = os.environ.get("HRF_DATA_DIR", "").strip()
    data_root = Path(data_root_raw).expanduser().resolve() if data_root_raw else Path(__file__).resolve().parents[1]
    database = args.database.resolve() if args.database else data_root / "storage" / "controller.sqlite3"
    backup_dir = args.backup_dir.resolve() if args.backup_dir else data_root / "backups"
    if args.action == "backup":
        path = backup_database(database, backup_dir, keep=args.keep)
        print(f"BACKUP_CREATED {path}")
        print(f"SHA256 {verify_database(path)}")
    elif args.action == "verify":
        if not args.backup:
            parser.error("verify requires --backup")
        print(f"BACKUP_VERIFIED {args.backup.resolve()}")
        print(f"SHA256 {verify_database(args.backup)}")
    else:
        if not args.backup:
            parser.error("restore requires --backup")
        restore_database(args.backup, database, confirm_stopped=args.confirm_stopped)
        print(f"RESTORE_COMPLETED {database}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
