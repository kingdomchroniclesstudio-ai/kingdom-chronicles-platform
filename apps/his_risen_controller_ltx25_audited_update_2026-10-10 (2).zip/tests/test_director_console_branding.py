import unittest

from director_console import APP_NAME, INDEX_HTML


class StudioBrandingTests(unittest.TestCase):
    def test_application_identity_and_control_room_labels(self):
        self.assertEqual(APP_NAME, "HIS RISEN STUDIOS")
        self.assertIn("<title>HIS RISEN STUDIOS</title>", INDEX_HTML)
        self.assertIn("Film Production Control Room", INDEX_HTML)
        self.assertIn("Secure access to the HIS RISEN STUDIOS production workspace.", INDEX_HTML)

    def test_existing_director_controls_are_preserved(self):
        for marker in (
            "Refresh",
            "LTX Update Monitor",
            "RUN ONE MOCK SHOT",
            "Director Command",
            '<video class="video"',
            "APPROVE",
            "REJECT",
            "async function approve(",
            "async function reject(",
        ):
            with self.subTest(marker=marker):
                self.assertIn(marker, INDEX_HTML)


if __name__ == "__main__":
    unittest.main()
