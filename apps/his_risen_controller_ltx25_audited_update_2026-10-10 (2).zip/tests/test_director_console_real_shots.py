from __future__ import annotations

import json
import tempfile
import threading
import unittest
import uuid
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from director_console import DirectorConsole, Handler, INDEX_HTML


class _FakeConnection:
    def execute(self, *args, **kwargs):
        return []


class _FakeStore:
    def __init__(self):
        self.connection = _FakeConnection()
        self._lock = threading.RLock()
        self.requests = {}

    def get_submission_request(self, request_id):
        return self.requests.get(request_id)


class _FakeHTTP:
    def _request_json(self, method, path, payload=None, timeout=None):
        if path == "/system_stats":
            return {"devices": [{"name": "NVIDIA A100", "type": "cuda", "vram_total": 80 * 1024 ** 3}]}
        if path == "/object_info":
            return {"TestLTXNode": {"input": {"required": {"prompt": ["STRING"]}}}}
        raise AssertionError(f"Unexpected ComfyUI preflight request: {method} {path}")


class MockComfyUIAdapter:
    pass


class RealComfyUIAdapter:
    def __init__(self):
        self.http = _FakeHTTP()


class _FakeController:
    def __init__(self, root: Path):
        self.adapter = MockComfyUIAdapter()
        self.root = root
        self.store = _FakeStore()
        self.auto_export_approved = False
        self.generated = []
        self.takes = {}

    def generate(self, specification, submission_request_id=None, submission_payload_hash=None, return_created=False):
        if submission_request_id:
            existing = self.store.get_submission_request(submission_request_id)
            if existing:
                if existing["payload_hash"] != submission_payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.takes[existing["take_id"]]
                return (take, False) if return_created else take
        self.generated.append(json.loads(json.dumps(specification)))
        take = {
            "take_id": f"TAKE-{len(self.generated):03d}",
            "film_id": specification["film_id"],
            "scene_id": specification["scene_id"],
            "shot_id": specification["shot_id"],
            "status": "SUBMITTED",
        }
        self.takes[take["take_id"]] = take
        if submission_request_id:
            self.store.requests[submission_request_id] = {
                "request_id": submission_request_id,
                "payload_hash": submission_payload_hash,
                "take_id": take["take_id"],
            }
        return (take, True) if submission_request_id and return_created else take

    def get_take(self, take_id):
        return self.takes[take_id]


class RealShotSubmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="his-risen-real-shot-test-")
        self.root = Path(self.temp.name)
        (self.root / "config").mkdir()
        (self.root / "workflows" / "real").mkdir(parents=True)
        self.template = {
            "film_id": "HRF-MEX-001",
            "scene_id": "SC016",
            "shot_id": "SC016-SH004",
            "shot_type": "SINGLE-SHOT",
            "character_ids": ["CHR-MOS"],
            "voice_profile_ids": ["VP-MOS"],
            "environment": "Night shoreline.",
            "action": "Moses raises his staff.",
            "camera": "Medium frontal shot.",
            "lighting": "Natural moonlight.",
            "audio": "Wind and distant water.",
            "dialogue": [],
            "continuity": "Keep Moses' approved appearance and staff.",
            "duration": 8,
            "reference_assets": [],
            "status": "READY",
            "resolution": "1440p",
            "aspect_ratio": "16:9",
            "frame_rate": 24,
            "quality_preset": "LTX-2.5 Fast workhorse",
        }
        (self.root / "config" / "test_shot.json").write_text(json.dumps(self.template), encoding="utf-8")
        self.workflow_path = "workflows/real/t2v.api.json"
        self.mapping_path = "workflows/real/t2v.mapping.json"
        (self.root / self.workflow_path).write_text(
            json.dumps({"1": {"class_type": "TestLTXNode", "inputs": {"prompt": ""}}}),
            encoding="utf-8",
        )
        (self.root / self.mapping_path).write_text(
            json.dumps({"prompt": {"node_id": "1", "input": "prompt", "required": True}}),
            encoding="utf-8",
        )
        self.presets_path = self.root / "workflows" / "real_presets.json"
        self.presets_path.write_text(json.dumps({
            "L25-T2V-SINGLE": {
                "ready": False,
                "workflow_file": self.workflow_path,
                "mapping_file": self.mapping_path,
            }
        }), encoding="utf-8")
        self.controller = _FakeController(self.root)
        self.console = DirectorConsole(self.controller, "123456", self.root)
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.server.console = self.console
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.server.server_address[1]}"
        self.origin = self.base
        self.cookie = f"hrf_director_session={self.console.sessions.create()}"

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        self.console.stop()
        self.temp.cleanup()

    def request(self, method, path, payload=None, *, auth=True, origin=True):
        headers = {"Content-Type": "application/json"}
        if auth:
            headers["Cookie"] = self.cookie
        if origin:
            headers["Origin"] = self.origin
        data = None if payload is None else json.dumps(payload).encode("utf-8")
        req = Request(self.base + path, data=data, headers=headers, method=method)
        try:
            with urlopen(req, timeout=3) as response:
                return response.status, json.loads(response.read().decode("utf-8"))
        except HTTPError as exc:
            return exc.code, json.loads(exc.read().decode("utf-8"))

    def test_new_shot_ui_has_explicit_cost_confirmation_and_safe_gate(self):
        self.assertIn("New real shot submission", INDEX_HTML)
        self.assertIn("confirmRealCost", INDEX_HTML)
        self.assertIn("submitRealShot", INDEX_HTML)
        self.assertIn("Mock Mode", INDEX_HTML)

    def test_shot_template_and_readiness_require_authenticated_session(self):
        self.assertEqual(self.request("GET", "/api/shot-template", auth=False)[0], 401)
        self.assertEqual(self.request("GET", "/api/generation-readiness", auth=False)[0], 401)
        status, template = self.request("GET", "/api/shot-template")
        self.assertEqual(status, 200)
        self.assertEqual(template["data"]["generation_mode"], "TEXT_TO_VIDEO")

    def test_server_requires_explicit_cost_acknowledgement(self):
        payload = {
            "request_id": str(uuid.uuid4()),
            "specification": self.template,
            "cost_acknowledged": False,
        }
        status, result = self.request("POST", "/api/shots/generate", payload)
        self.assertEqual(status, 409)
        self.assertIn("cost acknowledgement", result["error"])
        self.assertEqual(self.controller.generated, [])

    def test_mock_mode_refuses_real_shot_submission_without_calling_controller(self):
        request_id = str(uuid.uuid4())
        payload = {"request_id": request_id, "specification": self.template, "cost_acknowledged": True}
        status, result = self.request("POST", "/api/shots/generate", payload)
        self.assertEqual(status, 409)
        self.assertFalse(result["ok"])
        self.assertEqual(self.controller.generated, [])
        status, readiness = self.request("GET", "/api/generation-readiness")
        self.assertEqual(status, 200)
        self.assertFalse(readiness["data"]["enabled"])
        self.assertTrue(readiness["data"]["mock_mode"])

    def test_missing_or_untrusted_origin_is_rejected(self):
        payload = {"request_id": str(uuid.uuid4()), "specification": self.template}
        self.assertEqual(self.request("POST", "/api/shots/generate", payload, origin=False)[0], 403)
        req = Request(
            self.base + "/api/shots/generate",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Cookie": self.cookie,
                "Origin": "https://attacker.invalid",
            },
            method="POST",
        )
        try:
            urlopen(req, timeout=3)
            status = 200
        except HTTPError as exc:
            status = exc.code
        self.assertEqual(status, 403)
        self.assertEqual(self.controller.generated, [])

    def test_real_t2v_preflight_and_idempotent_submission(self):
        self.controller.adapter = RealComfyUIAdapter()
        cfg = json.loads(self.presets_path.read_text(encoding="utf-8"))
        cfg["L25-T2V-SINGLE"]["ready"] = True
        self.presets_path.write_text(json.dumps(cfg), encoding="utf-8")

        status, readiness = self.request("GET", "/api/generation-readiness")
        self.assertEqual(status, 200)
        self.assertTrue(readiness["data"]["enabled"])
        self.assertEqual(readiness["data"]["gpu_vram_gib"], 80)

        request_id = str(uuid.uuid4())
        spec = dict(self.template)
        spec["generation_mode"] = "TEXT_TO_VIDEO"
        payload = {"request_id": request_id, "specification": spec, "cost_acknowledged": True}
        status, first = self.request("POST", "/api/shots/generate", payload)
        self.assertEqual(status, 202)
        self.assertTrue(first["data"]["created"])
        self.assertEqual(len(self.controller.generated), 1)

        status, retry = self.request("POST", "/api/shots/generate", payload)
        self.assertEqual(status, 202)
        self.assertTrue(retry["data"]["reused"])
        self.assertEqual(len(self.controller.generated), 1)

        changed = dict(spec)
        changed["action"] = "A different action."
        status, conflict = self.request(
            "POST",
            "/api/shots/generate",
            {"request_id": request_id, "specification": changed, "cost_acknowledged": True},
        )
        self.assertEqual(status, 409)
        self.assertEqual(len(self.controller.generated), 1)

    def test_real_submission_rejects_non_t2v_and_invalid_specification(self):
        self.controller.adapter = RealComfyUIAdapter()
        cfg = json.loads(self.presets_path.read_text(encoding="utf-8"))
        cfg["L25-T2V-SINGLE"]["ready"] = True
        self.presets_path.write_text(json.dumps(cfg), encoding="utf-8")
        invalid = dict(self.template)
        invalid["generation_mode"] = "FIRST_LAST_FRAME"
        status, result = self.request(
            "POST",
            "/api/shots/generate",
            {"request_id": str(uuid.uuid4()), "specification": invalid, "cost_acknowledged": True},
        )
        self.assertEqual(status, 409)
        self.assertEqual(self.controller.generated, [])


if __name__ == "__main__":
    unittest.main()
