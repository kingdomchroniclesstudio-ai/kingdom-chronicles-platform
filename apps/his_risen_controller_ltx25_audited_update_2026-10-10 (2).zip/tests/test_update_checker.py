from __future__ import annotations
import json, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from updates.check import SOURCES
class UpdateCheckerPolicyTests(unittest.TestCase):
 def test_update_sources_are_official_and_no_auto_install(self):
  data=json.loads((ROOT/"workflows"/"ltx25_capabilities.json").read_text())
  policy=data["update_policy"]
  self.assertFalse(policy["automatic_install"]); self.assertFalse(policy["automatic_model_download"]); self.assertFalse(policy["automatic_gpu_job"])
  self.assertTrue(all(url.startswith("https://") for url in SOURCES.values()))
 def test_new_specialists_have_status_and_director_gate(self):
  data=json.loads((ROOT/"workflows"/"ltx25_capabilities.json").read_text())
  for key in ("MOTION_TRANSFER","LAYOUT_TO_RENDER","NATIVE_HDR_EXR_I2V","SDR_TO_HDR","ALPHA_GEN","CLEAN_PLATE","DEBLUR","RESTORE"):
   self.assertIn(key,data["production_profiles"]); self.assertTrue(data["production_profiles"][key]["requires_director_authorization"])
 def test_diffusers_is_not_default_route(self):
  data=json.loads((ROOT/"workflows"/"ltx25_capabilities.json").read_text())
  self.assertIn("SEPARATE_EXPERIMENTAL_ROUTE",data["integration_routes"]["diffusers"]["status"])
if __name__=="__main__": unittest.main()
