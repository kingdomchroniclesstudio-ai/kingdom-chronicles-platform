from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from updates.check import SOURCES, check_updates


class UpdateCheckerPolicyTests(unittest.TestCase):
    def test_update_sources_are_official_and_no_auto_install(self):
        data = json.loads((ROOT / "workflows" / "ltx25_capabilities.json").read_text())
        policy = data["update_policy"]
        self.assertFalse(policy["automatic_install"])
        self.assertFalse(policy["automatic_model_download"])
        self.assertFalse(policy["automatic_gpu_job"])
        self.assertTrue(all(url.startswith("https://") for url in SOURCES.values()))

    def test_new_specialists_have_status_and_director_gate(self):
        data = json.loads((ROOT / "workflows" / "ltx25_capabilities.json").read_text())
        for key in ("MOTION_TRANSFER", "LAYOUT_TO_RENDER", "NATIVE_HDR_EXR_I2V", "SDR_TO_HDR", "ALPHA_GEN", "CLEAN_PLATE", "DEBLUR", "RESTORE"):
            self.assertIn(key, data["production_profiles"])
            self.assertTrue(data["production_profiles"][key]["requires_director_authorization"])

    def test_diffusers_is_not_default_route(self):
        data = json.loads((ROOT / "workflows" / "ltx25_capabilities.json").read_text())
        self.assertIn("SEPARATE_EXPERIMENTAL_ROUTE", data["integration_routes"]["diffusers"]["status"])

    def test_release_metadata_is_exposed_and_first_check_is_not_claimed_as_update(self):
        root = Path(tempfile.mkdtemp())
        (root / "workflows").mkdir()
        (root / "workflows" / "ltx25_capabilities.json").write_text(json.dumps({"manifest_version": "test", "model_family": "LTX-2.5"}))
        release = json.dumps({"tag_name": "v9.9.9", "published_at": "2026-10-01T00:00:00Z", "html_url": "https://github.com/Lightricks/LTX-2/releases/tag/v9.9.9", "body": "notes"}).encode()
        hf = json.dumps({"sha": "abc123", "lastModified": "2026-10-01T00:00:00Z"}).encode()

        def fake_request(url, timeout):
            if "api.github.com" in url:
                return 200, release, "application/json"
            if "huggingface.co/api/models" in url:
                return 200, hf, "application/json"
            return 200, b"docs", "text/html"

        with patch("updates.check._request", side_effect=fake_request):
            result = check_updates(root)
        self.assertEqual(result["controller_update_check"], "metadata_discovery_only_no_changes_applied")
        self.assertFalse(result["automatic_install"])
        self.assertFalse(result["manifest_modified"])
        release_result = next(x for x in result["sources"] if x["source"] == "ltx_github_releases")
        self.assertEqual(release_result["release"]["tag_name"], "v9.9.9")
        self.assertEqual(release_result["change_status"], "first_observation_needs_manual_baseline")
        self.assertTrue((root / "storage" / "update_check_state.json").exists())

    def test_failed_source_is_reported_without_failing_whole_check(self):
        root = Path(tempfile.mkdtemp())
        (root / "workflows").mkdir()
        (root / "workflows" / "ltx25_capabilities.json").write_text(json.dumps({"manifest_version": "test", "model_family": "LTX-2.5"}))
        def fake_request(url, timeout):
            if "api.github.com" in url:
                raise TimeoutError("simulated timeout")
            return 200, b"docs", "text/html"
        with patch("updates.check._request", side_effect=fake_request):
            result = check_updates(root)
        release_result = next(x for x in result["sources"] if x["source"] == "ltx_github_releases")
        self.assertFalse(release_result["reachable"])
        self.assertIn("TimeoutError", release_result["error"])


class ReleaseFallbackAndBaselineTests(unittest.TestCase):
    def test_seed_baseline_matches_observed_metadata(self):
        import hashlib
        state = json.loads((ROOT / "storage" / "update_check_state.json").read_text(encoding="utf-8"))
        release = state["sources"]["ltx_github_releases"]
        model = state["sources"]["ltx_diffusers_model"]
        self.assertEqual(release["tag_name"], "v1.5.0")
        self.assertEqual(release["fingerprint"], hashlib.sha256(b"v1.5.0").hexdigest())
        self.assertEqual(model["revision"], "4791a1100e0cf97f7ed5c55c12dd71dce13f9dd3")
        self.assertEqual(model["last_modified"], "2026-10-22T08:58:38.000Z")
        self.assertIn("metadata baseline only", state["note"].lower())

    def test_rate_limit_uses_official_atom_fallback_without_false_update(self):
        import shutil
        import urllib.error
        root = Path(tempfile.mkdtemp())
        (root / "workflows").mkdir()
        shutil.copyfile(ROOT / "workflows" / "ltx25_capabilities.json", root / "workflows" / "ltx25_capabilities.json")
        (root / "storage").mkdir()
        shutil.copyfile(ROOT / "storage" / "update_check_state.json", root / "storage" / "update_check_state.json")
        feed = (
            b'<?xml version="1.0" encoding="utf-8"?>'
            b'<feed xmlns="http://www.w3.org/2005/Atom"><entry><title>v1.5.0</title>'
            b'<id>https://github.com/Lightricks/LTX-2/releases/tag/v1.5.0</id>'
            b'<published>2026-10-18T17:41:36Z</published>'
            b'<link rel="alternate" href="https://github.com/Lightricks/LTX-2/releases/tag/v1.5.0"/>'
            b'</entry></feed>'
        )
        hf = json.dumps({"sha": "4791a1100e0cf97f7ed5c55c12dd71dce13f9dd3",
                         "lastModified": "2026-10-22T08:58:38.000Z"}).encode()
        class FakeResponse:
            def __init__(self, body, content_type):
                self.status = 200
                self.body = body
                self.headers = {"Content-Type": content_type}
            def __enter__(self):
                return self
            def __exit__(self, *args):
                return False
            def read(self, limit):
                return self.body[:limit]
        def fake_urlopen(request, timeout):
            url = getattr(request, "full_url", str(request))
            if url == SOURCES["ltx_github_releases"]:
                raise urllib.error.HTTPError(url, 403, "rate limit exceeded", None, None)
            if url == "https://github.com/Lightricks/LTX-2/releases.atom":
                return FakeResponse(feed, "application/atom+xml")
            if url == SOURCES["ltx_diffusers_model"]:
                return FakeResponse(hf, "application/json")
            return FakeResponse(b"official docs", "text/html")
        with patch("updates.check.urllib.request.urlopen", side_effect=fake_urlopen):
            result = check_updates(root)
        release = next(x for x in result["sources"] if x["source"] == "ltx_github_releases")
        model = next(x for x in result["sources"] if x["source"] == "ltx_diffusers_model")
        self.assertTrue(release["reachable"])
        self.assertEqual(release["fallback_used"], "official GitHub releases Atom feed")
        self.assertEqual(release["change_status"], "no_change_since_last_check")
        self.assertEqual(model["change_status"], "no_change_since_last_check")
        self.assertEqual(result["change_candidates_requiring_manual_review"], 0)
        self.assertFalse(result["automatic_install"])
        self.assertFalse(result["downloads_started"])
        self.assertFalse(result["gpu_jobs_started"])


if __name__ == "__main__":
    unittest.main()
