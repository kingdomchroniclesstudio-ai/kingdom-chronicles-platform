from __future__ import annotations

import json
import os
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from config.bootstrap import build_controller
from config.data_paths import resolve_data_root
from updates.check import check_updates

ROOT = Path(__file__).resolve().parents[1]


class PersistentDataRootTests(unittest.TestCase):
    def _project_copy(self, parent: Path) -> Path:
        project = parent / "project"
        shutil.copytree(ROOT, project, ignore=shutil.ignore_patterns("*.sqlite3", "__pycache__", "*.pyc"))
        return project

    def test_hrf_data_dir_moves_database_and_export_workspace_to_mounted_volume(self):
        with tempfile.TemporaryDirectory(prefix="his-risen-data-root-") as folder:
            parent = Path(folder)
            project = self._project_copy(parent)
            data_root = parent / "mounted-volume"
            with mock.patch.dict(os.environ, {"HRF_DATA_DIR": str(data_root)}):
                controller = build_controller(project, backend="mock")
                try:
                    self.assertTrue((data_root / "storage" / "controller.sqlite3").is_file())
                    self.assertEqual(
                        controller.export_manager.workspace_root,
                        (data_root / "outputs" / "production").resolve(),
                    )
                    self.assertFalse((project / "storage" / "controller.sqlite3").exists())
                finally:
                    controller.close()

    def test_hrf_data_dir_must_be_absolute(self):
        with mock.patch.dict(os.environ, {"HRF_DATA_DIR": "relative-data"}):
            with self.assertRaisesRegex(ValueError, "absolute path"):
                resolve_data_root(ROOT)

    def test_updater_observation_cache_can_use_the_same_persistent_root(self):
        with tempfile.TemporaryDirectory(prefix="his-risen-updater-data-") as folder:
            parent = Path(folder)
            project = self._project_copy(parent)
            data_root = parent / "mounted-volume"
            (project / "workflows" / "ltx25_capabilities.json").write_text(
                json.dumps({"manifest_version": "test", "model_family": "LTX-2.5"}),
                encoding="utf-8",
            )

            def fake_request(url: str, timeout: float):
                if "api.github.com" in url:
                    body = json.dumps({"tag_name": "v-test", "published_at": "2026-11-01T00:00:00Z", "html_url": "https://example.invalid", "body": "test"}).encode()
                    return 200, body, "application/json"
                if "huggingface.co/api/models" in url:
                    body = json.dumps({"sha": "test-revision", "lastModified": "2026-11-01T00:00:00Z"}).encode()
                    return 200, body, "application/json"
                return 200, b"documentation", "text/html"

            with mock.patch("updates.check._request", side_effect=fake_request):
                check_updates(project, state_root=data_root)
            self.assertTrue((data_root / "storage" / "update_check_observations.json").is_file())
            self.assertFalse((project / "storage" / "update_check_observations.json").exists())


if __name__ == "__main__":
    unittest.main()
