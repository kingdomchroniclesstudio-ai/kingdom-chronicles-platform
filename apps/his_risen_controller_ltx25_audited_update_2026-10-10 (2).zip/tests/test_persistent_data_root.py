from __future__ import annotations

import json
import os
import shutil
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from config.bootstrap import build_controller
from config.data_paths import resolve_data_root
from storage.backup import backup_database, restore_database, verify_database, sha256_file
from updates.check import check_updates

ROOT = Path(__file__).resolve().parents[1]


class PersistentDataRootTests(unittest.TestCase):
    def _project_copy(self, parent: Path) -> Path:
        project = parent / "project"
        shutil.copytree(ROOT, project, ignore=shutil.ignore_patterns("*.sqlite3", "__pycache__", "*.pyc", "backups"))
        return project

    def test_hrf_data_dir_moves_database_exports_and_reference_assets_to_mounted_volume(self):
        with tempfile.TemporaryDirectory(prefix="his-risen-data-root-") as folder:
            parent = Path(folder)
            project = self._project_copy(parent)
            data_root = parent / "mounted-volume"
            assets = data_root / "assets"
            assets.mkdir(parents=True)
            (assets / "moses-reference.png").write_bytes(b"test-reference-image")
            spec = json.loads((project / "config" / "test_shot.json").read_text())
            spec["reference_assets"] = [{"asset_id":"REF-MOSES-01","kind":"image","path":"assets/moses-reference.png"}]
            with mock.patch.dict(os.environ, {"HRF_DATA_DIR": str(data_root)}):
                controller = build_controller(project, backend="mock")
                try:
                    self.assertTrue((data_root / "storage" / "controller.sqlite3").is_file())
                    self.assertEqual(controller.export_manager.workspace_root,(data_root / "outputs" / "production").resolve())
                    self.assertEqual(controller.asset_root,data_root.resolve())
                    take=controller.generate(spec)
                    saved=take["snapshot"]["profiles"]["reference_assets"][0]
                    self.assertEqual(saved["path"],"assets/moses-reference.png")
                    self.assertFalse((project / "storage" / "controller.sqlite3").exists())
                finally:
                    controller.close()

    def test_hrf_data_dir_must_be_absolute(self):
        with mock.patch.dict(os.environ, {"HRF_DATA_DIR": "relative-data"}):
            with self.assertRaisesRegex(ValueError, "absolute path"):
                resolve_data_root(ROOT)

    def test_updater_observation_cache_can_use_the_same_persistent_root(self):
        with tempfile.TemporaryDirectory(prefix="his-risen-updater-data-") as folder:
            parent = Path(folder)
            project = self._project_copy(parent)
            data_root = parent / "mounted-volume"
            (project / "workflows" / "ltx25_capabilities.json").write_text(json.dumps({"manifest_version":"test","model_family":"LTX-2.5"}),encoding="utf-8")
            def fake_request(url: str, timeout: float):
                if "api.github.com" in url:
                    return 200, json.dumps({"tag_name":"v-test","published_at":"2026-11-01T00:00:00Z","html_url":"https://example.invalid","body":"test"}).encode(), "application/json"
                if "huggingface.co/api/models" in url:
                    return 200, json.dumps({"sha":"test-revision","lastModified":"2026-11-01T00:00:00Z"}).encode(), "application/json"
                return 200, b"documentation", "text/html"
            with mock.patch("updates.check._request", side_effect=fake_request):
                check_updates(project, state_root=data_root)
            self.assertTrue((data_root / "storage" / "update_check_observations.json").is_file())
            self.assertFalse((project / "storage" / "update_check_observations.json").exists())


class SQLiteBackupTests(unittest.TestCase):
    def _db(self, path: Path, value: str) -> None:
        connection=sqlite3.connect(path)
        try:
            connection.execute("CREATE TABLE IF NOT EXISTS proof (value TEXT NOT NULL)")
            connection.execute("DELETE FROM proof")
            connection.execute("INSERT INTO proof(value) VALUES (?)",(value,))
            connection.commit()
        finally:
            connection.close()

    def test_backup_verify_and_restore_round_trip(self):
        with tempfile.TemporaryDirectory(prefix="his-risen-backup-") as folder:
            root=Path(folder); live=root/"controller.sqlite3"; backups=root/"backups"
            self._db(live,"before")
            backup=backup_database(live,backups,keep=3)
            digest=verify_database(backup)
            self._db(live,"after")
            with self.assertRaisesRegex(ValueError,"confirm_stopped"):
                restore_database(backup,live)
            restore_database(backup,live,confirm_stopped=True)
            connection=sqlite3.connect(live)
            try:
                value=connection.execute("SELECT value FROM proof").fetchone()[0]
            finally:
                connection.close()
            self.assertEqual(value,"before")
            self.assertEqual(len(digest),64)
            safety_backups=list((root/"pre-restore-backups").glob("controller-*.sqlite3"))
            self.assertEqual(len(safety_backups),1)
            self.assertEqual(verify_database(safety_backups[0]), sha256_file(safety_backups[0]))

    def test_backup_checksum_tampering_is_detected(self):
        with tempfile.TemporaryDirectory(prefix="his-risen-backup-tamper-") as folder:
            root=Path(folder); live=root/"controller.sqlite3"
            self._db(live,"trusted")
            backup=backup_database(live,root/"backups")
            backup.write_bytes(backup.read_bytes()+b"tamper")
            with self.assertRaisesRegex(ValueError,"SHA-256"):
                verify_database(backup)

    def test_backup_retention_keeps_newest_requested_count(self):
        with tempfile.TemporaryDirectory(prefix="his-risen-backup-retention-") as folder:
            root=Path(folder); live=root/"controller.sqlite3"; backup_dir=root/"backups"
            self._db(live,"one")
            backup_database(live,backup_dir,keep=1)
            self._db(live,"two")
            backup_database(live,backup_dir,keep=1)
            self.assertEqual(len(list(backup_dir.glob("controller-*.sqlite3"))),1)
            self.assertEqual(len(list(backup_dir.glob("controller-*.sqlite3.sha256"))),1)


if __name__ == "__main__":
    unittest.main()
