from __future__ import annotations

import hashlib
import json
import shutil
import tempfile
import unittest
import uuid
import sys
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parents[1]
if str(APP_ROOT) not in sys.path:
    sys.path.insert(0, str(APP_ROOT))

from config.bootstrap import build_controller


class DurableSubmissionIdempotencyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="his-risen-durable-idempotency-")
        source = Path(__file__).resolve().parents[1]
        self.project = Path(self.temp.name) / "project"
        shutil.copytree(source, self.project, ignore=shutil.ignore_patterns("*.sqlite3", "__pycache__", "*.pyc"))
        self.spec = json.loads((self.project / "config" / "test_shot.json").read_text(encoding="utf-8"))
        self.spec["generation_mode"] = "TEXT_TO_VIDEO"
        self.request_id = str(uuid.uuid4())
        self.payload_hash = hashlib.sha256(
            json.dumps(self.spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

    def tearDown(self):
        self.temp.cleanup()

    def test_request_survives_controller_restart_and_never_reserves_second_take(self):
        first_controller = build_controller(self.project, backend="mock")
        try:
            first, created = first_controller.generate(
                self.spec,
                submission_request_id=self.request_id,
                submission_payload_hash=self.payload_hash,
                return_created=True,
            )
            self.assertTrue(created)
            first_id = first["take_id"]
        finally:
            first_controller.close()

        restarted_controller = build_controller(self.project, backend="mock")
        try:
            second, created = restarted_controller.generate(
                self.spec,
                submission_request_id=self.request_id,
                submission_payload_hash=self.payload_hash,
                return_created=True,
            )
            self.assertFalse(created)
            self.assertEqual(second["take_id"], first_id)
            self.assertEqual(len(restarted_controller.store.film_takes(self.spec["film_id"])), 1)
        finally:
            restarted_controller.close()

    def test_request_id_cannot_be_reused_for_changed_specification(self):
        controller = build_controller(self.project, backend="mock")
        try:
            controller.generate(
                self.spec,
                submission_request_id=self.request_id,
                submission_payload_hash=self.payload_hash,
                return_created=True,
            )
            changed = dict(self.spec)
            changed["action"] = "A different action."
            changed_hash = hashlib.sha256(
                json.dumps(changed, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
            ).hexdigest()
            with self.assertRaisesRegex(ValueError, "different shot specification"):
                controller.generate(
                    changed,
                    submission_request_id=self.request_id,
                    submission_payload_hash=changed_hash,
                    return_created=True,
                )
        finally:
            controller.close()


if __name__ == "__main__":
    unittest.main()
