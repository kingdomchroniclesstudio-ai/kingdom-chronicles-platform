from __future__ import annotations

import argparse
import hashlib
import json
import os
import secrets
import threading
import time
import uuid
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, unquote, urlparse

from config.bootstrap import build_controller
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from config.data_paths import resolve_data_root


APP_NAME = "HIS RISEN STUDIOS"
COOKIE_NAME = "hrf_director_session"
SESSION_TTL = 12 * 60 * 60
MAX_FAILED_PER_WINDOW = 5
FAIL_WINDOW = 5 * 60
MAX_BODY_BYTES = 256 * 1024
MOCK_TEST_FILM_ID = "HRF-MOCK-TEST"
MOCK_TEST_SCENE_ID = "SC999"
MOCK_TEST_SHOT_ID = "SC999-SH001"


class RequestBodyError(ValueError):
    """Client-supplied request body is malformed or too large."""


class SessionStore:
    def __init__(self) -> None:
        self._sessions: dict[str, float] = {}
        self._lock = threading.RLock()

    def create(self) -> str:
        token = secrets.token_urlsafe(32)
        with self._lock:
            self._sessions[token] = time.time() + SESSION_TTL
        return token

    def valid(self, token: str | None) -> bool:
        if not token:
            return False
        now = time.time()
        with self._lock:
            expiry = self._sessions.get(token)
            if expiry is None:
                return False
            if expiry < now:
                self._sessions.pop(token, None)
                return False
            return True

    def revoke(self, token: str | None) -> None:
        if token:
            with self._lock:
                self._sessions.pop(token, None)


class LoginLimiter:
    def __init__(self) -> None:
        self._failed: dict[str, list[float]] = {}
        self._lock = threading.RLock()

    def allowed(self, key: str) -> bool:
        now = time.time()
        with self._lock:
            entries = [t for t in self._failed.get(key, []) if t > now - FAIL_WINDOW]
            self._failed[key] = entries
            return len(entries) < MAX_FAILED_PER_WINDOW

    def failure(self, key: str) -> None:
        with self._lock:
            self._failed.setdefault(key, []).append(time.time())


class DirectorConsole:
    def __init__(self, controller: Any, pin: str, root: Path) -> None:
        if not pin or not pin.isdigit() or len(pin) < 6 or len(pin) > 12:
            raise ValueError("HRF_DIRECTOR_PIN must be a 6-12 digit PIN.")
        self.controller = controller
        self.pin = pin
        self.root = root.resolve()
        self.sessions = SessionStore()
        self.limiter = LoginLimiter()
        self._generation_lock = threading.RLock()
        self._generation_requests: dict[str, dict[str, str]] = {}
        self._readiness_lock = threading.RLock()
        self._readiness_cache: tuple[float, dict[str, Any]] | None = None
        self._autopoll_stop = threading.Event()
        self._autopoll_thread = threading.Thread(target=self._poll_loop, daemon=True)
        self._autopoll_thread.start()

    def _poll_loop(self) -> None:
        while not self._autopoll_stop.wait(2.5):
            try:
                for take in self._active_takes():
                    try:
                        self.controller.advance(take["take_id"])
                    except Exception:
                        pass
            except Exception:
                pass

    def stop(self) -> None:
        self._autopoll_stop.set()
        if self._autopoll_thread.is_alive():
            self._autopoll_thread.join(timeout=1.0)

    def _active_takes(self) -> list[dict[str, Any]]:
        conn = self.controller.store.connection
        with self.controller.store._lock:
            rows = conn.execute(
                "SELECT take_id FROM takes WHERE status IN ('SUBMITTED','RUNNING') ORDER BY created_at"
            ).fetchall()
        return [self.controller.get_take(row["take_id"]) for row in rows]

    def list_films(self) -> list[dict[str, Any]]:
        conn = self.controller.store.connection
        with self.controller.store._lock:
            rows = conn.execute("SELECT film_id FROM films ORDER BY film_id").fetchall()
        return [{"film_id": row["film_id"]} for row in rows]

    def list_takes(self, film_id: str | None = None) -> list[dict[str, Any]]:
        conn = self.controller.store.connection
        with self.controller.store._lock:
            if film_id:
                rows = conn.execute(
                    "SELECT take_id FROM takes WHERE film_id=? ORDER BY scene_id,shot_id,take_number",
                    (film_id,),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT take_id FROM takes ORDER BY updated_at DESC LIMIT 200"
                ).fetchall()
        return [self.controller.get_take(row["take_id"]) for row in rows]

    def status(self) -> dict[str, Any]:
        adapter = type(self.controller.adapter).__name__
        return {
            "service": APP_NAME,
            "controller": "online",
            "backend_adapter": adapter,
            "mock_mode": adapter == "MockComfyUIAdapter",
            "real_generation_enabled": adapter != "MockComfyUIAdapter",
            "approval_required": True,
            "auto_export_approved": bool(self.controller.auto_export_approved),
            "export_manager": self.controller.export_manager is not None,
            "server_time": time.time(),
        }

    def check_for_updates(self) -> dict[str, Any]:
        """Check official LTX metadata without installing or downloading assets."""
        from updates.check import check_updates

        return check_updates(self.root, state_root=resolve_data_root(self.root))

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            loader.validate_required_mappings(
                workflow,
                mapping,
                {"prompt": "HIS RISEN read-only preflight", "duration": 8, "seed": 0},
            )

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            readiness = self.real_shot_readiness()
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            loader.validate_required_mappings(
                workflow,
                mapping,
                {
                    "prompt": "HIS RISEN read-only preflight",
                    "duration": 8,
                    "seed": 0,
                    "width": 2560,
                    "height": 1440,
                    "fps": 24,
                },
            )

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p", "4K"}:
            raise ValueError("Select a supported resolution before submitting.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            readiness = self.real_shot_readiness()
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p", "4K"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p", "4K"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p", "4K"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p", "4K"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p", "4K"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def create_mock_test(self) -> dict[str, Any]:
        if type(self.controller.adapter).__name__ != "MockComfyUIAdapter":
            raise ValueError("Mock Test is available only while the console is in Mock Mode.")

        # Reuse an active/reviewable mock take instead of accidentally creating a
        # second job when the Director double-clicks the test button.
        existing = self.list_takes(MOCK_TEST_FILM_ID)
        active = [
            t
            for t in existing
            if t["status"] in {"SUBMITTED", "RUNNING", "COMPLETED"}
            and t["scene_id"] == MOCK_TEST_SCENE_ID
            and t["shot_id"] == MOCK_TEST_SHOT_ID
        ]
        if active:
            latest = max(active, key=lambda t: (t["take_number"], t["updated_at"]))
            return {"created": False, "reused": True, "take": latest}

        spec_path = self.root / "config" / "test_shot.json"
        spec = json.loads(spec_path.read_text(encoding="utf-8"))
        spec.update(
            {
                "film_id": MOCK_TEST_FILM_ID,
                "scene_id": MOCK_TEST_SCENE_ID,
                "shot_id": MOCK_TEST_SHOT_ID,
                "generation_mode": "TEXT_TO_VIDEO",
                "duration": 8,
                "resolution": "1440p",
                "aspect_ratio": "16:9",
                "frame_rate": 24,
                "quality_preset": "Mock lifecycle verification",
            }
        )
        take = self.controller.generate(spec)
        return {
            "created": True,
            "reused": False,
            "take": take,
            "message": "Mock generation submitted. No real LTX/ComfyUI service was called.",
        }

    def take_review_video(self, take_id: str) -> tuple[str, Path | str] | None:
        take = self.controller.get_take(take_id)
        if take.get("status") not in {"COMPLETED", "APPROVED"}:
            return None

        if take.get("status") == "APPROVED":
            try:
                records = self.controller.export_status(take_id)
            except Exception:
                records = []
            for record in records:
                if record.get("status") == "VERIFIED" and record.get("kind") == "video" and record.get("path"):
                    path = Path(record["path"]).resolve()
                    workspace = self.controller.export_manager.workspace_root.resolve()
                    try:
                        path.relative_to(workspace)
                    except ValueError:
                        continue
                    if path.is_file():
                        return "file", path

        metadata = take.get("output_metadata") or {}
        media_files = metadata.get("media_files") if isinstance(metadata, dict) else None
        if not isinstance(media_files, list):
            return None
        for media in media_files:
            if not isinstance(media, dict) or media.get("kind") != "video":
                continue
            source_path = media.get("source_path")
            if source_path:
                path = Path(source_path).resolve()
                try:
                    path.relative_to(self.root)
                except ValueError:
                    continue
                if path.is_file():
                    return "file", path
            url = media.get("url")
            if isinstance(url, str) and url.startswith(("http://", "https://")):
                return "url", url
        return None


INDEX_HTML = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#090b10">
<meta name="description" content="HIS RISEN STUDIOS — secure film production control room for HIS RISEN FILMS.">
<title>HIS RISEN STUDIOS</title>
<style>
:root{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#eef1f5;background:#090b10}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at top,#171c26,#090b10 45%);min-height:100vh}
.wrap{max-width:1120px;margin:auto;padding:18px 14px 50px}.top{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:18px}.brand{font-weight:850;letter-spacing:.08em}.muted{color:#9aa4b2}
.card{background:rgba(20,24,32,.94);border:1px solid #29313d;border-radius:18px;padding:16px;box-shadow:0 12px 40px rgba(0,0,0,.24);margin-bottom:14px}
.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}.stat{padding:14px;border-radius:14px;background:#10151d;border:1px solid #252d38}.stat b{display:block;font-size:24px;margin-top:4px}
.row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.grow{flex:1}.pill{display:inline-flex;align-items:center;gap:5px;padding:5px 9px;border-radius:999px;background:#202735;font-size:12px}.ok{background:#123820;color:#9df3b0}.warn{background:#3a2c0e;color:#ffd98a}.bad{background:#3d1717;color:#ffb0b0}
button,input,textarea,select{font:inherit}button{border:0;border-radius:12px;padding:11px 14px;font-weight:750;cursor:pointer;background:#e9edf2;color:#0b0e13}button:disabled{opacity:.5;cursor:not-allowed}button.secondary{background:#242c38;color:#eef1f5}button.danger{background:#5a1f25;color:#ffd7da}button.success{background:#145b2a;color:#c7ffd2}button.primary{background:#dbe5f2;color:#0b0e13}
input,textarea,select{width:100%;background:#0c1118;border:1px solid #303947;color:#eef1f5;border-radius:12px;padding:11px;outline:none}textarea{min-height:80px;resize:vertical}.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
.progress{height:10px;background:#252c37;border-radius:99px;overflow:hidden;margin:10px 0}.bar{height:100%;background:#e9edf2;width:0;transition:width .4s}.shot-title{font-size:22px;font-weight:800}.video{width:100%;max-height:560px;background:#000;border-radius:14px;margin-top:12px}.login{max-width:420px;margin:12vh auto}
.pin{font-size:25px;letter-spacing:.25em;text-align:center}.hidden{display:none!important}.small{font-size:13px}.list{display:grid;gap:8px}.item{padding:12px;border:1px solid #29313d;border-radius:13px;background:#10151d}.notice{position:fixed;right:14px;bottom:14px;max-width:360px;background:#eef1f5;color:#0b0e13;padding:12px 14px;border-radius:12px;box-shadow:0 10px 30px #0008;display:none;z-index:20}.subtle{background:#0d1219;border:1px dashed #2b3440;border-radius:12px;padding:11px}.frame-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px}

.shot-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0}
.shot-form-grid label,.shot-shot-fields label{display:block;font-size:13px;color:#cbd3de}
#realShotForm>label{display:block;font-size:13px;color:#cbd3de;margin-top:10px}
#realShotForm textarea{min-height:64px;margin-top:5px}
#realShotForm input,#realShotForm select{margin-top:5px}
#realShotForm .shot-confirm{display:flex;align-items:center;gap:8px;margin-top:14px}
#realShotForm .shot-confirm input{width:auto;margin:0}
@media(max-width:700px){.shot-form-grid{grid-template-columns:1fr}}

.shot-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0}
.shot-form-grid label,.shot-shot-fields label{display:block;font-size:13px;color:#cbd3de}
#realShotForm>label{display:block;font-size:13px;color:#cbd3de;margin-top:10px}
#realShotForm textarea{min-height:64px;margin-top:5px}
#realShotForm input,#realShotForm select{margin-top:5px}
#realShotForm .shot-confirm{display:flex;align-items:center;gap:8px;margin-top:14px}
#realShotForm .shot-confirm input{width:auto;margin:0}
@media(max-width:700px){.shot-form-grid{grid-template-columns:1fr}}

.shot-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0}
.shot-form-grid label,.shot-shot-fields label{display:block;font-size:13px;color:#cbd3de}
#realShotForm>label{display:block;font-size:13px;color:#cbd3de;margin-top:10px}
#realShotForm textarea{min-height:64px;margin-top:5px}
#realShotForm input,#realShotForm select{margin-top:5px}
#realShotForm .shot-confirm{display:flex;align-items:center;gap:8px;margin-top:14px}
#realShotForm .shot-confirm input{width:auto;margin:0}
@media(max-width:700px){.shot-form-grid{grid-template-columns:1fr}}

.shot-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0}
.shot-form-grid label,.shot-shot-fields label{display:block;font-size:13px;color:#cbd3de}
#realShotForm>label{display:block;font-size:13px;color:#cbd3de;margin-top:10px}
#realShotForm textarea{min-height:64px;margin-top:5px}
#realShotForm input,#realShotForm select{margin-top:5px}
#realShotForm .shot-confirm{display:flex;align-items:center;gap:8px;margin-top:14px}
#realShotForm .shot-confirm input{width:auto;margin:0}
@media(max-width:700px){.shot-form-grid{grid-template-columns:1fr}}

.shot-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0}
.shot-form-grid label,.shot-shot-fields label{display:block;font-size:13px;color:#cbd3de}
#realShotForm>label{display:block;font-size:13px;color:#cbd3de;margin-top:10px}
#realShotForm textarea{min-height:64px;margin-top:5px}
#realShotForm input,#realShotForm select{margin-top:5px}
#realShotForm .shot-confirm{display:flex;align-items:center;gap:8px;margin-top:14px}
#realShotForm .shot-confirm input{width:auto;margin:0}
@media(max-width:700px){.shot-form-grid{grid-template-columns:1fr}}

.shot-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0}
.shot-form-grid label,.shot-shot-fields label{display:block;font-size:13px;color:#cbd3de}
#realShotForm>label{display:block;font-size:13px;color:#cbd3de;margin-top:10px}
#realShotForm textarea{min-height:64px;margin-top:5px}
#realShotForm input,#realShotForm select{margin-top:5px}
#realShotForm .shot-confirm{display:flex;align-items:center;gap:8px;margin-top:14px}
#realShotForm .shot-confirm input{width:auto;margin:0}
@media(max-width:700px){.shot-form-grid{grid-template-columns:1fr}}

.shot-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0}
.shot-form-grid label,.shot-shot-fields label{display:block;font-size:13px;color:#cbd3de}
#realShotForm>label{display:block;font-size:13px;color:#cbd3de;margin-top:10px}
#realShotForm textarea{min-height:64px;margin-top:5px}
#realShotForm input,#realShotForm select{margin-top:5px}
#realShotForm .shot-confirm{display:flex;align-items:center;gap:8px;margin-top:14px}
#realShotForm .shot-confirm input{width:auto;margin:0}
@media(max-width:700px){.shot-form-grid{grid-template-columns:1fr}}

.shot-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0}
.shot-form-grid label,.shot-shot-fields label{display:block;font-size:13px;color:#cbd3de}
#realShotForm>label{display:block;font-size:13px;color:#cbd3de;margin-top:10px}
#realShotForm textarea{min-height:64px;margin-top:5px}
#realShotForm input,#realShotForm select{margin-top:5px}
#realShotForm .shot-confirm{display:flex;align-items:center;gap:8px;margin-top:14px}
#realShotForm .shot-confirm input{width:auto;margin:0}
@media(max-width:700px){.shot-form-grid{grid-template-columns:1fr}}

.shot-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0}
.shot-form-grid label,.shot-shot-fields label{display:block;font-size:13px;color:#cbd3de}
#realShotForm>label{display:block;font-size:13px;color:#cbd3de;margin-top:10px}
#realShotForm textarea{min-height:64px;margin-top:5px}
#realShotForm input,#realShotForm select{margin-top:5px}
#realShotForm .shot-confirm{display:flex;align-items:center;gap:8px;margin-top:14px}
#realShotForm .shot-confirm input{width:auto;margin:0}
@media(max-width:700px){.shot-form-grid{grid-template-columns:1fr}}

.shot-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0}
.shot-form-grid label,.shot-shot-fields label{display:block;font-size:13px;color:#cbd3de}
#realShotForm>label{display:block;font-size:13px;color:#cbd3de;margin-top:10px}
#realShotForm textarea{min-height:64px;margin-top:5px}
#realShotForm input,#realShotForm select{margin-top:5px}
#realShotForm .shot-confirm{display:flex;align-items:center;gap:8px;margin-top:14px}
#realShotForm .shot-confirm input{width:auto;margin:0}
@media(max-width:700px){.shot-form-grid{grid-template-columns:1fr}}

.shot-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0}
.shot-form-grid label,.shot-shot-fields label{display:block;font-size:13px;color:#cbd3de}
#realShotForm>label{display:block;font-size:13px;color:#cbd3de;margin-top:10px}
#realShotForm textarea{min-height:64px;margin-top:5px}
#realShotForm input,#realShotForm select{margin-top:5px}
#realShotForm .shot-confirm{display:flex;align-items:center;gap:8px;margin-top:14px}
#realShotForm .shot-confirm input{width:auto;margin:0}
@media(max-width:700px){.shot-form-grid{grid-template-columns:1fr}}

.shot-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0}
.shot-form-grid label,.shot-shot-fields label{display:block;font-size:13px;color:#cbd3de}
#realShotForm>label{display:block;font-size:13px;color:#cbd3de;margin-top:10px}
#realShotForm textarea{min-height:64px;margin-top:5px}
#realShotForm input,#realShotForm select{margin-top:5px}
#realShotForm .shot-confirm{display:flex;align-items:center;gap:8px;margin-top:14px}
#realShotForm .shot-confirm input{width:auto;margin:0}
@media(max-width:700px){.shot-form-grid{grid-template-columns:1fr}}

.shot-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0}
.shot-form-grid label,.shot-shot-fields label{display:block;font-size:13px;color:#cbd3de}
#realShotForm>label{display:block;font-size:13px;color:#cbd3de;margin-top:10px}
#realShotForm textarea{min-height:64px;margin-top:5px}
#realShotForm input,#realShotForm select{margin-top:5px}
#realShotForm .shot-confirm{display:flex;align-items:center;gap:8px;margin-top:14px}
#realShotForm .shot-confirm input{width:auto;margin:0}
@media(max-width:700px){.shot-form-grid{grid-template-columns:1fr}}
@media(max-width:700px){.grid{grid-template-columns:repeat(2,1fr)}.wrap{padding:12px 10px 40px}.top{align-items:flex-start}.shot-title{font-size:19px}.frame-grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<div id="login" class="wrap login">
  <div class="card">
    <div class="brand">HIS RISEN STUDIOS</div><h1>Film Production Control Room</h1>
    <p class="muted">Secure access to the HIS RISEN STUDIOS production workspace.</p>
    <input id="pin" class="pin" type="password" inputmode="numeric" maxlength="12" autocomplete="current-password" placeholder="PIN">
    <div class="actions"><button class="grow" onclick="login()">ENTER STUDIO</button></div>
    <p id="loginMsg" class="small muted"></p>
  </div>
</div>
<div id="app" class="wrap hidden">
  <div class="top">
    <div><div class="brand">HIS RISEN STUDIOS</div><div class="muted small">Film Production Control Room</div></div>
    <div class="row"><span id="backend" class="pill">Checking…</span><button class="secondary" onclick="logout()">Lock</button></div>
  </div>

  <div class="card">
    <div class="row">
      <div class="grow"><h2>Production</h2><div id="filmInfo" class="muted">No production selected.</div></div>
      <select id="filmSelect" style="max-width:320px" onchange="selectFilm(this.value)" disabled><option>No production selected</option></select>
      <button class="secondary" onclick="refreshAll()">Refresh</button>
    </div>
  </div>

  <div class="card" id="realShotCard">
    <div class="row">
      <div class="grow"><h3>New real shot submission</h3><p class="muted small">This submits a single text-to-video shot through the authenticated controller. It stays locked in Mock Mode and until the verified T2V workflow, ComfyUI nodes and CUDA GPU pass preflight.</p></div>
      <span id="realShotGate" class="pill warn">LOCKED</span>
    </div>
    <div id="realShotGateMessage" class="small muted" role="status" aria-live="polite">Checking production readiness…</div>
    <form id="realShotForm" onsubmit="submitRealShot(event)">
      <div class="shot-form-grid">
        <label>Film ID<input id="shotFilmId" required autocomplete="off"></label>
        <label>Scene ID<input id="shotSceneId" required autocomplete="off"></label>
        <label>Shot ID<input id="shotId" required autocomplete="off"></label>
        <label>Character IDs (comma-separated)<input id="shotCharacters" required autocomplete="off"></label>
        <label>Voice profile IDs (comma-separated)<input id="shotVoices" required autocomplete="off"></label>
        <label>Duration (seconds)<input id="shotDuration" type="number" min="1" max="20" step="1" required></label>
        <label>Resolution<select id="shotResolution"><option>720p</option><option>1080p</option><option>1440p</option><option>4K</option></select></label>
        <label>Aspect ratio<input id="shotAspectRatio" value="16:9" required></label>
        <label>Frame rate<input id="shotFrameRate" type="number" min="1" max="60" step="1" required></label>
        <label>Seed (optional)<input id="shotSeed" type="number" min="0" step="1" placeholder="Random seed"></label>
        <label>Quality preset<input id="shotQuality" required></label>
      </div>
      <label>Environment<textarea id="shotEnvironment" required></textarea></label>
      <label>Action<textarea id="shotAction" required></textarea></label>
      <label>Camera<textarea id="shotCamera" required></textarea></label>
      <label>Lighting<textarea id="shotLighting" required></textarea></label>
      <label>Audio and sound design<textarea id="shotAudio" required></textarea></label>
      <label>Continuity requirements<textarea id="shotContinuity" required></textarea></label>
      <label class="shot-confirm"><input id="confirmRealCost" type="checkbox" required> I confirm this is a real generation request and may incur GPU charges.</label>
      <div class="actions"><button id="submitRealShotButton" class="primary" type="submit" disabled>SUBMIT REAL SHOT</button><span id="realShotResult" class="small muted" role="status" aria-live="polite"></span></div>
    </form>
  </div>

  <div class="card" id="realShotCard">
    <div class="row">
      <div class="grow"><h3>New real shot submission</h3><p class="muted small">This submits a single text-to-video shot through the authenticated controller. It stays locked in Mock Mode and until the verified T2V workflow, ComfyUI nodes and CUDA GPU pass preflight.</p></div>
      <span id="realShotGate" class="pill warn">LOCKED</span>
    </div>
    <div id="realShotGateMessage" class="small muted" role="status" aria-live="polite">Checking production readiness…</div>
    <form id="realShotForm" onsubmit="submitRealShot(event)">
      <div class="shot-form-grid">
        <label>Film ID<input id="shotFilmId" required autocomplete="off"></label>
        <label>Scene ID<input id="shotSceneId" required autocomplete="off"></label>
        <label>Shot ID<input id="shotId" required autocomplete="off"></label>
        <label>Character IDs (comma-separated)<input id="shotCharacters" required autocomplete="off"></label>
        <label>Voice profile IDs (comma-separated)<input id="shotVoices" required autocomplete="off"></label>
        <label>Duration (seconds)<input id="shotDuration" type="number" min="1" max="20" step="1" required></label>
        <label>Resolution<select id="shotResolution"><option>720p</option><option>1080p</option><option>1440p</option><option>4K</option></select></label>
        <label>Aspect ratio<input id="shotAspectRatio" value="16:9" required></label>
        <label>Frame rate<input id="shotFrameRate" type="number" min="1" max="60" step="1" required></label>
        <label>Seed (optional)<input id="shotSeed" type="number" min="0" step="1" placeholder="Random seed"></label>
        <label>Quality preset<input id="shotQuality" required></label>
      </div>
      <label>Environment<textarea id="shotEnvironment" required></textarea></label>
      <label>Action<textarea id="shotAction" required></textarea></label>
      <label>Camera<textarea id="shotCamera" required></textarea></label>
      <label>Lighting<textarea id="shotLighting" required></textarea></label>
      <label>Audio and sound design<textarea id="shotAudio" required></textarea></label>
      <label>Continuity requirements<textarea id="shotContinuity" required></textarea></label>
      <label class="shot-confirm"><input id="confirmRealCost" type="checkbox" required> I confirm this is a real generation request and may incur GPU charges.</label>
      <div class="actions"><button id="submitRealShotButton" class="primary" type="submit" disabled>SUBMIT REAL SHOT</button><span id="realShotResult" class="small muted" role="status" aria-live="polite"></span></div>
    </form>
  </div>

  <div class="card" id="realShotCard">
    <div class="row">
      <div class="grow"><h3>New real shot submission</h3><p class="muted small">This submits a single text-to-video shot through the authenticated controller. It stays locked in Mock Mode and until the verified T2V workflow, ComfyUI nodes and CUDA GPU pass preflight.</p></div>
      <span id="realShotGate" class="pill warn">LOCKED</span>
    </div>
    <div id="realShotGateMessage" class="small muted" role="status" aria-live="polite">Checking production readiness…</div>
    <form id="realShotForm" onsubmit="submitRealShot(event)">
      <div class="shot-form-grid">
        <label>Film ID<input id="shotFilmId" required autocomplete="off"></label>
        <label>Scene ID<input id="shotSceneId" required autocomplete="off"></label>
        <label>Shot ID<input id="shotId" required autocomplete="off"></label>
        <label>Character IDs (comma-separated)<input id="shotCharacters" required autocomplete="off"></label>
        <label>Voice profile IDs (comma-separated)<input id="shotVoices" required autocomplete="off"></label>
        <label>Duration (seconds)<input id="shotDuration" type="number" min="1" max="20" step="1" required></label>
        <label>Resolution<select id="shotResolution"><option>720p</option><option>1080p</option><option>1440p</option><option>4K</option></select></label>
        <label>Aspect ratio<input id="shotAspectRatio" value="16:9" readonly></label>
        <label>Frame rate<input id="shotFrameRate" type="number" min="1" max="60" step="1" required></label>
        <label>Seed<input id="shotSeed" type="number" min="0" step="1" value="0" required></label>
      </div>
      <label>Environment<textarea id="shotEnvironment" required></textarea></label>
      <label>Action<textarea id="shotAction" required></textarea></label>
      <label>Camera<textarea id="shotCamera" required></textarea></label>
      <label>Lighting<textarea id="shotLighting" required></textarea></label>
      <label>Audio and sound design<textarea id="shotAudio" required></textarea></label>
      <label>Continuity requirements<textarea id="shotContinuity" required></textarea></label>
      <label class="shot-confirm"><input id="confirmRealCost" type="checkbox" required> I confirm this is a real generation request and may incur GPU charges.</label>
      <div class="actions"><button id="submitRealShotButton" class="primary" type="submit" disabled>SUBMIT REAL SHOT</button><span id="realShotResult" class="small muted" role="status" aria-live="polite"></span></div>
    </form>
  </div>

  <div class="card" id="realShotCard">
    <div class="row">
      <div class="grow"><h3>New real shot submission</h3><p class="muted small">This submits a single text-to-video shot through the authenticated controller. It stays locked in Mock Mode and until the verified T2V workflow, ComfyUI nodes and CUDA GPU pass preflight.</p></div>
      <span id="realShotGate" class="pill warn">LOCKED</span>
    </div>
    <div id="realShotGateMessage" class="small muted" role="status" aria-live="polite">Checking production readiness…</div>
    <form id="realShotForm" onsubmit="submitRealShot(event)">
      <div class="shot-form-grid">
        <label>Film ID<input id="shotFilmId" required autocomplete="off"></label>
        <label>Scene ID<input id="shotSceneId" required autocomplete="off"></label>
        <label>Shot ID<input id="shotId" required autocomplete="off"></label>
        <label>Character IDs (comma-separated)<input id="shotCharacters" required autocomplete="off"></label>
        <label>Voice profile IDs (comma-separated)<input id="shotVoices" required autocomplete="off"></label>
        <label>Duration (seconds)<input id="shotDuration" type="number" min="1" max="20" step="1" required></label>
        <label>Resolution<select id="shotResolution"><option>720p</option><option>1080p</option><option>1440p</option><option>4K</option></select></label>
        <label>Aspect ratio<input id="shotAspectRatio" value="16:9" readonly></label>
        <label>Frame rate<input id="shotFrameRate" type="number" min="1" max="60" step="1" required></label>
        <label>Seed<input id="shotSeed" type="number" min="0" step="1" value="0" required></label>
      </div>
      <label>Environment<textarea id="shotEnvironment" required></textarea></label>
      <label>Action<textarea id="shotAction" required></textarea></label>
      <label>Camera<textarea id="shotCamera" required></textarea></label>
      <label>Lighting<textarea id="shotLighting" required></textarea></label>
      <label>Audio and sound design<textarea id="shotAudio" required></textarea></label>
      <label>Continuity requirements<textarea id="shotContinuity" required></textarea></label>
      <label class="shot-confirm"><input id="confirmRealCost" type="checkbox" required> I confirm this is a real generation request and may incur GPU charges.</label>
      <div class="actions"><button id="submitRealShotButton" class="primary" type="submit" disabled>SUBMIT REAL SHOT</button><span id="realShotResult" class="small muted" role="status" aria-live="polite"></span></div>
    </form>
  </div>

  <div class="card" id="realShotCard">
    <div class="row">
      <div class="grow"><h3>New real shot submission</h3><p class="muted small">This submits a single text-to-video shot through the authenticated controller. It stays locked in Mock Mode and until the verified T2V workflow, ComfyUI nodes and CUDA GPU pass preflight.</p></div>
      <span id="realShotGate" class="pill warn">LOCKED</span>
    </div>
    <div id="realShotGateMessage" class="small muted" role="status" aria-live="polite">Checking production readiness…</div>
    <form id="realShotForm" onsubmit="submitRealShot(event)">
      <div class="shot-form-grid">
        <label>Film ID<input id="shotFilmId" required autocomplete="off"></label>
        <label>Scene ID<input id="shotSceneId" required autocomplete="off"></label>
        <label>Shot ID<input id="shotId" required autocomplete="off"></label>
        <label>Character IDs (comma-separated)<input id="shotCharacters" required autocomplete="off"></label>
        <label>Voice profile IDs (comma-separated)<input id="shotVoices" required autocomplete="off"></label>
        <label>Duration (seconds)<input id="shotDuration" type="number" min="1" max="20" step="1" required></label>
        <label>Resolution<select id="shotResolution"><option>720p</option><option>1080p</option><option>1440p</option><option>4K</option></select></label>
        <label>Aspect ratio<input id="shotAspectRatio" value="16:9" readonly></label>
        <label>Frame rate<input id="shotFrameRate" type="number" min="1" max="60" step="1" required></label>
        <label>Seed<input id="shotSeed" type="number" min="0" step="1" value="0" required></label>
      </div>
      <label>Environment<textarea id="shotEnvironment" required></textarea></label>
      <label>Action<textarea id="shotAction" required></textarea></label>
      <label>Camera<textarea id="shotCamera" required></textarea></label>
      <label>Lighting<textarea id="shotLighting" required></textarea></label>
      <label>Audio and sound design<textarea id="shotAudio" required></textarea></label>
      <label>Continuity requirements<textarea id="shotContinuity" required></textarea></label>
      <label class="shot-confirm"><input id="confirmRealCost" type="checkbox" required> I confirm this is a real generation request and may incur GPU charges.</label>
      <div class="actions"><button id="submitRealShotButton" class="primary" type="submit" disabled>SUBMIT REAL SHOT</button><span id="realShotResult" class="small muted" role="status" aria-live="polite"></span></div>
    </form>
  </div>

  <div class="card" id="realShotCard">
    <div class="row">
      <div class="grow"><h3>New real shot submission</h3><p class="muted small">This submits a single text-to-video shot through the authenticated controller. It stays locked in Mock Mode and until the verified T2V workflow, ComfyUI nodes and CUDA GPU pass preflight.</p></div>
      <span id="realShotGate" class="pill warn">LOCKED</span>
    </div>
    <div id="realShotGateMessage" class="small muted" role="status" aria-live="polite">Checking production readiness…</div>
    <form id="realShotForm" onsubmit="submitRealShot(event)">
      <div class="shot-form-grid">
        <label>Film ID<input id="shotFilmId" required autocomplete="off"></label>
        <label>Scene ID<input id="shotSceneId" required autocomplete="off"></label>
        <label>Shot ID<input id="shotId" required autocomplete="off"></label>
        <label>Character IDs (comma-separated)<input id="shotCharacters" required autocomplete="off"></label>
        <label>Voice profile IDs (comma-separated)<input id="shotVoices" required autocomplete="off"></label>
        <label>Duration (seconds)<input id="shotDuration" type="number" min="1" max="20" step="1" required></label>
        <label>Resolution<select id="shotResolution"><option>720p</option><option>1080p</option><option>1440p</option><option>4K</option></select></label>
        <label>Aspect ratio<input id="shotAspectRatio" value="16:9" readonly></label>
        <label>Frame rate<input id="shotFrameRate" type="number" min="1" max="60" step="1" required></label>
        <label>Seed<input id="shotSeed" type="number" min="0" step="1" value="0" required></label>
      </div>
      <label>Environment<textarea id="shotEnvironment" required></textarea></label>
      <label>Action<textarea id="shotAction" required></textarea></label>
      <label>Camera<textarea id="shotCamera" required></textarea></label>
      <label>Lighting<textarea id="shotLighting" required></textarea></label>
      <label>Audio and sound design<textarea id="shotAudio" required></textarea></label>
      <label>Continuity requirements<textarea id="shotContinuity" required></textarea></label>
      <label class="shot-confirm"><input id="confirmRealCost" type="checkbox" required> I confirm this is a real generation request and may incur GPU charges.</label>
      <div class="actions"><button id="submitRealShotButton" class="primary" type="submit" disabled>SUBMIT REAL SHOT</button><span id="realShotResult" class="small muted" role="status" aria-live="polite"></span></div>
    </form>
  </div>

  <div class="card" id="realShotCard">
    <div class="row">
      <div class="grow"><h3>New real shot submission</h3><p class="muted small">This submits a single text-to-video shot through the authenticated controller. It stays locked in Mock Mode and until the verified T2V workflow, ComfyUI nodes and CUDA GPU pass preflight.</p></div>
      <span id="realShotGate" class="pill warn">LOCKED</span>
    </div>
    <div id="realShotGateMessage" class="small muted" role="status" aria-live="polite">Checking production readiness…</div>
    <form id="realShotForm" onsubmit="submitRealShot(event)">
      <div class="shot-form-grid">
        <label>Film ID<input id="shotFilmId" required autocomplete="off"></label>
        <label>Scene ID<input id="shotSceneId" required autocomplete="off"></label>
        <label>Shot ID<input id="shotId" required autocomplete="off"></label>
        <label>Character IDs (comma-separated)<input id="shotCharacters" required autocomplete="off"></label>
        <label>Voice profile IDs (comma-separated)<input id="shotVoices" required autocomplete="off"></label>
        <label>Duration (seconds)<input id="shotDuration" type="number" min="1" max="20" step="1" required></label>
        <label>Resolution<select id="shotResolution"><option>720p</option><option>1080p</option><option>1440p</option><option>4K</option></select></label>
        <label>Aspect ratio<input id="shotAspectRatio" value="16:9" readonly></label>
        <label>Frame rate<input id="shotFrameRate" type="number" min="1" max="60" step="1" required></label>
        <label>Seed<input id="shotSeed" type="number" min="0" step="1" value="0" required></label>
      </div>
      <label>Environment<textarea id="shotEnvironment" required></textarea></label>
      <label>Action<textarea id="shotAction" required></textarea></label>
      <label>Camera<textarea id="shotCamera" required></textarea></label>
      <label>Lighting<textarea id="shotLighting" required></textarea></label>
      <label>Audio and sound design<textarea id="shotAudio" required></textarea></label>
      <label>Continuity requirements<textarea id="shotContinuity" required></textarea></label>
      <label class="shot-confirm"><input id="confirmRealCost" type="checkbox" required> I confirm this is a real generation request and may incur GPU charges.</label>
      <div class="actions"><button id="submitRealShotButton" class="primary" type="submit" disabled>SUBMIT REAL SHOT</button><span id="realShotResult" class="small muted" role="status" aria-live="polite"></span></div>
    </form>
  </div>

  <div class="card" id="realShotCard">
    <div class="row">
      <div class="grow"><h3>New real shot submission</h3><p class="muted small">This submits a single text-to-video shot through the authenticated controller. It stays locked in Mock Mode and until the verified T2V workflow, ComfyUI nodes and CUDA GPU pass preflight.</p></div>
      <span id="realShotGate" class="pill warn">LOCKED</span>
    </div>
    <div id="realShotGateMessage" class="small muted" role="status" aria-live="polite">Checking production readiness…</div>
    <form id="realShotForm" onsubmit="submitRealShot(event)">
      <div class="shot-form-grid">
        <label>Film ID<input id="shotFilmId" required autocomplete="off"></label>
        <label>Scene ID<input id="shotSceneId" required autocomplete="off"></label>
        <label>Shot ID<input id="shotId" required autocomplete="off"></label>
        <label>Character IDs (comma-separated)<input id="shotCharacters" required autocomplete="off"></label>
        <label>Voice profile IDs (comma-separated)<input id="shotVoices" required autocomplete="off"></label>
        <label>Duration (seconds)<input id="shotDuration" type="number" min="1" max="20" step="1" required></label>
        <label>Resolution<select id="shotResolution"><option>720p</option><option>1080p</option><option>1440p</option></select></label>
        <label>Aspect ratio<input id="shotAspectRatio" value="16:9" readonly></label>
        <label>Frame rate<input id="shotFrameRate" type="number" min="1" max="60" step="1" required></label>
        <label>Seed<input id="shotSeed" type="number" min="0" step="1" value="0" required></label>
      </div>
      <label>Environment<textarea id="shotEnvironment" required></textarea></label>
      <label>Action<textarea id="shotAction" required></textarea></label>
      <label>Camera<textarea id="shotCamera" required></textarea></label>
      <label>Lighting<textarea id="shotLighting" required></textarea></label>
      <label>Audio and sound design<textarea id="shotAudio" required></textarea></label>
      <label>Continuity requirements<textarea id="shotContinuity" required></textarea></label>
      <label class="shot-confirm"><input id="confirmRealCost" type="checkbox" required> I confirm this is a real generation request and may incur GPU charges.</label>
      <div class="actions"><button id="submitRealShotButton" class="primary" type="submit" disabled>SUBMIT REAL SHOT</button><span id="realShotResult" class="small muted" role="status" aria-live="polite"></span></div>
    </form>
  </div>

  <div class="card" id="realShotCard">
    <div class="row">
      <div class="grow"><h3>New real shot submission</h3><p class="muted small">This submits a single text-to-video shot through the authenticated controller. It stays locked in Mock Mode and until the verified T2V workflow, ComfyUI nodes and CUDA GPU pass preflight.</p></div>
      <span id="realShotGate" class="pill warn">LOCKED</span>
    </div>
    <div id="realShotGateMessage" class="small muted" role="status" aria-live="polite">Checking production readiness…</div>
    <form id="realShotForm" onsubmit="submitRealShot(event)">
      <div class="shot-form-grid">
        <label>Film ID<input id="shotFilmId" required autocomplete="off"></label>
        <label>Scene ID<input id="shotSceneId" required autocomplete="off"></label>
        <label>Shot ID<input id="shotId" required autocomplete="off"></label>
        <label>Character IDs (comma-separated)<input id="shotCharacters" required autocomplete="off"></label>
        <label>Voice profile IDs (comma-separated)<input id="shotVoices" required autocomplete="off"></label>
        <label>Duration (seconds)<input id="shotDuration" type="number" min="1" max="20" step="1" required></label>
        <label>Resolution<select id="shotResolution"><option>720p</option><option>1080p</option><option>1440p</option></select></label>
        <label>Aspect ratio<input id="shotAspectRatio" value="16:9" readonly></label>
        <label>Frame rate<input id="shotFrameRate" type="number" min="1" max="60" step="1" required></label>
        <label>Seed<input id="shotSeed" type="number" min="0" step="1" value="0" required></label>
      </div>
      <label>Environment<textarea id="shotEnvironment" required></textarea></label>
      <label>Action<textarea id="shotAction" required></textarea></label>
      <label>Camera<textarea id="shotCamera" required></textarea></label>
      <label>Lighting<textarea id="shotLighting" required></textarea></label>
      <label>Audio and sound design<textarea id="shotAudio" required></textarea></label>
      <label>Continuity requirements<textarea id="shotContinuity" required></textarea></label>
      <label class="shot-confirm"><input id="confirmRealCost" type="checkbox" required> I confirm this is a real generation request and may incur GPU charges.</label>
      <div class="actions"><button id="submitRealShotButton" class="primary" type="submit" disabled>SUBMIT REAL SHOT</button><span id="realShotResult" class="small muted" role="status" aria-live="polite"></span></div>
    </form>
  </div>

  <div class="card" id="realShotCard">
    <div class="row">
      <div class="grow"><h3>New real shot submission</h3><p class="muted small">This submits a single text-to-video shot through the authenticated controller. It stays locked in Mock Mode and until the verified T2V workflow, ComfyUI nodes and CUDA GPU pass preflight.</p></div>
      <span id="realShotGate" class="pill warn">LOCKED</span>
    </div>
    <div id="realShotGateMessage" class="small muted" role="status" aria-live="polite">Checking production readiness…</div>
    <form id="realShotForm" onsubmit="submitRealShot(event)">
      <div class="shot-form-grid">
        <label>Film ID<input id="shotFilmId" required autocomplete="off"></label>
        <label>Scene ID<input id="shotSceneId" required autocomplete="off"></label>
        <label>Shot ID<input id="shotId" required autocomplete="off"></label>
        <label>Character IDs (comma-separated)<input id="shotCharacters" required autocomplete="off"></label>
        <label>Voice profile IDs (comma-separated)<input id="shotVoices" required autocomplete="off"></label>
        <label>Duration (seconds)<input id="shotDuration" type="number" min="1" max="20" step="1" required></label>
        <label>Resolution<select id="shotResolution"><option>720p</option><option>1080p</option><option>1440p</option></select></label>
        <label>Aspect ratio<input id="shotAspectRatio" value="16:9" readonly></label>
        <label>Frame rate<input id="shotFrameRate" type="number" min="1" max="60" step="1" required></label>
        <label>Seed<input id="shotSeed" type="number" min="0" step="1" value="0" required></label>
      </div>
      <label>Environment<textarea id="shotEnvironment" required></textarea></label>
      <label>Action<textarea id="shotAction" required></textarea></label>
      <label>Camera<textarea id="shotCamera" required></textarea></label>
      <label>Lighting<textarea id="shotLighting" required></textarea></label>
      <label>Audio and sound design<textarea id="shotAudio" required></textarea></label>
      <label>Continuity requirements<textarea id="shotContinuity" required></textarea></label>
      <label class="shot-confirm"><input id="confirmRealCost" type="checkbox" required> I confirm this is a real generation request and may incur GPU charges.</label>
      <div class="actions"><button id="submitRealShotButton" class="primary" type="submit" disabled>SUBMIT REAL SHOT</button><span id="realShotResult" class="small muted" role="status" aria-live="polite"></span></div>
    </form>
  </div>

  <div class="card" id="realShotCard">
    <div class="row">
      <div class="grow"><h3>New real shot submission</h3><p class="muted small">This submits a single text-to-video shot through the authenticated controller. It stays locked in Mock Mode and until the verified T2V workflow, ComfyUI nodes and CUDA GPU pass preflight.</p></div>
      <span id="realShotGate" class="pill warn">LOCKED</span>
    </div>
    <div id="realShotGateMessage" class="small muted" role="status" aria-live="polite">Checking production readiness…</div>
    <form id="realShotForm" onsubmit="submitRealShot(event)">
      <div class="shot-form-grid">
        <label>Film ID<input id="shotFilmId" required autocomplete="off"></label>
        <label>Scene ID<input id="shotSceneId" required autocomplete="off"></label>
        <label>Shot ID<input id="shotId" required autocomplete="off"></label>
        <label>Character IDs (comma-separated)<input id="shotCharacters" required autocomplete="off"></label>
        <label>Voice profile IDs (comma-separated)<input id="shotVoices" required autocomplete="off"></label>
        <label>Duration (seconds)<input id="shotDuration" type="number" min="1" max="20" step="1" required></label>
        <label>Resolution<select id="shotResolution"><option>720p</option><option>1080p</option><option>1440p</option></select></label>
        <label>Aspect ratio<input id="shotAspectRatio" value="16:9" readonly></label>
        <label>Frame rate<input id="shotFrameRate" type="number" min="1" max="60" step="1" required></label>
        <label>Seed<input id="shotSeed" type="number" min="0" step="1" value="0" required></label>
      </div>
      <label>Environment<textarea id="shotEnvironment" required></textarea></label>
      <label>Action<textarea id="shotAction" required></textarea></label>
      <label>Camera<textarea id="shotCamera" required></textarea></label>
      <label>Lighting<textarea id="shotLighting" required></textarea></label>
      <label>Audio and sound design<textarea id="shotAudio" required></textarea></label>
      <label>Continuity requirements<textarea id="shotContinuity" required></textarea></label>
      <label class="shot-confirm"><input id="confirmRealCost" type="checkbox" required> I confirm this is a real generation request and may incur GPU charges.</label>
      <div class="actions"><button id="submitRealShotButton" class="primary" type="submit" disabled>SUBMIT REAL SHOT</button><span id="realShotResult" class="small muted" role="status" aria-live="polite"></span></div>
    </form>
  </div>

  <div class="card" id="realShotCard">
    <div class="row">
      <div class="grow"><h3>New real shot submission</h3><p class="muted small">This submits a single text-to-video shot through the authenticated controller. It stays locked in Mock Mode and until the verified T2V workflow, ComfyUI nodes and CUDA GPU pass preflight.</p></div>
      <span id="realShotGate" class="pill warn">LOCKED</span>
    </div>
    <div id="realShotGateMessage" class="small muted" role="status" aria-live="polite">Checking production readiness…</div>
    <form id="realShotForm" onsubmit="submitRealShot(event)">
      <div class="shot-form-grid">
        <label>Film ID<input id="shotFilmId" required autocomplete="off"></label>
        <label>Scene ID<input id="shotSceneId" required autocomplete="off"></label>
        <label>Shot ID<input id="shotId" required autocomplete="off"></label>
        <label>Character IDs (comma-separated)<input id="shotCharacters" required autocomplete="off"></label>
        <label>Voice profile IDs (comma-separated)<input id="shotVoices" required autocomplete="off"></label>
        <label>Duration (seconds)<input id="shotDuration" type="number" min="1" max="20" step="1" required></label>
        <label>Resolution<select id="shotResolution"><option>720p</option><option>1080p</option><option>1440p</option></select></label>
        <label>Aspect ratio<input id="shotAspectRatio" value="16:9" readonly></label>
        <label>Frame rate<input id="shotFrameRate" type="number" min="1" max="60" step="1" required></label>
        <label>Seed<input id="shotSeed" type="number" min="0" step="1" value="0" required></label>
      </div>
      <label>Environment<textarea id="shotEnvironment" required></textarea></label>
      <label>Action<textarea id="shotAction" required></textarea></label>
      <label>Camera<textarea id="shotCamera" required></textarea></label>
      <label>Lighting<textarea id="shotLighting" required></textarea></label>
      <label>Audio and sound design<textarea id="shotAudio" required></textarea></label>
      <label>Continuity requirements<textarea id="shotContinuity" required></textarea></label>
      <label class="shot-confirm"><input id="confirmRealCost" type="checkbox" required> I confirm this is a real generation request and may incur GPU charges.</label>
      <div class="actions"><button id="submitRealShotButton" class="primary" type="submit" disabled>SUBMIT REAL SHOT</button><span id="realShotResult" class="small muted" role="status" aria-live="polite"></span></div>
    </form>
  </div>

  <div class="card" id="realShotCard">
    <div class="row">
      <div class="grow"><h3>New real shot submission</h3><p class="muted small">This submits a single text-to-video shot through the authenticated controller. It stays locked in Mock Mode and until the verified T2V workflow, ComfyUI nodes and CUDA GPU pass preflight.</p></div>
      <span id="realShotGate" class="pill warn">LOCKED</span>
    </div>
    <div id="realShotGateMessage" class="small muted" role="status" aria-live="polite">Checking production readiness…</div>
    <form id="realShotForm" onsubmit="submitRealShot(event)">
      <div class="shot-form-grid">
        <label>Film ID<input id="shotFilmId" required autocomplete="off"></label>
        <label>Scene ID<input id="shotSceneId" required autocomplete="off"></label>
        <label>Shot ID<input id="shotId" required autocomplete="off"></label>
        <label>Character IDs (comma-separated)<input id="shotCharacters" required autocomplete="off"></label>
        <label>Voice profile IDs (comma-separated)<input id="shotVoices" required autocomplete="off"></label>
        <label>Duration (seconds)<input id="shotDuration" type="number" min="1" max="20" step="1" required></label>
        <label>Resolution<select id="shotResolution"><option>720p</option><option>1080p</option><option>1440p</option></select></label>
        <label>Aspect ratio<input id="shotAspectRatio" value="16:9" readonly></label>
        <label>Frame rate<input id="shotFrameRate" type="number" min="1" max="60" step="1" required></label>
        <label>Seed<input id="shotSeed" type="number" min="0" step="1" value="0" required></label>
      </div>
      <label>Environment<textarea id="shotEnvironment" required></textarea></label>
      <label>Action<textarea id="shotAction" required></textarea></label>
      <label>Camera<textarea id="shotCamera" required></textarea></label>
      <label>Lighting<textarea id="shotLighting" required></textarea></label>
      <label>Audio and sound design<textarea id="shotAudio" required></textarea></label>
      <label>Continuity requirements<textarea id="shotContinuity" required></textarea></label>
      <label class="shot-confirm"><input id="confirmRealCost" type="checkbox" required> I confirm this is a real generation request and may incur GPU charges.</label>
      <div class="actions"><button id="submitRealShotButton" class="primary" type="submit" disabled>SUBMIT REAL SHOT</button><span id="realShotResult" class="small muted" role="status" aria-live="polite"></span></div>
    </form>
  </div>

  <div class="grid">
    <div class="stat"><span class="muted small">Total takes</span><b id="total">0</b></div>
    <div class="stat"><span class="muted small">Approved</span><b id="approved">0</b></div>
    <div class="stat"><span class="muted small">Waiting review</span><b id="review">0</b></div>
    <div class="stat"><span class="muted small">Rejected</span><b id="rejected">0</b></div>
  </div>

  <div id="mockTestCard" class="card hidden">
    <div class="row"><div class="grow"><h3>Controller Mock Test</h3><p class="muted small">Creates one safe 8-second test shot and exercises the real controller lifecycle without calling RunPod, ComfyUI, or LTX.</p></div><button class="primary" onclick="runMockTest()">RUN ONE MOCK SHOT</button></div>
    <div id="mockTestResult" class="small muted"></div>
  </div>

  <div class="card" id="updateCheckCard">
    <div class="row"><div class="grow"><h3>LTX Update Monitor</h3><p class="muted small">Checks official release, model and documentation sources. This is read-only discovery: it does not install controller code, download model weights, edit capabilities, or start GPU jobs.</p></div><button id="updateCheckButton" class="primary" onclick="runUpdateCheck()">CHECK FOR UPDATES</button></div>
    <div id="updateCheckStatus" class="small muted" role="status" aria-live="polite">Not checked in this session.</div>
    <div id="updateCheckResults" class="list" aria-live="polite"></div>
  </div>

  <div id="current" class="card"><div class="muted">No completed shot awaiting Director review.</div></div>

  <div class="card"><h3>Director Command</h3><p class="muted small">The natural-language command bridge is not connected yet. No command is executed from this box.</p><textarea id="command" placeholder="Example: Pause production after the current shot."></textarea><div class="actions"><button onclick="sendCommand()">SEND COMMAND</button></div><div id="commandResult" class="small muted"></div></div>
  <div class="card"><h3>Recent production</h3><div id="takes" class="list"><div class="muted">Loading…</div></div></div>
</div>
<div id="notice" class="notice"></div>
<script>
let currentFilm=null,pollHandle=null;
let shotTemplate=null,generationGate=null,pendingShotRequestId=null,pendingShotPayload=null;
let shotTemplate=null,generationGate=null,pendingShotRequestId=null,pendingShotPayload=null;
let shotTemplate=null,generationGate=null,pendingShotRequestId=null,pendingShotPayload=null;
let shotTemplate=null,generationGate=null,pendingShotRequestId=null,pendingShotPayload=null;
let shotTemplate=null,generationGate=null,pendingShotRequestId=null,pendingShotPayload=null;
let shotTemplate=null,generationGate=null,pendingShotRequestId=null,pendingShotPayload=null;
let shotTemplate=null,generationGate=null,pendingShotRequestId=null,pendingShotPayload=null;
let shotTemplate=null,generationGate=null,pendingShotRequestId=null,pendingShotPayload=null;
let shotTemplate=null,generationGate=null,pendingShotRequestId=null,pendingShotPayload=null;
let shotTemplate=null,generationGate=null,pendingShotRequestId=null,pendingShotPayload=null;
let shotTemplate=null,generationGate=null,pendingShotRequestId=null,pendingShotPayload=null;
let shotTemplate=null,generationGate=null,pendingShotRequestId=null,pendingShotPayload=null;
let shotTemplate=null,generationGate=null,pendingShotRequestId=null,pendingShotPayload=null;
const $=id=>document.getElementById(id);
function note(t){$('notice').textContent=t;$('notice').style.display='block';setTimeout(()=>$('notice').style.display='none',3500)}
async function api(path,opts={}){const r=await fetch('/api'+path,{...opts,headers:{'Content-Type':'application/json',...(opts.headers||{})}});if(r.status===401){showLogin();throw Error('Unauthorized')}const j=await r.json();if(!r.ok)throw Error(j.error||j.details?.join(', ')||'Request failed');return j.data}
async function login(){const pin=$('pin').value;try{await api('/login',{method:'POST',body:JSON.stringify({pin})});$('pin').value='';showApp();await refreshAll()}catch(e){$('loginMsg').textContent='Access denied or temporarily locked.'}}
$('pin').addEventListener('keydown',e=>{if(e.key==='Enter')login()});
function showLogin(){clearInterval(pollHandle);pollHandle=null;$('app').classList.add('hidden');$('login').classList.remove('hidden')}
function showApp(){$('login').classList.add('hidden');$('app').classList.remove('hidden');if(!pollHandle)pollHandle=setInterval(refreshAll,4000)}
async function logout(){await fetch('/api/logout',{method:'POST'});showLogin()}
function selectFilm(value){currentFilm=value||null;refreshAll()}
async function refreshAll(){try{
 const s=await api('/status');
 if(!shotTemplate)await loadShotTemplate();
 const gate=await api('/generation-readiness');renderGenerationGate(gate);
 if(!shotTemplate)await loadShotTemplate();
 const gate=await api('/generation-readiness');renderGenerationGate(gate);
 if(!shotTemplate)await loadShotTemplate();
 const gate=await api('/generation-readiness');renderGenerationGate(gate);
 if(!shotTemplate)await loadShotTemplate();
 const gate=await api('/generation-readiness');renderGenerationGate(gate);
 if(!shotTemplate)await loadShotTemplate();
 const gate=await api('/generation-readiness');renderGenerationGate(gate);
 if(!shotTemplate)await loadShotTemplate();
 const gate=await api('/generation-readiness');renderGenerationGate(gate);
 if(!shotTemplate)await loadShotTemplate();
 const gate=await api('/generation-readiness');renderGenerationGate(gate);
 if(!shotTemplate)await loadShotTemplate();
 const gate=await api('/generation-readiness');renderGenerationGate(gate);
 if(!shotTemplate)await loadShotTemplate();
 const gate=await api('/generation-readiness');renderGenerationGate(gate);
 if(!shotTemplate)await loadShotTemplate();
 const gate=await api('/generation-readiness');renderGenerationGate(gate);
 if(!shotTemplate)await loadShotTemplate();
 const gate=await api('/generation-readiness');renderGenerationGate(gate);
 if(!shotTemplate)await loadShotTemplate();
 const gate=await api('/generation-readiness');renderGenerationGate(gate);
 if(!shotTemplate)await loadShotTemplate();
 const gate=await api('/generation-readiness');renderGenerationGate(gate);
 $('backend').textContent=s.mock_mode?'🟡 MOCK MODE':'🟢 LTX/ComfyUI';$('backend').className='pill '+(s.mock_mode?'warn':'ok');
 $('mockTestCard').classList.toggle('hidden',!s.mock_mode);
 const films=await api('/films');
 const select=$('filmSelect'); select.innerHTML=films.length?films.map(f=>`<option value="${esc(f.film_id)}">${esc(f.film_id)}</option>`).join(''):'<option>No production selected</option>';
 if(!currentFilm||!films.some(f=>f.film_id===currentFilm))currentFilm=films.length?films[0].film_id:null;
 select.disabled=!films.length; if(currentFilm)select.value=currentFilm;
 if(!currentFilm){$('filmInfo').textContent='No production selected.';$('total').textContent='0';$('approved').textContent='0';$('review').textContent='0';$('rejected').textContent='0';$('takes').innerHTML='<div class="muted">No takes yet.</div>';$('current').innerHTML='<div class="muted">No completed shot awaiting Director review.</div>';return;}
 const ready=await api('/films/'+encodeURIComponent(currentFilm)+'/readiness');
 $('total').textContent=ready.takes_total||0;$('approved').textContent=ready.approved||0;$('review').textContent=ready.pending_or_review||0;$('rejected').textContent=ready.rejected||0;
 $('filmInfo').textContent=ready.ready_for_editing?'Ready for editing':(ready.failed?'Production has a failed take':'Production in progress');
 const takes=await api('/takes?film_id='+encodeURIComponent(currentFilm));
 renderTakes(takes);renderCurrent([...takes].reverse().find(t=>t.status==='COMPLETED'));
 }catch(e){if(e.message!=='Unauthorized')$('filmInfo').textContent=e.message}}
function renderCurrent(t){
 if(!t){$('current').innerHTML='<div class="muted">No completed shot awaiting Director review.</div>';return}
 const snap=t.snapshot?.specification||{};const mode=snap.generation_mode||'AUTO';const frame=snap.frame_conditioning||null;
 let frameHtml='';
 if(frame){const first=frame.first_frame||{};const last=frame.last_frame||{};frameHtml=`<div class="subtle"><b>Frame conditioning</b><div class="frame-grid"><div><div class="small muted">First frame</div><div class="small">${esc(first.description||'Not described')}</div>${first.asset_id?`<div class="small muted">Asset: ${esc(first.asset_id)}</div>`:''}</div>${last&&Object.keys(last).length?`<div><div class="small muted">Last frame</div><div class="small">${esc(last.description||'Not described')}</div>${last.asset_id?`<div class="small muted">Asset: ${esc(last.asset_id)}</div>`:''}</div>`:''}</div></div>`}
 $('current').innerHTML=`<div class="shot-title">${esc(t.shot_id||'Shot')}</div><div class="row"><span class="pill warn">READY FOR REVIEW</span><span class="pill">${esc(mode)}</span><span class="muted">Take ${esc(String(t.take_number||''))} · ${esc(String(snap.resolution||'resolution pending'))} · ${esc(String(snap.frame_rate||'24'))} fps</span></div><div class="progress"><div class="bar" style="width:${t.progress||100}%"></div></div><div class="muted small">${esc(snap.action||'Review generated shot.')}</div>${frameHtml}<video class="video" controls preload="metadata" src="/api/takes/${encodeURIComponent(t.take_id)}/preview"></video><div class="actions"><button class="success" onclick="approve('${esc(t.take_id)}')">✓ APPROVE</button><button class="danger" onclick="reject('${esc(t.take_id)}')">✕ REJECT</button></div>`;
}
function renderTakes(takes){
 $('takes').innerHTML=takes.slice().reverse().slice(0,40).map(t=>{
  const action=t.status==='REJECTED'?`<button class="secondary" onclick="regenerate('${esc(t.take_id)}')">REGENERATE</button>`:t.status==='APPROVED'?`<button class="secondary" onclick="exportTake('${esc(t.take_id)}')">EXPORT</button>`:'';
  const mode=t.snapshot?.specification?.generation_mode||'AUTO';
  return `<div class="item"><div class="row"><div class="grow"><b>${esc(t.shot_id)}</b> <span class="muted">Take ${t.take_number}</span></div><span class="pill ${t.status==='APPROVED'?'ok':t.status==='REJECTED'||t.status==='FAILED'?'bad':t.status==='COMPLETED'?'warn':''}">${esc(t.status)}</span></div><div class="muted small">${esc(mode)} · ${t.progress||0}%</div><div class="progress"><div class="bar" style="width:${t.progress||0}%"></div></div>${action?`<div class="actions">${action}</div>`:''}</div>`
 }).join('')||'<div class="muted">No takes yet.</div>';
}
async function runMockTest(){try{const r=await api('/mock-test',{method:'POST',body:JSON.stringify({})});currentFilm=r.take.film_id;$('mockTestResult').textContent=`Mock take: ${r.take.take_id}. Waiting for controller completion…`;note(r.reused?'Using the active mock test.':'Mock shot submitted.');await refreshAll()}catch(e){note(e.message)}}
function csvIds(value){return value.split(',').map(v=>v.trim()).filter(Boolean)}
async function loadShotTemplate(){
 try{
  shotTemplate=await api('/shot-template');
  $('shotFilmId').value=shotTemplate.film_id||'';
  $('shotSceneId').value=shotTemplate.scene_id||'';
  $('shotId').value=shotTemplate.shot_id||'';
  $('shotCharacters').value=(shotTemplate.character_ids||[]).join(', ');
  $('shotVoices').value=(shotTemplate.voice_profile_ids||[]).join(', ');
  $('shotEnvironment').value=shotTemplate.environment||'';
  $('shotAction').value=shotTemplate.action||'';
  $('shotCamera').value=shotTemplate.camera||'';
  $('shotLighting').value=shotTemplate.lighting||'';
  $('shotAudio').value=shotTemplate.audio||'';
  $('shotContinuity').value=shotTemplate.continuity||'';
  $('shotDuration').value=shotTemplate.duration||8;
  $('shotResolution').value=shotTemplate.resolution||'1440p';
  $('shotAspectRatio').value=shotTemplate.aspect_ratio||'16:9';
  $('shotFrameRate').value=shotTemplate.frame_rate||24;
  $('shotQuality').value=shotTemplate.quality_preset||'LTX-2.5 Fast workhorse';
  $('shotSeed').value=shotTemplate.seed===undefined?'':shotTemplate.seed;
  return true;
 }catch(e){
  $('realShotGateMessage').textContent='Shot template could not be loaded: '+e.message;
  return false;
 }
}
function renderGenerationGate(gate){
 generationGate=gate;
 $('realShotGate').textContent=gate.enabled?'T2V READY':'LOCKED';
 $('realShotGate').className='pill '+(gate.enabled?'ok':'warn');
 $('realShotGateMessage').textContent=gate.reason||'Preflight status unavailable.';
 const enabled=Boolean(gate.enabled&&shotTemplate);
 document.querySelectorAll('#realShotForm input,#realShotForm textarea,#realShotForm select').forEach(el=>{el.disabled=!enabled});
 $('submitRealShotButton').disabled=!enabled;
 if(gate.enabled&&gate.gpu_name){
  $('realShotGateMessage').textContent=gate.reason+' Detected: '+gate.gpu_name+' · '+gate.gpu_vram_gib+' GiB VRAM.';
 }
}
function buildShotSpecification(){
 if(!shotTemplate)throw Error('Shot template is not loaded.');
 const spec=JSON.parse(JSON.stringify(shotTemplate));
 spec.film_id=$('shotFilmId').value.trim().toUpperCase();
 spec.scene_id=$('shotSceneId').value.trim().toUpperCase();
 spec.shot_id=$('shotId').value.trim().toUpperCase();
 spec.shot_type='SINGLE-SHOT';
 spec.character_ids=csvIds($('shotCharacters').value);
 spec.voice_profile_ids=csvIds($('shotVoices').value);
 spec.environment=$('shotEnvironment').value.trim();
 spec.action=$('shotAction').value.trim();
 spec.camera=$('shotCamera').value.trim();
 spec.lighting=$('shotLighting').value.trim();
 spec.audio=$('shotAudio').value.trim();
 spec.continuity=$('shotContinuity').value.trim();
 spec.duration=Number($('shotDuration').value);
 spec.resolution=$('shotResolution').value;
 spec.aspect_ratio=$('shotAspectRatio').value.trim();
 spec.frame_rate=Number($('shotFrameRate').value);
 spec.quality_preset=$('shotQuality').value.trim();
 spec.status='READY';
 spec.generation_mode='TEXT_TO_VIDEO';
 spec.reference_assets=Array.isArray(shotTemplate.reference_assets)?shotTemplate.reference_assets:[];
 delete spec.input_image;delete spec.frame_conditioning;delete spec.continuation_source;
 const seed=$('shotSeed').value.trim();
 if(seed==='')delete spec.seed;else spec.seed=Number(seed);
 return spec;
}
function newShotRequestId(){
 if(window.crypto&&typeof window.crypto.randomUUID==='function')return window.crypto.randomUUID();
 throw Error('This browser does not support secure UUID generation. Update the browser before submitting.');
}
async function submitRealShot(event){
 event.preventDefault();
 if(!generationGate||!generationGate.enabled){note('Real shot submission is locked by production preflight.');return}
 if(!$('confirmRealCost').checked){note('Confirm the real-generation cost acknowledgement first.');return}
 let spec,payload;
 try{spec=buildShotSpecification();payload=JSON.stringify(spec)}catch(e){note(e.message);return}
 if(!pendingShotRequestId||pendingShotPayload!==payload){
  try{pendingShotRequestId=newShotRequestId()}catch(e){note(e.message);return}
  pendingShotPayload=payload;
 }
 const button=$('submitRealShotButton');
 button.disabled=true;button.textContent='SUBMITTING…';
 $('realShotResult').textContent='Submitting through the secured controller…';
 try{
  const result=await api('/shots/generate',{method:'POST',body:JSON.stringify({request_id:pendingShotRequestId,specification:spec,cost_acknowledged:$('confirmRealCost').checked})});
  const take=result.take||{};
  $('realShotResult').textContent=(result.reused?'Existing submission returned: ':'Shot submitted: ')+(take.take_id||'take ID unavailable');
  note(result.message||'Shot submission accepted.');
  pendingShotRequestId=null;pendingShotPayload=null;$('confirmRealCost').checked=false;
  currentFilm=take.film_id||currentFilm;
  await refreshAll();
 }catch(e){
  $('realShotResult').textContent='Submission not confirmed: '+e.message+'. Retrying with the same request ID will not intentionally create a duplicate.';
  note(e.message);
 }finally{
  button.textContent='SUBMIT REAL SHOT';
  button.disabled=!(generationGate&&generationGate.enabled&&shotTemplate);
 }
}
function csvIds(value){return value.split(',').map(v=>v.trim()).filter(Boolean)}
async function loadShotTemplate(){
 try{
  shotTemplate=await api('/shot-template');
  $('shotFilmId').value=shotTemplate.film_id||'';
  $('shotSceneId').value=shotTemplate.scene_id||'';
  $('shotId').value=shotTemplate.shot_id||'';
  $('shotCharacters').value=(shotTemplate.character_ids||[]).join(', ');
  $('shotVoices').value=(shotTemplate.voice_profile_ids||[]).join(', ');
  $('shotEnvironment').value=shotTemplate.environment||'';
  $('shotAction').value=shotTemplate.action||'';
  $('shotCamera').value=shotTemplate.camera||'';
  $('shotLighting').value=shotTemplate.lighting||'';
  $('shotAudio').value=shotTemplate.audio||'';
  $('shotContinuity').value=shotTemplate.continuity||'';
  $('shotDuration').value=shotTemplate.duration||8;
  $('shotResolution').value=shotTemplate.resolution||'1440p';
  $('shotAspectRatio').value=shotTemplate.aspect_ratio||'16:9';
  $('shotFrameRate').value=shotTemplate.frame_rate||24;
  $('shotQuality').value=shotTemplate.quality_preset||'LTX-2.5 Fast workhorse';
  $('shotSeed').value=shotTemplate.seed===undefined?'':shotTemplate.seed;
  return true;
 }catch(e){
  $('realShotGateMessage').textContent='Shot template could not be loaded: '+e.message;
  return false;
 }
}
function renderGenerationGate(gate){
 generationGate=gate;
 $('realShotGate').textContent=gate.enabled?'T2V READY':'LOCKED';
 $('realShotGate').className='pill '+(gate.enabled?'ok':'warn');
 $('realShotGateMessage').textContent=gate.reason||'Preflight status unavailable.';
 const enabled=Boolean(gate.enabled&&shotTemplate);
 document.querySelectorAll('#realShotForm input,#realShotForm textarea,#realShotForm select').forEach(el=>{el.disabled=!enabled});
 $('submitRealShotButton').disabled=!enabled;
 if(gate.enabled&&gate.gpu_name){
  $('realShotGateMessage').textContent=gate.reason+' Detected: '+gate.gpu_name+' · '+gate.gpu_vram_gib+' GiB VRAM.';
 }
}
function buildShotSpecification(){
 if(!shotTemplate)throw Error('Shot template is not loaded.');
 const spec=JSON.parse(JSON.stringify(shotTemplate));
 spec.film_id=$('shotFilmId').value.trim().toUpperCase();
 spec.scene_id=$('shotSceneId').value.trim().toUpperCase();
 spec.shot_id=$('shotId').value.trim().toUpperCase();
 spec.shot_type='SINGLE-SHOT';
 spec.character_ids=csvIds($('shotCharacters').value);
 spec.voice_profile_ids=csvIds($('shotVoices').value);
 spec.environment=$('shotEnvironment').value.trim();
 spec.action=$('shotAction').value.trim();
 spec.camera=$('shotCamera').value.trim();
 spec.lighting=$('shotLighting').value.trim();
 spec.audio=$('shotAudio').value.trim();
 spec.continuity=$('shotContinuity').value.trim();
 spec.duration=Number($('shotDuration').value);
 spec.resolution=$('shotResolution').value;
 spec.aspect_ratio=$('shotAspectRatio').value.trim();
 spec.frame_rate=Number($('shotFrameRate').value);
 spec.quality_preset=$('shotQuality').value.trim();
 spec.status='READY';
 spec.generation_mode='TEXT_TO_VIDEO';
 spec.reference_assets=Array.isArray(shotTemplate.reference_assets)?shotTemplate.reference_assets:[];
 delete spec.input_image;delete spec.frame_conditioning;delete spec.continuation_source;
 const seed=$('shotSeed').value.trim();
 if(seed==='')delete spec.seed;else spec.seed=Number(seed);
 return spec;
}
function newShotRequestId(){
 if(window.crypto&&typeof window.crypto.randomUUID==='function')return window.crypto.randomUUID();
 throw Error('This browser does not support secure UUID generation. Update the browser before submitting.');
}
async function submitRealShot(event){
 event.preventDefault();
 if(!generationGate||!generationGate.enabled){note('Real shot submission is locked by production preflight.');return}
 if(!$('confirmRealCost').checked){note('Confirm the real-generation cost acknowledgement first.');return}
 let spec,payload;
 try{spec=buildShotSpecification();payload=JSON.stringify(spec)}catch(e){note(e.message);return}
 if(!pendingShotRequestId||pendingShotPayload!==payload){
  try{pendingShotRequestId=newShotRequestId()}catch(e){note(e.message);return}
  pendingShotPayload=payload;
 }
 const button=$('submitRealShotButton');
 button.disabled=true;button.textContent='SUBMITTING…';
 $('realShotResult').textContent='Submitting through the secured controller…';
 try{
  const result=await api('/shots/generate',{method:'POST',body:JSON.stringify({request_id:pendingShotRequestId,specification:spec,cost_acknowledged:$('confirmRealCost').checked})});
  const take=result.take||{};
  $('realShotResult').textContent=(result.reused?'Existing submission returned: ':'Shot submitted: ')+(take.take_id||'take ID unavailable');
  note(result.message||'Shot submission accepted.');
  pendingShotRequestId=null;pendingShotPayload=null;$('confirmRealCost').checked=false;
  currentFilm=take.film_id||currentFilm;
  await refreshAll();
 }catch(e){
  $('realShotResult').textContent='Submission not confirmed: '+e.message+'. Retrying with the same request ID will not intentionally create a duplicate.';
  note(e.message);
 }finally{
  button.textContent='SUBMIT REAL SHOT';
  button.disabled=!(generationGate&&generationGate.enabled&&shotTemplate);
 }
}
function csvIds(value){return value.split(',').map(v=>v.trim()).filter(Boolean)}
async function loadShotTemplate(){
 try{
  shotTemplate=await api('/shot-template');
  $('shotFilmId').value=shotTemplate.film_id||'';
  $('shotSceneId').value=shotTemplate.scene_id||'';
  $('shotId').value=shotTemplate.shot_id||'';
  $('shotCharacters').value=(shotTemplate.character_ids||[]).join(', ');
  $('shotVoices').value=(shotTemplate.voice_profile_ids||[]).join(', ');
  $('shotEnvironment').value=shotTemplate.environment||'';
  $('shotAction').value=shotTemplate.action||'';
  $('shotCamera').value=shotTemplate.camera||'';
  $('shotLighting').value=shotTemplate.lighting||'';
  $('shotAudio').value=shotTemplate.audio||'';
  $('shotContinuity').value=shotTemplate.continuity||'';
  $('shotDuration').value=shotTemplate.duration||8;
  $('shotResolution').value=shotTemplate.resolution||'1440p';
  $('shotAspectRatio').value=shotTemplate.aspect_ratio||'16:9';
  $('shotFrameRate').value=shotTemplate.frame_rate||24;
  $('shotSeed').value=shotTemplate.seed===undefined?0:shotTemplate.seed;
  return true;
 }catch(e){
  $('realShotGateMessage').textContent='Shot template could not be loaded: '+e.message;
  return false;
 }
}
function renderGenerationGate(gate){
 generationGate=gate;
 $('realShotGate').textContent=gate.enabled?'T2V READY':'LOCKED';
 $('realShotGate').className='pill '+(gate.enabled?'ok':'warn');
 $('realShotGateMessage').textContent=gate.reason||'Preflight status unavailable.';
 const enabled=Boolean(gate.enabled&&shotTemplate);
 document.querySelectorAll('#realShotForm input,#realShotForm textarea,#realShotForm select').forEach(el=>{el.disabled=!enabled});
 $('submitRealShotButton').disabled=!enabled;
 if(gate.enabled&&gate.gpu_name){
  $('realShotGateMessage').textContent=gate.reason+' Detected: '+gate.gpu_name+' · '+gate.gpu_vram_gib+' GiB VRAM.';
 }
}
function buildShotSpecification(){
 if(!shotTemplate)throw Error('Shot template is not loaded.');
 const spec=JSON.parse(JSON.stringify(shotTemplate));
 spec.film_id=$('shotFilmId').value.trim().toUpperCase();
 spec.scene_id=$('shotSceneId').value.trim().toUpperCase();
 spec.shot_id=$('shotId').value.trim().toUpperCase();
 spec.shot_type='SINGLE-SHOT';
 spec.character_ids=csvIds($('shotCharacters').value);
 spec.voice_profile_ids=csvIds($('shotVoices').value);
 spec.environment=$('shotEnvironment').value.trim();
 spec.action=$('shotAction').value.trim();
 spec.camera=$('shotCamera').value.trim();
 spec.lighting=$('shotLighting').value.trim();
 spec.audio=$('shotAudio').value.trim();
 spec.continuity=$('shotContinuity').value.trim();
 spec.duration=Number($('shotDuration').value);
 spec.resolution=$('shotResolution').value;
 spec.aspect_ratio=$('shotAspectRatio').value.trim();
 spec.frame_rate=Number($('shotFrameRate').value);
 delete spec.quality_preset;
 spec.status='READY';
 spec.generation_mode='TEXT_TO_VIDEO';
 spec.reference_assets=Array.isArray(shotTemplate.reference_assets)?shotTemplate.reference_assets:[];
 delete spec.input_image;delete spec.frame_conditioning;delete spec.continuation_source;
 const seed=$('shotSeed').value.trim();
 if(seed==='')throw Error('A numeric seed is required for the approved T2V mapping.');
 spec.seed=Number(seed);
 return spec;
}
function newShotRequestId(){
 if(window.crypto&&typeof window.crypto.randomUUID==='function')return window.crypto.randomUUID();
 throw Error('This browser does not support secure UUID generation. Update the browser before submitting.');
}
async function submitRealShot(event){
 event.preventDefault();
 if(!generationGate||!generationGate.enabled){note('Real shot submission is locked by production preflight.');return}
 if(!$('confirmRealCost').checked){note('Confirm the real-generation cost acknowledgement first.');return}
 let spec,payload;
 try{spec=buildShotSpecification();payload=JSON.stringify(spec)}catch(e){note(e.message);return}
 if(!pendingShotRequestId||pendingShotPayload!==payload){
  try{pendingShotRequestId=newShotRequestId()}catch(e){note(e.message);return}
  pendingShotPayload=payload;
 }
 const button=$('submitRealShotButton');
 button.disabled=true;button.textContent='SUBMITTING…';
 $('realShotResult').textContent='Submitting through the secured controller…';
 try{
  const result=await api('/shots/generate',{method:'POST',body:JSON.stringify({request_id:pendingShotRequestId,specification:spec,cost_acknowledged:$('confirmRealCost').checked})});
  const take=result.take||{};
  $('realShotResult').textContent=(result.reused?'Existing submission returned: ':'Shot submitted: ')+(take.take_id||'take ID unavailable');
  note(result.message||'Shot submission accepted.');
  pendingShotRequestId=null;pendingShotPayload=null;$('confirmRealCost').checked=false;
  currentFilm=take.film_id||currentFilm;
  await refreshAll();
 }catch(e){
  $('realShotResult').textContent='Submission not confirmed: '+e.message+'. Retrying with the same request ID will not intentionally create a duplicate.';
  note(e.message);
 }finally{
  button.textContent='SUBMIT REAL SHOT';
  button.disabled=!(generationGate&&generationGate.enabled&&shotTemplate);
 }
}
function csvIds(value){return value.split(',').map(v=>v.trim()).filter(Boolean)}
async function loadShotTemplate(){
 try{
  shotTemplate=await api('/shot-template');
  $('shotFilmId').value=shotTemplate.film_id||'';
  $('shotSceneId').value=shotTemplate.scene_id||'';
  $('shotId').value=shotTemplate.shot_id||'';
  $('shotCharacters').value=(shotTemplate.character_ids||[]).join(', ');
  $('shotVoices').value=(shotTemplate.voice_profile_ids||[]).join(', ');
  $('shotEnvironment').value=shotTemplate.environment||'';
  $('shotAction').value=shotTemplate.action||'';
  $('shotCamera').value=shotTemplate.camera||'';
  $('shotLighting').value=shotTemplate.lighting||'';
  $('shotAudio').value=shotTemplate.audio||'';
  $('shotContinuity').value=shotTemplate.continuity||'';
  $('shotDuration').value=shotTemplate.duration||8;
  $('shotResolution').value=shotTemplate.resolution||'1440p';
  $('shotAspectRatio').value=shotTemplate.aspect_ratio||'16:9';
  $('shotFrameRate').value=shotTemplate.frame_rate||24;
  $('shotSeed').value=shotTemplate.seed===undefined?0:shotTemplate.seed;
  return true;
 }catch(e){
  $('realShotGateMessage').textContent='Shot template could not be loaded: '+e.message;
  return false;
 }
}
function renderGenerationGate(gate){
 generationGate=gate;
 $('realShotGate').textContent=gate.enabled?'T2V READY':'LOCKED';
 $('realShotGate').className='pill '+(gate.enabled?'ok':'warn');
 $('realShotGateMessage').textContent=gate.reason||'Preflight status unavailable.';
 const enabled=Boolean(gate.enabled&&shotTemplate);
 document.querySelectorAll('#realShotForm input,#realShotForm textarea,#realShotForm select').forEach(el=>{el.disabled=!enabled});
 $('submitRealShotButton').disabled=!enabled;
 if(gate.enabled&&gate.gpu_name){
  $('realShotGateMessage').textContent=gate.reason+' Detected: '+gate.gpu_name+' · '+gate.gpu_vram_gib+' GiB VRAM.';
 }
}
function buildShotSpecification(){
 if(!shotTemplate)throw Error('Shot template is not loaded.');
 const spec=JSON.parse(JSON.stringify(shotTemplate));
 spec.film_id=$('shotFilmId').value.trim().toUpperCase();
 spec.scene_id=$('shotSceneId').value.trim().toUpperCase();
 spec.shot_id=$('shotId').value.trim().toUpperCase();
 spec.shot_type='SINGLE-SHOT';
 spec.character_ids=csvIds($('shotCharacters').value);
 spec.voice_profile_ids=csvIds($('shotVoices').value);
 spec.environment=$('shotEnvironment').value.trim();
 spec.action=$('shotAction').value.trim();
 spec.camera=$('shotCamera').value.trim();
 spec.lighting=$('shotLighting').value.trim();
 spec.audio=$('shotAudio').value.trim();
 spec.continuity=$('shotContinuity').value.trim();
 spec.duration=Number($('shotDuration').value);
 spec.resolution=$('shotResolution').value;
 spec.aspect_ratio=$('shotAspectRatio').value.trim();
 spec.frame_rate=Number($('shotFrameRate').value);
 delete spec.quality_preset;
 spec.status='READY';
 spec.generation_mode='TEXT_TO_VIDEO';
 spec.reference_assets=Array.isArray(shotTemplate.reference_assets)?shotTemplate.reference_assets:[];
 delete spec.input_image;delete spec.frame_conditioning;delete spec.continuation_source;
 const seed=$('shotSeed').value.trim();
 if(seed==='')throw Error('A numeric seed is required for the approved T2V mapping.');
 spec.seed=Number(seed);
 return spec;
}
function newShotRequestId(){
 if(window.crypto&&typeof window.crypto.randomUUID==='function')return window.crypto.randomUUID();
 throw Error('This browser does not support secure UUID generation. Update the browser before submitting.');
}
async function submitRealShot(event){
 event.preventDefault();
 if(!generationGate||!generationGate.enabled){note('Real shot submission is locked by production preflight.');return}
 if(!$('confirmRealCost').checked){note('Confirm the real-generation cost acknowledgement first.');return}
 let spec,payload;
 try{spec=buildShotSpecification();payload=JSON.stringify(spec)}catch(e){note(e.message);return}
 if(!pendingShotRequestId||pendingShotPayload!==payload){
  try{pendingShotRequestId=newShotRequestId()}catch(e){note(e.message);return}
  pendingShotPayload=payload;
 }
 const button=$('submitRealShotButton');
 button.disabled=true;button.textContent='SUBMITTING…';
 $('realShotResult').textContent='Submitting through the secured controller…';
 try{
  const result=await api('/shots/generate',{method:'POST',body:JSON.stringify({request_id:pendingShotRequestId,specification:spec,cost_acknowledged:$('confirmRealCost').checked})});
  const take=result.take||{};
  $('realShotResult').textContent=(result.reused?'Existing submission returned: ':'Shot submitted: ')+(take.take_id||'take ID unavailable');
  note(result.message||'Shot submission accepted.');
  pendingShotRequestId=null;pendingShotPayload=null;$('confirmRealCost').checked=false;
  currentFilm=take.film_id||currentFilm;
  await refreshAll();
 }catch(e){
  $('realShotResult').textContent='Submission not confirmed: '+e.message+'. Retrying with the same request ID will not intentionally create a duplicate.';
  note(e.message);
 }finally{
  button.textContent='SUBMIT REAL SHOT';
  button.disabled=!(generationGate&&generationGate.enabled&&shotTemplate);
 }
}
function csvIds(value){return value.split(',').map(v=>v.trim()).filter(Boolean)}
async function loadShotTemplate(){
 try{
  shotTemplate=await api('/shot-template');
  $('shotFilmId').value=shotTemplate.film_id||'';
  $('shotSceneId').value=shotTemplate.scene_id||'';
  $('shotId').value=shotTemplate.shot_id||'';
  $('shotCharacters').value=(shotTemplate.character_ids||[]).join(', ');
  $('shotVoices').value=(shotTemplate.voice_profile_ids||[]).join(', ');
  $('shotEnvironment').value=shotTemplate.environment||'';
  $('shotAction').value=shotTemplate.action||'';
  $('shotCamera').value=shotTemplate.camera||'';
  $('shotLighting').value=shotTemplate.lighting||'';
  $('shotAudio').value=shotTemplate.audio||'';
  $('shotContinuity').value=shotTemplate.continuity||'';
  $('shotDuration').value=shotTemplate.duration||8;
  $('shotResolution').value=shotTemplate.resolution||'1440p';
  $('shotAspectRatio').value=shotTemplate.aspect_ratio||'16:9';
  $('shotFrameRate').value=shotTemplate.frame_rate||24;
  $('shotSeed').value=shotTemplate.seed===undefined?0:shotTemplate.seed;
  return true;
 }catch(e){
  $('realShotGateMessage').textContent='Shot template could not be loaded: '+e.message;
  return false;
 }
}
function renderGenerationGate(gate){
 generationGate=gate;
 $('realShotGate').textContent=gate.enabled?'T2V READY':'LOCKED';
 $('realShotGate').className='pill '+(gate.enabled?'ok':'warn');
 $('realShotGateMessage').textContent=gate.reason||'Preflight status unavailable.';
 const enabled=Boolean(gate.enabled&&shotTemplate);
 document.querySelectorAll('#realShotForm input,#realShotForm textarea,#realShotForm select').forEach(el=>{el.disabled=!enabled});
 $('submitRealShotButton').disabled=!enabled;
 if(gate.enabled&&gate.gpu_name){
  $('realShotGateMessage').textContent=gate.reason+' Detected: '+gate.gpu_name+' · '+gate.gpu_vram_gib+' GiB VRAM.';
 }
}
function buildShotSpecification(){
 if(!shotTemplate)throw Error('Shot template is not loaded.');
 const spec=JSON.parse(JSON.stringify(shotTemplate));
 spec.film_id=$('shotFilmId').value.trim().toUpperCase();
 spec.scene_id=$('shotSceneId').value.trim().toUpperCase();
 spec.shot_id=$('shotId').value.trim().toUpperCase();
 spec.shot_type='SINGLE-SHOT';
 spec.character_ids=csvIds($('shotCharacters').value);
 spec.voice_profile_ids=csvIds($('shotVoices').value);
 spec.environment=$('shotEnvironment').value.trim();
 spec.action=$('shotAction').value.trim();
 spec.camera=$('shotCamera').value.trim();
 spec.lighting=$('shotLighting').value.trim();
 spec.audio=$('shotAudio').value.trim();
 spec.continuity=$('shotContinuity').value.trim();
 spec.duration=Number($('shotDuration').value);
 spec.resolution=$('shotResolution').value;
 spec.aspect_ratio=$('shotAspectRatio').value.trim();
 spec.frame_rate=Number($('shotFrameRate').value);
 delete spec.quality_preset;
 spec.status='READY';
 spec.generation_mode='TEXT_TO_VIDEO';
 spec.reference_assets=Array.isArray(shotTemplate.reference_assets)?shotTemplate.reference_assets:[];
 delete spec.input_image;delete spec.frame_conditioning;delete spec.continuation_source;
 const seed=$('shotSeed').value.trim();
 if(seed==='')throw Error('A numeric seed is required for the approved T2V mapping.');
 spec.seed=Number(seed);
 return spec;
}
function newShotRequestId(){
 if(window.crypto&&typeof window.crypto.randomUUID==='function')return window.crypto.randomUUID();
 throw Error('This browser does not support secure UUID generation. Update the browser before submitting.');
}
async function submitRealShot(event){
 event.preventDefault();
 if(!generationGate||!generationGate.enabled){note('Real shot submission is locked by production preflight.');return}
 if(!$('confirmRealCost').checked){note('Confirm the real-generation cost acknowledgement first.');return}
 let spec,payload;
 try{spec=buildShotSpecification();payload=JSON.stringify(spec)}catch(e){note(e.message);return}
 if(!pendingShotRequestId||pendingShotPayload!==payload){
  try{pendingShotRequestId=newShotRequestId()}catch(e){note(e.message);return}
  pendingShotPayload=payload;
 }
 const button=$('submitRealShotButton');
 button.disabled=true;button.textContent='SUBMITTING…';
 $('realShotResult').textContent='Submitting through the secured controller…';
 try{
  const result=await api('/shots/generate',{method:'POST',body:JSON.stringify({request_id:pendingShotRequestId,specification:spec,cost_acknowledged:$('confirmRealCost').checked})});
  const take=result.take||{};
  $('realShotResult').textContent=(result.reused?'Existing submission returned: ':'Shot submitted: ')+(take.take_id||'take ID unavailable');
  note(result.message||'Shot submission accepted.');
  pendingShotRequestId=null;pendingShotPayload=null;$('confirmRealCost').checked=false;
  currentFilm=take.film_id||currentFilm;
  await refreshAll();
 }catch(e){
  $('realShotResult').textContent='Submission not confirmed: '+e.message+'. Retrying with the same request ID will not intentionally create a duplicate.';
  note(e.message);
 }finally{
  button.textContent='SUBMIT REAL SHOT';
  button.disabled=!(generationGate&&generationGate.enabled&&shotTemplate);
 }
}
function csvIds(value){return value.split(',').map(v=>v.trim()).filter(Boolean)}
async function loadShotTemplate(){
 try{
  shotTemplate=await api('/shot-template');
  $('shotFilmId').value=shotTemplate.film_id||'';
  $('shotSceneId').value=shotTemplate.scene_id||'';
  $('shotId').value=shotTemplate.shot_id||'';
  $('shotCharacters').value=(shotTemplate.character_ids||[]).join(', ');
  $('shotVoices').value=(shotTemplate.voice_profile_ids||[]).join(', ');
  $('shotEnvironment').value=shotTemplate.environment||'';
  $('shotAction').value=shotTemplate.action||'';
  $('shotCamera').value=shotTemplate.camera||'';
  $('shotLighting').value=shotTemplate.lighting||'';
  $('shotAudio').value=shotTemplate.audio||'';
  $('shotContinuity').value=shotTemplate.continuity||'';
  $('shotDuration').value=shotTemplate.duration||8;
  $('shotResolution').value=shotTemplate.resolution||'1440p';
  $('shotAspectRatio').value=shotTemplate.aspect_ratio||'16:9';
  $('shotFrameRate').value=shotTemplate.frame_rate||24;
  $('shotSeed').value=shotTemplate.seed===undefined?0:shotTemplate.seed;
  return true;
 }catch(e){
  $('realShotGateMessage').textContent='Shot template could not be loaded: '+e.message;
  return false;
 }
}
function renderGenerationGate(gate){
 generationGate=gate;
 $('realShotGate').textContent=gate.enabled?'T2V READY':'LOCKED';
 $('realShotGate').className='pill '+(gate.enabled?'ok':'warn');
 $('realShotGateMessage').textContent=gate.reason||'Preflight status unavailable.';
 const enabled=Boolean(gate.enabled&&shotTemplate);
 document.querySelectorAll('#realShotForm input,#realShotForm textarea,#realShotForm select').forEach(el=>{el.disabled=!enabled});
 $('submitRealShotButton').disabled=!enabled;
 if(gate.enabled&&gate.gpu_name){
  $('realShotGateMessage').textContent=gate.reason+' Detected: '+gate.gpu_name+' · '+gate.gpu_vram_gib+' GiB VRAM.';
 }
}
function buildShotSpecification(){
 if(!shotTemplate)throw Error('Shot template is not loaded.');
 const spec=JSON.parse(JSON.stringify(shotTemplate));
 spec.film_id=$('shotFilmId').value.trim().toUpperCase();
 spec.scene_id=$('shotSceneId').value.trim().toUpperCase();
 spec.shot_id=$('shotId').value.trim().toUpperCase();
 spec.shot_type='SINGLE-SHOT';
 spec.character_ids=csvIds($('shotCharacters').value);
 spec.voice_profile_ids=csvIds($('shotVoices').value);
 spec.environment=$('shotEnvironment').value.trim();
 spec.action=$('shotAction').value.trim();
 spec.camera=$('shotCamera').value.trim();
 spec.lighting=$('shotLighting').value.trim();
 spec.audio=$('shotAudio').value.trim();
 spec.continuity=$('shotContinuity').value.trim();
 spec.duration=Number($('shotDuration').value);
 spec.resolution=$('shotResolution').value;
 spec.aspect_ratio=$('shotAspectRatio').value.trim();
 spec.frame_rate=Number($('shotFrameRate').value);
 delete spec.quality_preset;
 spec.status='READY';
 spec.generation_mode='TEXT_TO_VIDEO';
 spec.reference_assets=Array.isArray(shotTemplate.reference_assets)?shotTemplate.reference_assets:[];
 delete spec.input_image;delete spec.frame_conditioning;delete spec.continuation_source;
 const seed=$('shotSeed').value.trim();
 if(seed==='')throw Error('A numeric seed is required for the approved T2V mapping.');
 spec.seed=Number(seed);
 return spec;
}
function newShotRequestId(){
 if(window.crypto&&typeof window.crypto.randomUUID==='function')return window.crypto.randomUUID();
 throw Error('This browser does not support secure UUID generation. Update the browser before submitting.');
}
async function submitRealShot(event){
 event.preventDefault();
 if(!generationGate||!generationGate.enabled){note('Real shot submission is locked by production preflight.');return}
 if(!$('confirmRealCost').checked){note('Confirm the real-generation cost acknowledgement first.');return}
 let spec,payload;
 try{spec=buildShotSpecification();payload=JSON.stringify(spec)}catch(e){note(e.message);return}
 if(!pendingShotRequestId||pendingShotPayload!==payload){
  try{pendingShotRequestId=newShotRequestId()}catch(e){note(e.message);return}
  pendingShotPayload=payload;
 }
 const button=$('submitRealShotButton');
 button.disabled=true;button.textContent='SUBMITTING…';
 $('realShotResult').textContent='Submitting through the secured controller…';
 try{
  const result=await api('/shots/generate',{method:'POST',body:JSON.stringify({request_id:pendingShotRequestId,specification:spec,cost_acknowledged:$('confirmRealCost').checked})});
  const take=result.take||{};
  $('realShotResult').textContent=(result.reused?'Existing submission returned: ':'Shot submitted: ')+(take.take_id||'take ID unavailable');
  note(result.message||'Shot submission accepted.');
  pendingShotRequestId=null;pendingShotPayload=null;$('confirmRealCost').checked=false;
  currentFilm=take.film_id||currentFilm;
  await refreshAll();
 }catch(e){
  $('realShotResult').textContent='Submission not confirmed: '+e.message+'. Retrying with the same request ID will not intentionally create a duplicate.';
  note(e.message);
 }finally{
  button.textContent='SUBMIT REAL SHOT';
  button.disabled=!(generationGate&&generationGate.enabled&&shotTemplate);
 }
}
function csvIds(value){return value.split(',').map(v=>v.trim()).filter(Boolean)}
async function loadShotTemplate(){
 try{
  shotTemplate=await api('/shot-template');
  $('shotFilmId').value=shotTemplate.film_id||'';
  $('shotSceneId').value=shotTemplate.scene_id||'';
  $('shotId').value=shotTemplate.shot_id||'';
  $('shotCharacters').value=(shotTemplate.character_ids||[]).join(', ');
  $('shotVoices').value=(shotTemplate.voice_profile_ids||[]).join(', ');
  $('shotEnvironment').value=shotTemplate.environment||'';
  $('shotAction').value=shotTemplate.action||'';
  $('shotCamera').value=shotTemplate.camera||'';
  $('shotLighting').value=shotTemplate.lighting||'';
  $('shotAudio').value=shotTemplate.audio||'';
  $('shotContinuity').value=shotTemplate.continuity||'';
  $('shotDuration').value=shotTemplate.duration||8;
  $('shotResolution').value=shotTemplate.resolution||'1440p';
  $('shotAspectRatio').value=shotTemplate.aspect_ratio||'16:9';
  $('shotFrameRate').value=shotTemplate.frame_rate||24;
  $('shotSeed').value=shotTemplate.seed===undefined?0:shotTemplate.seed;
  return true;
 }catch(e){
  $('realShotGateMessage').textContent='Shot template could not be loaded: '+e.message;
  return false;
 }
}
function renderGenerationGate(gate){
 generationGate=gate;
 $('realShotGate').textContent=gate.enabled?'T2V READY':'LOCKED';
 $('realShotGate').className='pill '+(gate.enabled?'ok':'warn');
 $('realShotGateMessage').textContent=gate.reason||'Preflight status unavailable.';
 const enabled=Boolean(gate.enabled&&shotTemplate);
 document.querySelectorAll('#realShotForm input,#realShotForm textarea,#realShotForm select').forEach(el=>{el.disabled=!enabled});
 $('submitRealShotButton').disabled=!enabled;
 if(gate.enabled&&gate.gpu_name){
  $('realShotGateMessage').textContent=gate.reason+' Detected: '+gate.gpu_name+' · '+gate.gpu_vram_gib+' GiB VRAM.';
 }
}
function buildShotSpecification(){
 if(!shotTemplate)throw Error('Shot template is not loaded.');
 const spec=JSON.parse(JSON.stringify(shotTemplate));
 spec.film_id=$('shotFilmId').value.trim().toUpperCase();
 spec.scene_id=$('shotSceneId').value.trim().toUpperCase();
 spec.shot_id=$('shotId').value.trim().toUpperCase();
 spec.shot_type='SINGLE-SHOT';
 spec.character_ids=csvIds($('shotCharacters').value);
 spec.voice_profile_ids=csvIds($('shotVoices').value);
 spec.environment=$('shotEnvironment').value.trim();
 spec.action=$('shotAction').value.trim();
 spec.camera=$('shotCamera').value.trim();
 spec.lighting=$('shotLighting').value.trim();
 spec.audio=$('shotAudio').value.trim();
 spec.continuity=$('shotContinuity').value.trim();
 spec.duration=Number($('shotDuration').value);
 spec.resolution=$('shotResolution').value;
 spec.aspect_ratio=$('shotAspectRatio').value.trim();
 spec.frame_rate=Number($('shotFrameRate').value);
 delete spec.quality_preset;
 spec.status='READY';
 spec.generation_mode='TEXT_TO_VIDEO';
 spec.reference_assets=Array.isArray(shotTemplate.reference_assets)?shotTemplate.reference_assets:[];
 delete spec.input_image;delete spec.frame_conditioning;delete spec.continuation_source;
 const seed=$('shotSeed').value.trim();
 if(seed==='')throw Error('A numeric seed is required for the approved T2V mapping.');
 spec.seed=Number(seed);
 return spec;
}
function newShotRequestId(){
 if(window.crypto&&typeof window.crypto.randomUUID==='function')return window.crypto.randomUUID();
 throw Error('This browser does not support secure UUID generation. Update the browser before submitting.');
}
async function submitRealShot(event){
 event.preventDefault();
 if(!generationGate||!generationGate.enabled){note('Real shot submission is locked by production preflight.');return}
 if(!$('confirmRealCost').checked){note('Confirm the real-generation cost acknowledgement first.');return}
 let spec,payload;
 try{spec=buildShotSpecification();payload=JSON.stringify(spec)}catch(e){note(e.message);return}
 if(!pendingShotRequestId||pendingShotPayload!==payload){
  try{pendingShotRequestId=newShotRequestId()}catch(e){note(e.message);return}
  pendingShotPayload=payload;
 }
 const button=$('submitRealShotButton');
 button.disabled=true;button.textContent='SUBMITTING…';
 $('realShotResult').textContent='Submitting through the secured controller…';
 try{
  const result=await api('/shots/generate',{method:'POST',body:JSON.stringify({request_id:pendingShotRequestId,specification:spec,cost_acknowledged:$('confirmRealCost').checked})});
  const take=result.take||{};
  $('realShotResult').textContent=(result.reused?'Existing submission returned: ':'Shot submitted: ')+(take.take_id||'take ID unavailable');
  note(result.message||'Shot submission accepted.');
  pendingShotRequestId=null;pendingShotPayload=null;$('confirmRealCost').checked=false;
  currentFilm=take.film_id||currentFilm;
  await refreshAll();
 }catch(e){
  $('realShotResult').textContent='Submission not confirmed: '+e.message+'. Retrying with the same request ID will not intentionally create a duplicate.';
  note(e.message);
 }finally{
  button.textContent='SUBMIT REAL SHOT';
  button.disabled=!(generationGate&&generationGate.enabled&&shotTemplate);
 }
}
function csvIds(value){return value.split(',').map(v=>v.trim()).filter(Boolean)}
async function loadShotTemplate(){
 try{
  shotTemplate=await api('/shot-template');
  $('shotFilmId').value=shotTemplate.film_id||'';
  $('shotSceneId').value=shotTemplate.scene_id||'';
  $('shotId').value=shotTemplate.shot_id||'';
  $('shotCharacters').value=(shotTemplate.character_ids||[]).join(', ');
  $('shotVoices').value=(shotTemplate.voice_profile_ids||[]).join(', ');
  $('shotEnvironment').value=shotTemplate.environment||'';
  $('shotAction').value=shotTemplate.action||'';
  $('shotCamera').value=shotTemplate.camera||'';
  $('shotLighting').value=shotTemplate.lighting||'';
  $('shotAudio').value=shotTemplate.audio||'';
  $('shotContinuity').value=shotTemplate.continuity||'';
  $('shotDuration').value=shotTemplate.duration||8;
  $('shotResolution').value=shotTemplate.resolution||'1440p';
  $('shotAspectRatio').value=shotTemplate.aspect_ratio||'16:9';
  $('shotFrameRate').value=shotTemplate.frame_rate||24;
  $('shotSeed').value=shotTemplate.seed===undefined?0:shotTemplate.seed;
  return true;
 }catch(e){
  $('realShotGateMessage').textContent='Shot template could not be loaded: '+e.message;
  return false;
 }
}
function renderGenerationGate(gate){
 generationGate=gate;
 $('realShotGate').textContent=gate.enabled?'T2V READY':'LOCKED';
 $('realShotGate').className='pill '+(gate.enabled?'ok':'warn');
 $('realShotGateMessage').textContent=gate.reason||'Preflight status unavailable.';
 const enabled=Boolean(gate.enabled&&shotTemplate);
 document.querySelectorAll('#realShotForm input,#realShotForm textarea,#realShotForm select').forEach(el=>{el.disabled=!enabled});
 $('submitRealShotButton').disabled=!enabled;
 if(gate.enabled&&gate.gpu_name){
  $('realShotGateMessage').textContent=gate.reason+' Detected: '+gate.gpu_name+' · '+gate.gpu_vram_gib+' GiB VRAM.';
 }
}
function buildShotSpecification(){
 if(!shotTemplate)throw Error('Shot template is not loaded.');
 const spec=JSON.parse(JSON.stringify(shotTemplate));
 spec.film_id=$('shotFilmId').value.trim().toUpperCase();
 spec.scene_id=$('shotSceneId').value.trim().toUpperCase();
 spec.shot_id=$('shotId').value.trim().toUpperCase();
 spec.shot_type='SINGLE-SHOT';
 spec.character_ids=csvIds($('shotCharacters').value);
 spec.voice_profile_ids=csvIds($('shotVoices').value);
 spec.environment=$('shotEnvironment').value.trim();
 spec.action=$('shotAction').value.trim();
 spec.camera=$('shotCamera').value.trim();
 spec.lighting=$('shotLighting').value.trim();
 spec.audio=$('shotAudio').value.trim();
 spec.continuity=$('shotContinuity').value.trim();
 spec.duration=Number($('shotDuration').value);
 spec.resolution=$('shotResolution').value;
 spec.aspect_ratio=$('shotAspectRatio').value.trim();
 spec.frame_rate=Number($('shotFrameRate').value);
 delete spec.quality_preset;
 spec.status='READY';
 spec.generation_mode='TEXT_TO_VIDEO';
 spec.reference_assets=Array.isArray(shotTemplate.reference_assets)?shotTemplate.reference_assets:[];
 delete spec.input_image;delete spec.frame_conditioning;delete spec.continuation_source;
 const seed=$('shotSeed').value.trim();
 if(seed==='')throw Error('A numeric seed is required for the approved T2V mapping.');
 spec.seed=Number(seed);
 return spec;
}
function newShotRequestId(){
 if(window.crypto&&typeof window.crypto.randomUUID==='function')return window.crypto.randomUUID();
 throw Error('This browser does not support secure UUID generation. Update the browser before submitting.');
}
async function submitRealShot(event){
 event.preventDefault();
 if(!generationGate||!generationGate.enabled){note('Real shot submission is locked by production preflight.');return}
 if(!$('confirmRealCost').checked){note('Confirm the real-generation cost acknowledgement first.');return}
 let spec,payload;
 try{spec=buildShotSpecification();payload=JSON.stringify(spec)}catch(e){note(e.message);return}
 if(!pendingShotRequestId||pendingShotPayload!==payload){
  try{pendingShotRequestId=newShotRequestId()}catch(e){note(e.message);return}
  pendingShotPayload=payload;
 }
 const button=$('submitRealShotButton');
 button.disabled=true;button.textContent='SUBMITTING…';
 $('realShotResult').textContent='Submitting through the secured controller…';
 try{
  const result=await api('/shots/generate',{method:'POST',body:JSON.stringify({request_id:pendingShotRequestId,specification:spec,cost_acknowledged:$('confirmRealCost').checked})});
  const take=result.take||{};
  $('realShotResult').textContent=(result.reused?'Existing submission returned: ':'Shot submitted: ')+(take.take_id||'take ID unavailable');
  note(result.message||'Shot submission accepted.');
  pendingShotRequestId=null;pendingShotPayload=null;$('confirmRealCost').checked=false;
  currentFilm=take.film_id||currentFilm;
  await refreshAll();
 }catch(e){
  $('realShotResult').textContent='Submission not confirmed: '+e.message+'. Retrying with the same request ID will not intentionally create a duplicate.';
  note(e.message);
 }finally{
  button.textContent='SUBMIT REAL SHOT';
  button.disabled=!(generationGate&&generationGate.enabled&&shotTemplate);
 }
}
function csvIds(value){return value.split(',').map(v=>v.trim()).filter(Boolean)}
async function loadShotTemplate(){
 try{
  shotTemplate=await api('/shot-template');
  $('shotFilmId').value=shotTemplate.film_id||'';
  $('shotSceneId').value=shotTemplate.scene_id||'';
  $('shotId').value=shotTemplate.shot_id||'';
  $('shotCharacters').value=(shotTemplate.character_ids||[]).join(', ');
  $('shotVoices').value=(shotTemplate.voice_profile_ids||[]).join(', ');
  $('shotEnvironment').value=shotTemplate.environment||'';
  $('shotAction').value=shotTemplate.action||'';
  $('shotCamera').value=shotTemplate.camera||'';
  $('shotLighting').value=shotTemplate.lighting||'';
  $('shotAudio').value=shotTemplate.audio||'';
  $('shotContinuity').value=shotTemplate.continuity||'';
  $('shotDuration').value=shotTemplate.duration||8;
  $('shotResolution').value=shotTemplate.resolution||'1440p';
  $('shotAspectRatio').value=shotTemplate.aspect_ratio||'16:9';
  $('shotFrameRate').value=shotTemplate.frame_rate||24;
  $('shotSeed').value=shotTemplate.seed===undefined?0:shotTemplate.seed;
  return true;
 }catch(e){
  $('realShotGateMessage').textContent='Shot template could not be loaded: '+e.message;
  return false;
 }
}
function renderGenerationGate(gate){
 generationGate=gate;
 $('realShotGate').textContent=gate.enabled?'T2V READY':'LOCKED';
 $('realShotGate').className='pill '+(gate.enabled?'ok':'warn');
 $('realShotGateMessage').textContent=gate.reason||'Preflight status unavailable.';
 const enabled=Boolean(gate.enabled&&shotTemplate);
 document.querySelectorAll('#realShotForm input,#realShotForm textarea,#realShotForm select').forEach(el=>{el.disabled=!enabled});
 $('submitRealShotButton').disabled=!enabled;
 if(gate.enabled&&gate.gpu_name){
  $('realShotGateMessage').textContent=gate.reason+' Detected: '+gate.gpu_name+' · '+gate.gpu_vram_gib+' GiB VRAM.';
 }
}
function buildShotSpecification(){
 if(!shotTemplate)throw Error('Shot template is not loaded.');
 const spec=JSON.parse(JSON.stringify(shotTemplate));
 spec.film_id=$('shotFilmId').value.trim().toUpperCase();
 spec.scene_id=$('shotSceneId').value.trim().toUpperCase();
 spec.shot_id=$('shotId').value.trim().toUpperCase();
 spec.shot_type='SINGLE-SHOT';
 spec.character_ids=csvIds($('shotCharacters').value);
 spec.voice_profile_ids=csvIds($('shotVoices').value);
 spec.environment=$('shotEnvironment').value.trim();
 spec.action=$('shotAction').value.trim();
 spec.camera=$('shotCamera').value.trim();
 spec.lighting=$('shotLighting').value.trim();
 spec.audio=$('shotAudio').value.trim();
 spec.continuity=$('shotContinuity').value.trim();
 spec.duration=Number($('shotDuration').value);
 spec.resolution=$('shotResolution').value;
 spec.aspect_ratio=$('shotAspectRatio').value.trim();
 spec.frame_rate=Number($('shotFrameRate').value);
 delete spec.quality_preset;
 spec.status='READY';
 spec.generation_mode='TEXT_TO_VIDEO';
 spec.reference_assets=Array.isArray(shotTemplate.reference_assets)?shotTemplate.reference_assets:[];
 delete spec.input_image;delete spec.frame_conditioning;delete spec.continuation_source;
 const seed=$('shotSeed').value.trim();
 if(seed==='')throw Error('A numeric seed is required for the approved T2V mapping.');
 spec.seed=Number(seed);
 return spec;
}
function newShotRequestId(){
 if(window.crypto&&typeof window.crypto.randomUUID==='function')return window.crypto.randomUUID();
 throw Error('This browser does not support secure UUID generation. Update the browser before submitting.');
}
async function submitRealShot(event){
 event.preventDefault();
 if(!generationGate||!generationGate.enabled){note('Real shot submission is locked by production preflight.');return}
 if(!$('confirmRealCost').checked){note('Confirm the real-generation cost acknowledgement first.');return}
 let spec,payload;
 try{spec=buildShotSpecification();payload=JSON.stringify(spec)}catch(e){note(e.message);return}
 if(!pendingShotRequestId||pendingShotPayload!==payload){
  try{pendingShotRequestId=newShotRequestId()}catch(e){note(e.message);return}
  pendingShotPayload=payload;
 }
 const button=$('submitRealShotButton');
 button.disabled=true;button.textContent='SUBMITTING…';
 $('realShotResult').textContent='Submitting through the secured controller…';
 try{
  const result=await api('/shots/generate',{method:'POST',body:JSON.stringify({request_id:pendingShotRequestId,specification:spec,cost_acknowledged:$('confirmRealCost').checked})});
  const take=result.take||{};
  $('realShotResult').textContent=(result.reused?'Existing submission returned: ':'Shot submitted: ')+(take.take_id||'take ID unavailable');
  note(result.message||'Shot submission accepted.');
  pendingShotRequestId=null;pendingShotPayload=null;$('confirmRealCost').checked=false;
  currentFilm=take.film_id||currentFilm;
  await refreshAll();
 }catch(e){
  $('realShotResult').textContent='Submission not confirmed: '+e.message+'. Retrying with the same request ID will not intentionally create a duplicate.';
  note(e.message);
 }finally{
  button.textContent='SUBMIT REAL SHOT';
  button.disabled=!(generationGate&&generationGate.enabled&&shotTemplate);
 }
}
function csvIds(value){return value.split(',').map(v=>v.trim()).filter(Boolean)}
async function loadShotTemplate(){
 try{
  shotTemplate=await api('/shot-template');
  $('shotFilmId').value=shotTemplate.film_id||'';
  $('shotSceneId').value=shotTemplate.scene_id||'';
  $('shotId').value=shotTemplate.shot_id||'';
  $('shotCharacters').value=(shotTemplate.character_ids||[]).join(', ');
  $('shotVoices').value=(shotTemplate.voice_profile_ids||[]).join(', ');
  $('shotEnvironment').value=shotTemplate.environment||'';
  $('shotAction').value=shotTemplate.action||'';
  $('shotCamera').value=shotTemplate.camera||'';
  $('shotLighting').value=shotTemplate.lighting||'';
  $('shotAudio').value=shotTemplate.audio||'';
  $('shotContinuity').value=shotTemplate.continuity||'';
  $('shotDuration').value=shotTemplate.duration||8;
  $('shotResolution').value=shotTemplate.resolution||'1440p';
  $('shotAspectRatio').value=shotTemplate.aspect_ratio||'16:9';
  $('shotFrameRate').value=shotTemplate.frame_rate||24;
  $('shotSeed').value=shotTemplate.seed===undefined?0:shotTemplate.seed;
  return true;
 }catch(e){
  $('realShotGateMessage').textContent='Shot template could not be loaded: '+e.message;
  return false;
 }
}
function renderGenerationGate(gate){
 generationGate=gate;
 $('realShotGate').textContent=gate.enabled?'T2V READY':'LOCKED';
 $('realShotGate').className='pill '+(gate.enabled?'ok':'warn');
 $('realShotGateMessage').textContent=gate.reason||'Preflight status unavailable.';
 const enabled=Boolean(gate.enabled&&shotTemplate);
 document.querySelectorAll('#realShotForm input,#realShotForm textarea,#realShotForm select').forEach(el=>{el.disabled=!enabled});
 $('submitRealShotButton').disabled=!enabled;
 if(gate.enabled&&gate.gpu_name){
  $('realShotGateMessage').textContent=gate.reason+' Detected: '+gate.gpu_name+' · '+gate.gpu_vram_gib+' GiB VRAM.';
 }
}
function buildShotSpecification(){
 if(!shotTemplate)throw Error('Shot template is not loaded.');
 const spec=JSON.parse(JSON.stringify(shotTemplate));
 spec.film_id=$('shotFilmId').value.trim().toUpperCase();
 spec.scene_id=$('shotSceneId').value.trim().toUpperCase();
 spec.shot_id=$('shotId').value.trim().toUpperCase();
 spec.shot_type='SINGLE-SHOT';
 spec.character_ids=csvIds($('shotCharacters').value);
 spec.voice_profile_ids=csvIds($('shotVoices').value);
 spec.environment=$('shotEnvironment').value.trim();
 spec.action=$('shotAction').value.trim();
 spec.camera=$('shotCamera').value.trim();
 spec.lighting=$('shotLighting').value.trim();
 spec.audio=$('shotAudio').value.trim();
 spec.continuity=$('shotContinuity').value.trim();
 spec.duration=Number($('shotDuration').value);
 spec.resolution=$('shotResolution').value;
 spec.aspect_ratio=$('shotAspectRatio').value.trim();
 spec.frame_rate=Number($('shotFrameRate').value);
 delete spec.quality_preset;
 spec.status='READY';
 spec.generation_mode='TEXT_TO_VIDEO';
 spec.reference_assets=Array.isArray(shotTemplate.reference_assets)?shotTemplate.reference_assets:[];
 delete spec.input_image;delete spec.frame_conditioning;delete spec.continuation_source;
 const seed=$('shotSeed').value.trim();
 if(seed==='')throw Error('A numeric seed is required for the approved T2V mapping.');
 spec.seed=Number(seed);
 return spec;
}
function newShotRequestId(){
 if(window.crypto&&typeof window.crypto.randomUUID==='function')return window.crypto.randomUUID();
 throw Error('This browser does not support secure UUID generation. Update the browser before submitting.');
}
async function submitRealShot(event){
 event.preventDefault();
 if(!generationGate||!generationGate.enabled){note('Real shot submission is locked by production preflight.');return}
 if(!$('confirmRealCost').checked){note('Confirm the real-generation cost acknowledgement first.');return}
 let spec,payload;
 try{spec=buildShotSpecification();payload=JSON.stringify(spec)}catch(e){note(e.message);return}
 if(!pendingShotRequestId||pendingShotPayload!==payload){
  try{pendingShotRequestId=newShotRequestId()}catch(e){note(e.message);return}
  pendingShotPayload=payload;
 }
 const button=$('submitRealShotButton');
 button.disabled=true;button.textContent='SUBMITTING…';
 $('realShotResult').textContent='Submitting through the secured controller…';
 try{
  const result=await api('/shots/generate',{method:'POST',body:JSON.stringify({request_id:pendingShotRequestId,specification:spec,cost_acknowledged:$('confirmRealCost').checked})});
  const take=result.take||{};
  $('realShotResult').textContent=(result.reused?'Existing submission returned: ':'Shot submitted: ')+(take.take_id||'take ID unavailable');
  note(result.message||'Shot submission accepted.');
  pendingShotRequestId=null;pendingShotPayload=null;$('confirmRealCost').checked=false;
  currentFilm=take.film_id||currentFilm;
  await refreshAll();
 }catch(e){
  $('realShotResult').textContent='Submission not confirmed: '+e.message+'. Retrying with the same request ID will not intentionally create a duplicate.';
  note(e.message);
 }finally{
  button.textContent='SUBMIT REAL SHOT';
  button.disabled=!(generationGate&&generationGate.enabled&&shotTemplate);
 }
}
function csvIds(value){return value.split(',').map(v=>v.trim()).filter(Boolean)}
async function loadShotTemplate(){
 try{
  shotTemplate=await api('/shot-template');
  $('shotFilmId').value=shotTemplate.film_id||'';
  $('shotSceneId').value=shotTemplate.scene_id||'';
  $('shotId').value=shotTemplate.shot_id||'';
  $('shotCharacters').value=(shotTemplate.character_ids||[]).join(', ');
  $('shotVoices').value=(shotTemplate.voice_profile_ids||[]).join(', ');
  $('shotEnvironment').value=shotTemplate.environment||'';
  $('shotAction').value=shotTemplate.action||'';
  $('shotCamera').value=shotTemplate.camera||'';
  $('shotLighting').value=shotTemplate.lighting||'';
  $('shotAudio').value=shotTemplate.audio||'';
  $('shotContinuity').value=shotTemplate.continuity||'';
  $('shotDuration').value=shotTemplate.duration||8;
  $('shotResolution').value=shotTemplate.resolution||'1440p';
  $('shotAspectRatio').value=shotTemplate.aspect_ratio||'16:9';
  $('shotFrameRate').value=shotTemplate.frame_rate||24;
  $('shotSeed').value=shotTemplate.seed===undefined?0:shotTemplate.seed;
  return true;
 }catch(e){
  $('realShotGateMessage').textContent='Shot template could not be loaded: '+e.message;
  return false;
 }
}
function renderGenerationGate(gate){
 generationGate=gate;
 $('realShotGate').textContent=gate.enabled?'T2V READY':'LOCKED';
 $('realShotGate').className='pill '+(gate.enabled?'ok':'warn');
 $('realShotGateMessage').textContent=gate.reason||'Preflight status unavailable.';
 const enabled=Boolean(gate.enabled&&shotTemplate);
 document.querySelectorAll('#realShotForm input,#realShotForm textarea,#realShotForm select').forEach(el=>{el.disabled=!enabled});
 $('submitRealShotButton').disabled=!enabled;
 if(gate.enabled&&gate.gpu_name){
  $('realShotGateMessage').textContent=gate.reason+' Detected: '+gate.gpu_name+' · '+gate.gpu_vram_gib+' GiB VRAM.';
 }
}
function buildShotSpecification(){
 if(!shotTemplate)throw Error('Shot template is not loaded.');
 const spec=JSON.parse(JSON.stringify(shotTemplate));
 spec.film_id=$('shotFilmId').value.trim().toUpperCase();
 spec.scene_id=$('shotSceneId').value.trim().toUpperCase();
 spec.shot_id=$('shotId').value.trim().toUpperCase();
 spec.shot_type='SINGLE-SHOT';
 spec.character_ids=csvIds($('shotCharacters').value);
 spec.voice_profile_ids=csvIds($('shotVoices').value);
 spec.environment=$('shotEnvironment').value.trim();
 spec.action=$('shotAction').value.trim();
 spec.camera=$('shotCamera').value.trim();
 spec.lighting=$('shotLighting').value.trim();
 spec.audio=$('shotAudio').value.trim();
 spec.continuity=$('shotContinuity').value.trim();
 spec.duration=Number($('shotDuration').value);
 spec.resolution=$('shotResolution').value;
 spec.aspect_ratio=$('shotAspectRatio').value.trim();
 spec.frame_rate=Number($('shotFrameRate').value);
 delete spec.quality_preset;
 spec.status='READY';
 spec.generation_mode='TEXT_TO_VIDEO';
 spec.reference_assets=Array.isArray(shotTemplate.reference_assets)?shotTemplate.reference_assets:[];
 delete spec.input_image;delete spec.frame_conditioning;delete spec.continuation_source;
 const seed=$('shotSeed').value.trim();
 if(seed==='')throw Error('A numeric seed is required for the approved T2V mapping.');
 spec.seed=Number(seed);
 return spec;
}
function newShotRequestId(){
 if(window.crypto&&typeof window.crypto.randomUUID==='function')return window.crypto.randomUUID();
 throw Error('This browser does not support secure UUID generation. Update the browser before submitting.');
}
async function submitRealShot(event){
 event.preventDefault();
 if(!generationGate||!generationGate.enabled){note('Real shot submission is locked by production preflight.');return}
 if(!$('confirmRealCost').checked){note('Confirm the real-generation cost acknowledgement first.');return}
 let spec,payload;
 try{spec=buildShotSpecification();payload=JSON.stringify(spec)}catch(e){note(e.message);return}
 if(!pendingShotRequestId||pendingShotPayload!==payload){
  try{pendingShotRequestId=newShotRequestId()}catch(e){note(e.message);return}
  pendingShotPayload=payload;
 }
 const button=$('submitRealShotButton');
 button.disabled=true;button.textContent='SUBMITTING…';
 $('realShotResult').textContent='Submitting through the secured controller…';
 try{
  const result=await api('/shots/generate',{method:'POST',body:JSON.stringify({request_id:pendingShotRequestId,specification:spec,cost_acknowledged:$('confirmRealCost').checked})});
  const take=result.take||{};
  $('realShotResult').textContent=(result.reused?'Existing submission returned: ':'Shot submitted: ')+(take.take_id||'take ID unavailable');
  note(result.message||'Shot submission accepted.');
  pendingShotRequestId=null;pendingShotPayload=null;$('confirmRealCost').checked=false;
  currentFilm=take.film_id||currentFilm;
  await refreshAll();
 }catch(e){
  $('realShotResult').textContent='Submission not confirmed: '+e.message+'. Retrying with the same request ID will not intentionally create a duplicate.';
  note(e.message);
 }finally{
  button.textContent='SUBMIT REAL SHOT';
  button.disabled=!(generationGate&&generationGate.enabled&&shotTemplate);
 }
}
function csvIds(value){return value.split(',').map(v=>v.trim()).filter(Boolean)}
async function loadShotTemplate(){
 try{
  shotTemplate=await api('/shot-template');
  $('shotFilmId').value=shotTemplate.film_id||'';
  $('shotSceneId').value=shotTemplate.scene_id||'';
  $('shotId').value=shotTemplate.shot_id||'';
  $('shotCharacters').value=(shotTemplate.character_ids||[]).join(', ');
  $('shotVoices').value=(shotTemplate.voice_profile_ids||[]).join(', ');
  $('shotEnvironment').value=shotTemplate.environment||'';
  $('shotAction').value=shotTemplate.action||'';
  $('shotCamera').value=shotTemplate.camera||'';
  $('shotLighting').value=shotTemplate.lighting||'';
  $('shotAudio').value=shotTemplate.audio||'';
  $('shotContinuity').value=shotTemplate.continuity||'';
  $('shotDuration').value=shotTemplate.duration||8;
  $('shotResolution').value=shotTemplate.resolution||'1440p';
  $('shotAspectRatio').value=shotTemplate.aspect_ratio||'16:9';
  $('shotFrameRate').value=shotTemplate.frame_rate||24;
  $('shotSeed').value=shotTemplate.seed===undefined?0:shotTemplate.seed;
  return true;
 }catch(e){
  $('realShotGateMessage').textContent='Shot template could not be loaded: '+e.message;
  return false;
 }
}
function renderGenerationGate(gate){
 generationGate=gate;
 $('realShotGate').textContent=gate.enabled?'T2V READY':'LOCKED';
 $('realShotGate').className='pill '+(gate.enabled?'ok':'warn');
 $('realShotGateMessage').textContent=gate.reason||'Preflight status unavailable.';
 const enabled=Boolean(gate.enabled&&shotTemplate);
 document.querySelectorAll('#realShotForm input,#realShotForm textarea,#realShotForm select').forEach(el=>{el.disabled=!enabled});
 $('submitRealShotButton').disabled=!enabled;
 if(gate.enabled&&gate.gpu_name){
  $('realShotGateMessage').textContent=gate.reason+' Detected: '+gate.gpu_name+' · '+gate.gpu_vram_gib+' GiB VRAM.';
 }
}
function buildShotSpecification(){
 if(!shotTemplate)throw Error('Shot template is not loaded.');
 const spec=JSON.parse(JSON.stringify(shotTemplate));
 spec.film_id=$('shotFilmId').value.trim().toUpperCase();
 spec.scene_id=$('shotSceneId').value.trim().toUpperCase();
 spec.shot_id=$('shotId').value.trim().toUpperCase();
 spec.shot_type='SINGLE-SHOT';
 spec.character_ids=csvIds($('shotCharacters').value);
 spec.voice_profile_ids=csvIds($('shotVoices').value);
 spec.environment=$('shotEnvironment').value.trim();
 spec.action=$('shotAction').value.trim();
 spec.camera=$('shotCamera').value.trim();
 spec.lighting=$('shotLighting').value.trim();
 spec.audio=$('shotAudio').value.trim();
 spec.continuity=$('shotContinuity').value.trim();
 spec.duration=Number($('shotDuration').value);
 spec.resolution=$('shotResolution').value;
 spec.aspect_ratio=$('shotAspectRatio').value.trim();
 spec.frame_rate=Number($('shotFrameRate').value);
 delete spec.quality_preset;
 spec.status='READY';
 spec.generation_mode='TEXT_TO_VIDEO';
 spec.reference_assets=Array.isArray(shotTemplate.reference_assets)?shotTemplate.reference_assets:[];
 delete spec.input_image;delete spec.frame_conditioning;delete spec.continuation_source;
 const seed=$('shotSeed').value.trim();
 if(seed==='')throw Error('A numeric seed is required for the approved T2V mapping.');
 spec.seed=Number(seed);
 return spec;
}
function newShotRequestId(){
 if(window.crypto&&typeof window.crypto.randomUUID==='function')return window.crypto.randomUUID();
 throw Error('This browser does not support secure UUID generation. Update the browser before submitting.');
}
async function submitRealShot(event){
 event.preventDefault();
 if(!generationGate||!generationGate.enabled){note('Real shot submission is locked by production preflight.');return}
 if(!$('confirmRealCost').checked){note('Confirm the real-generation cost acknowledgement first.');return}
 let spec,payload;
 try{spec=buildShotSpecification();payload=JSON.stringify(spec)}catch(e){note(e.message);return}
 if(!pendingShotRequestId||pendingShotPayload!==payload){
  try{pendingShotRequestId=newShotRequestId()}catch(e){note(e.message);return}
  pendingShotPayload=payload;
 }
 const button=$('submitRealShotButton');
 button.disabled=true;button.textContent='SUBMITTING…';
 $('realShotResult').textContent='Submitting through the secured controller…';
 try{
  const result=await api('/shots/generate',{method:'POST',body:JSON.stringify({request_id:pendingShotRequestId,specification:spec,cost_acknowledged:$('confirmRealCost').checked})});
  const take=result.take||{};
  $('realShotResult').textContent=(result.reused?'Existing submission returned: ':'Shot submitted: ')+(take.take_id||'take ID unavailable');
  note(result.message||'Shot submission accepted.');
  pendingShotRequestId=null;pendingShotPayload=null;$('confirmRealCost').checked=false;
  currentFilm=take.film_id||currentFilm;
  await refreshAll();
 }catch(e){
  $('realShotResult').textContent='Submission not confirmed: '+e.message+'. Retrying with the same request ID will not intentionally create a duplicate.';
  note(e.message);
 }finally{
  button.textContent='SUBMIT REAL SHOT';
  button.disabled=!(generationGate&&generationGate.enabled&&shotTemplate);
 }
}
function csvIds(value){return value.split(',').map(v=>v.trim()).filter(Boolean)}
async function loadShotTemplate(){
 try{
  shotTemplate=await api('/shot-template');
  $('shotFilmId').value=shotTemplate.film_id||'';
  $('shotSceneId').value=shotTemplate.scene_id||'';
  $('shotId').value=shotTemplate.shot_id||'';
  $('shotCharacters').value=(shotTemplate.character_ids||[]).join(', ');
  $('shotVoices').value=(shotTemplate.voice_profile_ids||[]).join(', ');
  $('shotEnvironment').value=shotTemplate.environment||'';
  $('shotAction').value=shotTemplate.action||'';
  $('shotCamera').value=shotTemplate.camera||'';
  $('shotLighting').value=shotTemplate.lighting||'';
  $('shotAudio').value=shotTemplate.audio||'';
  $('shotContinuity').value=shotTemplate.continuity||'';
  $('shotDuration').value=shotTemplate.duration||8;
  $('shotResolution').value=shotTemplate.resolution||'1440p';
  $('shotAspectRatio').value=shotTemplate.aspect_ratio||'16:9';
  $('shotFrameRate').value=shotTemplate.frame_rate||24;
  $('shotSeed').value=shotTemplate.seed===undefined?0:shotTemplate.seed;
  return true;
 }catch(e){
  $('realShotGateMessage').textContent='Shot template could not be loaded: '+e.message;
  return false;
 }
}
function renderGenerationGate(gate){
 generationGate=gate;
 $('realShotGate').textContent=gate.enabled?'T2V READY':'LOCKED';
 $('realShotGate').className='pill '+(gate.enabled?'ok':'warn');
 $('realShotGateMessage').textContent=gate.reason||'Preflight status unavailable.';
 const enabled=Boolean(gate.enabled&&shotTemplate);
 document.querySelectorAll('#realShotForm input,#realShotForm textarea,#realShotForm select').forEach(el=>{el.disabled=!enabled});
 $('submitRealShotButton').disabled=!enabled;
 if(gate.enabled&&gate.gpu_name){
  $('realShotGateMessage').textContent=gate.reason+' Detected: '+gate.gpu_name+' · '+gate.gpu_vram_gib+' GiB VRAM.';
 }
}
function buildShotSpecification(){
 if(!shotTemplate)throw Error('Shot template is not loaded.');
 const spec=JSON.parse(JSON.stringify(shotTemplate));
 spec.film_id=$('shotFilmId').value.trim().toUpperCase();
 spec.scene_id=$('shotSceneId').value.trim().toUpperCase();
 spec.shot_id=$('shotId').value.trim().toUpperCase();
 spec.shot_type='SINGLE-SHOT';
 spec.character_ids=csvIds($('shotCharacters').value);
 spec.voice_profile_ids=csvIds($('shotVoices').value);
 spec.environment=$('shotEnvironment').value.trim();
 spec.action=$('shotAction').value.trim();
 spec.camera=$('shotCamera').value.trim();
 spec.lighting=$('shotLighting').value.trim();
 spec.audio=$('shotAudio').value.trim();
 spec.continuity=$('shotContinuity').value.trim();
 spec.duration=Number($('shotDuration').value);
 spec.resolution=$('shotResolution').value;
 spec.aspect_ratio=$('shotAspectRatio').value.trim();
 spec.frame_rate=Number($('shotFrameRate').value);
 delete spec.quality_preset;
 spec.status='READY';
 spec.generation_mode='TEXT_TO_VIDEO';
 spec.reference_assets=Array.isArray(shotTemplate.reference_assets)?shotTemplate.reference_assets:[];
 delete spec.input_image;delete spec.frame_conditioning;delete spec.continuation_source;
 const seed=$('shotSeed').value.trim();
 if(seed==='')throw Error('A numeric seed is required for the approved T2V mapping.');
 spec.seed=Number(seed);
 return spec;
}
function newShotRequestId(){
 if(window.crypto&&typeof window.crypto.randomUUID==='function')return window.crypto.randomUUID();
 throw Error('This browser does not support secure UUID generation. Update the browser before submitting.');
}
async function submitRealShot(event){
 event.preventDefault();
 if(!generationGate||!generationGate.enabled){note('Real shot submission is locked by production preflight.');return}
 if(!$('confirmRealCost').checked){note('Confirm the real-generation cost acknowledgement first.');return}
 let spec,payload;
 try{spec=buildShotSpecification();payload=JSON.stringify(spec)}catch(e){note(e.message);return}
 if(!pendingShotRequestId||pendingShotPayload!==payload){
  try{pendingShotRequestId=newShotRequestId()}catch(e){note(e.message);return}
  pendingShotPayload=payload;
 }
 const button=$('submitRealShotButton');
 button.disabled=true;button.textContent='SUBMITTING…';
 $('realShotResult').textContent='Submitting through the secured controller…';
 try{
  const result=await api('/shots/generate',{method:'POST',body:JSON.stringify({request_id:pendingShotRequestId,specification:spec,cost_acknowledged:$('confirmRealCost').checked})});
  const take=result.take||{};
  $('realShotResult').textContent=(result.reused?'Existing submission returned: ':'Shot submitted: ')+(take.take_id||'take ID unavailable');
  note(result.message||'Shot submission accepted.');
  pendingShotRequestId=null;pendingShotPayload=null;$('confirmRealCost').checked=false;
  currentFilm=take.film_id||currentFilm;
  await refreshAll();
 }catch(e){
  $('realShotResult').textContent='Submission not confirmed: '+e.message+'. Retrying with the same request ID will not intentionally create a duplicate.';
  note(e.message);
 }finally{
  button.textContent='SUBMIT REAL SHOT';
  button.disabled=!(generationGate&&generationGate.enabled&&shotTemplate);
 }
}
function updateStatusLabel(result){
 const labels={first_observation_needs_manual_baseline:'Approved baseline missing — manual review needed',release_metadata_differs_from_approved_baseline:'Release metadata differs from approved baseline',model_metadata_differs_from_approved_baseline:'Model metadata differs from approved baseline',no_change_since_last_check:'No metadata change from approved baseline'};
 return labels[result]||String(result||'No update status inferred').replaceAll('_',' ');
}
function renderUpdateResults(data){
 const host=$('updateCheckResults');
 const results=Array.isArray(data.sources)?data.sources:[];
 const summary=Number(data.change_candidates_requiring_manual_review)||0;
 $('updateCheckStatus').textContent=`Check finished. ${summary} metadata candidate(s) need manual review. No changes were applied; automatic install is off.`;
 host.innerHTML=results.map(item=>{
  const detail=item.release?.tag_name?`Release: ${esc(item.release.tag_name)}`:item.model?.revision?`Model revision: ${esc(String(item.model.revision).slice(0,12))}…`:'';
  const extra=item.error?`<div class="small bad">${esc(item.error)}</div>`:item.note?`<div class="small muted">${esc(item.note)}</div>`:'';
  const status=item.change_status?updateStatusLabel(item.change_status):item.reachable?(item.metadata_status||'Source reachable'):'Source unavailable';
  const badge=item.reachable===true?'ok':item.reachable===false?'bad':'warn';
  const http=item.http_status?` · HTTP ${esc(item.http_status)}`:'';
  return `<div class="item"><div class="row"><b class="grow">${esc(item.source||'Update source')}</b><span class="pill ${badge}">${esc(item.reachable===true?'REACHABLE':item.reachable===false?'UNREACHABLE':'LOCAL')}</span></div><div class="small">${esc(status)}${http}</div>${detail?`<div class="small muted">${detail}</div>`:''}${extra}</div>`;
 }).join('')||'<div class="muted small">No source results were returned.</div>';
}
async function runUpdateCheck(){
 const button=$('updateCheckButton');button.disabled=true;button.textContent='CHECKING…';$('updateCheckStatus').textContent='Checking official sources. Nothing will be installed or downloaded.';$('updateCheckResults').innerHTML='';
 try{const data=await api('/updates/check',{method:'POST',body:JSON.stringify({})});renderUpdateResults(data);note('Update check completed; review any candidates manually.');}
 catch(e){$('updateCheckStatus').textContent='The update check did not complete: '+e.message;note(e.message)}
 finally{button.disabled=false;button.textContent='CHECK FOR UPDATES'}
}
async function approve(id){try{await api('/takes/'+encodeURIComponent(id)+'/approve',{method:'POST',body:JSON.stringify({auto_export:true})});note('Approved. Export started/completed.');await refreshAll()}catch(e){note(e.message)}}
async function reject(id){const reason=prompt('Why are you rejecting this take?');if(!reason)return;try{await api('/takes/'+encodeURIComponent(id)+'/reject',{method:'POST',body:JSON.stringify({reason})});note('Rejected and recorded.');await refreshAll()}catch(e){note(e.message)}}
async function regenerate(id){try{const r=await api('/takes/'+encodeURIComponent(id)+'/regenerate',{method:'POST',body:JSON.stringify({})});note('Regeneration submitted: '+r.take_id);await refreshAll()}catch(e){note(e.message)}}
async function exportTake(id){try{await api('/takes/'+encodeURIComponent(id)+'/export',{method:'POST',body:JSON.stringify({})});note('Approved output export verified.');await refreshAll()}catch(e){note(e.message)}}
async function sendCommand(){const c=$('command').value.trim();if(!c)return;$('commandResult').textContent='Command interface is reserved for the AI-agent bridge; no action was executed.';$('command').value=''}
function esc(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
refreshAll();
</script>
</body></html>'''


class Handler(BaseHTTPRequestHandler):
    server_version = "HIS-RISEN-Director-Console/0.2"

    def _console(self) -> DirectorConsole:
        return self.server.console  # type: ignore[attr-defined]

    def _cookie_token(self) -> str | None:
        raw = self.headers.get("Cookie", "")
        for part in raw.split(";"):
            key, _, value = part.strip().partition("=")
            if key == COOKIE_NAME:
                return value
        return None

    def _authed(self) -> bool:
        return self._console().sessions.valid(self._cookie_token())

    def _secure_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; media-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
        )
        if self.headers.get("X-Forwarded-Proto", "http").lower() == "https":
            self.send_header("Strict-Transport-Security", "max-age=31536000; includeSubDomains")

    def _json(self, status: int, payload: Any) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self._secure_headers()
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> Any:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise RequestBodyError("invalid Content-Length") from exc
        if length < 0 or length > MAX_BODY_BYTES:
            raise RequestBodyError("request body is too large")
        raw = self.rfile.read(length) if length else b"{}"
        try:
            return json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise RequestBodyError("invalid JSON request body") from exc

    def _require_auth(self) -> bool:
        if self._authed():
            return True
        self._json(HTTPStatus.UNAUTHORIZED, {"ok": False, "error": "authentication_required"})
        return False

    def _check_origin(self) -> bool:
        origin = self.headers.get("Origin")
        if not origin:
            return True
        parsed = urlparse(origin)
        host = self.headers.get("Host", "")
        if parsed.netloc != host:
            self._json(HTTPStatus.FORBIDDEN, {"ok": False, "error": "origin_not_allowed"})
            return False
        return True

    def do_GET(self) -> None:
        path = urlparse(self.path).path.rstrip("/") or "/"
        try:
            if path == "/":
                body = INDEX_HTML.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self._secure_headers()
                self.end_headers()
                self.wfile.write(body)
                return
            if path == "/health":
                self._json(200, {"ok": True, "service": APP_NAME})
                return
            if not path.startswith("/api/"):
                self._json(404, {"ok": False, "error": "not_found"})
                return
            if path == "/api/status":
                if not self._require_auth():
                    return
                self._json(200, {"ok": True, "data": self._console().status()})
                return
            if not self._require_auth():
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/films":
                self._json(200, {"ok": True, "data": self._console().list_films()})
                return
            if path == "/api/takes":
                q = parse_qs(urlparse(self.path).query)
                film_id = q.get("film_id", [None])[0]
                self._json(200, {"ok": True, "data": self._console().list_takes(film_id)})
                return
            if path.startswith("/api/films/") and path.endswith("/readiness"):
                film_id = unquote(path.split("/")[3])
                self._json(200, {"ok": True, "data": self._console().controller.film_readiness(film_id)})
                return
            if path.startswith("/api/takes/") and path.endswith("/preview"):
                take_id = unquote(path.split("/")[3])
                preview = self._console().take_review_video(take_id)
                if not preview:
                    self._json(404, {"ok": False, "error": "video_preview_not_available"})
                    return
                kind, target = preview
                if kind == "file":
                    self._send_file(Path(target), "video/mp4")
                    return
                # URL proxying is intentionally reserved for configured controller
                # output URLs; it is never accepted from a Director text field.
                try:
                    retriever = self._console().controller.export_manager.retriever
                    with retriever.open_remote(str(target), timeout=30) as response:
                        self.send_response(200)
                        self.send_header("Content-Type", response.headers.get("Content-Type", "video/mp4"))
                        length = response.headers.get("Content-Length")
                        if length:
                            self.send_header("Content-Length", length)
                        self.send_header("Cache-Control", "private, max-age=30")
                        self._secure_headers()
                        self.end_headers()
                        while chunk := response.read(1024 * 1024):
                            self.wfile.write(chunk)
                except Exception:
                    self._json(502, {"ok": False, "error": "video_preview_upstream_failed"})
                return
            self._json(404, {"ok": False, "error": "not_found"})
        except Exception as exc:
            self._json(500, {"ok": False, "error": f"{type(exc).__name__}: {exc}"})

    def do_POST(self) -> None:
        path = urlparse(self.path).path.rstrip("/") or "/"
        try:
            if path == "/api/login":
                key = self.client_address[0]
                if not self._console().limiter.allowed(key):
                    self._json(429, {"ok": False, "error": "too_many_attempts"})
                    return
                body = self._read_json()
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                presented = str(body.get("pin", ""))
                if not secrets.compare_digest(presented, self._console().pin):
                    self._console().limiter.failure(key)
                    self._json(401, {"ok": False, "error": "invalid_pin"})
                    return
                token = self._console().sessions.create()
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                secure = "; Secure" if self.headers.get("X-Forwarded-Proto", "http").lower() == "https" else ""
                self.send_header("Set-Cookie", f"{COOKIE_NAME}={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_TTL}{secure}")
                self._secure_headers()
                body_bytes = b'{"ok":true}'
                self.send_header("Content-Length", str(len(body_bytes)))
                self.end_headers()
                self.wfile.write(body_bytes)
                return
            if path == "/api/logout":
                self._console().sessions.revoke(self._cookie_token())
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                secure = "; Secure" if self.headers.get("X-Forwarded-Proto", "http").lower() == "https" else ""
                self.send_header("Set-Cookie", f"{COOKIE_NAME}=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict{secure}")
                self._secure_headers()
                body_bytes = b'{"ok":true}'
                self.send_header("Content-Length", str(len(body_bytes)))
                self.end_headers()
                self.wfile.write(body_bytes)
                return
            if not self._check_origin():
                return
            if not self._require_auth():
                return

            body = self._read_json()
            if path == "/api/shots/generate":
                # Browsers must send the same-origin Origin header for this
                # state-changing endpoint; SameSite=Strict is an additional layer.
                if not self.headers.get("Origin"):
                    self._json(HTTPStatus.FORBIDDEN, {"ok": False, "error": "origin_required"})
                    return
                if not isinstance(body, dict) or set(body) != {"request_id", "specification", "cost_acknowledged"}:
                    raise ValueError("shot submission requires request_id, specification and cost_acknowledged")
                if body["cost_acknowledged"] is not True:
                    raise ValueError("director cost acknowledgement is required before real generation")
                if not isinstance(body["specification"], dict):
                    raise ValueError("specification must be a JSON object")
                result = self._console().submit_real_shot(body["specification"], body["request_id"])
                self._json(202, {"ok": True, "data": result})
                return
            if path == "/api/updates/check":
                if body not in ({}, None):
                    raise ValueError("update check does not accept configuration; it only reads official metadata")
                self._json(200, {"ok": True, "data": self._console().check_for_updates()})
                return
            if path == "/api/mock-test":
                if body not in ({}, None):
                    raise ValueError("mock test does not accept configuration; it uses the fixed safe fixture")
                self._json(200, {"ok": True, "data": self._console().create_mock_test()})
                return
            if path.startswith("/api/takes/") and path.endswith("/approve"):
                take_id = unquote(path.split("/")[3])
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                result = self._console().controller.director_approve(take_id, auto_export=bool(body.get("auto_export", True)))
                self._json(200, {"ok": True, "data": result})
                return
            if path.startswith("/api/takes/") and path.endswith("/reject"):
                take_id = unquote(path.split("/")[3])
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                result = self._console().controller.director_reject(take_id, str(body.get("reason", "")).strip())
                self._json(200, {"ok": True, "data": result})
                return
            if path.startswith("/api/takes/") and path.endswith("/regenerate"):
                if body not in ({}, None):
                    raise ValueError("regeneration does not accept a request body")
                take_id = unquote(path.split("/")[3])
                result = self._console().controller.regenerate(take_id)
                self._json(200, {"ok": True, "data": result})
                return
            if path.startswith("/api/takes/") and path.endswith("/export"):
                if body not in ({}, None):
                    raise ValueError("export does not accept a request body")
                take_id = unquote(path.split("/")[3])
                result = self._console().controller.export_approved(take_id)
                self._json(200, {"ok": True, "data": result})
                return
            self._json(404, {"ok": False, "error": "not_found"})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except RequestBodyError as exc:
            self._json(413 if "too large" in str(exc) else 400, {"ok": False, "error": str(exc)})
        except Exception as exc:
            self._json(409, {"ok": False, "error": f"{type(exc).__name__}: {exc}"})

    def _send_file(self, path: Path, content_type: str) -> None:
        if not path.is_file():
            self._json(404, {"ok": False, "error": "file_not_found"})
            return
        size = path.stat().st_size
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(size))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Cache-Control", "private, max-age=30")
        self._secure_headers()
        self.end_headers()
        with path.open("rb") as handle:
            while chunk := handle.read(1024 * 1024):
                self.wfile.write(chunk)

    def log_message(self, fmt: str, *args: object) -> None:
        return


def main() -> None:
    parser = argparse.ArgumentParser(description=APP_NAME)
    parser.add_argument("--host", default=os.environ.get("HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "8080")))
    parser.add_argument("--backend", choices=["mock", "comfyui"], default=None)
    args = parser.parse_args()

    root = Path(__file__).resolve().parent
    pin = os.environ.get("HRF_DIRECTOR_PIN", "").strip()
    controller = build_controller(root, backend=args.backend)
    console = DirectorConsole(controller, pin, root)
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    server.console = console  # type: ignore[attr-defined]
    print(f"{APP_NAME} listening on http://{args.host}:{args.port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        console.stop()
        controller.close()
        server.server_close()


if __name__ == "__main__":
    main()
