from __future__ import annotations

import argparse
import hashlib
import json
import os
import secrets
import threading
import time
import uuid
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, unquote, urlparse

from config.bootstrap import build_controller
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from models.specification import ValidationError, validate_specification
from config.data_paths import resolve_data_root
from studio_workspace import StudioWorkspace


APP_NAME = "HIS RISEN STUDIOS"
COOKIE_NAME = "hrf_director_session"
SESSION_TTL = 12 * 60 * 60
MAX_FAILED_PER_WINDOW = 5
FAIL_WINDOW = 5 * 60
MAX_BODY_BYTES = 256 * 1024
MOCK_TEST_FILM_ID = "HRF-MOCK-TEST"
MOCK_TEST_SCENE_ID = "SC999"
MOCK_TEST_SHOT_ID = "SC999-SH001"


class RequestBodyError(ValueError):
    """Client-supplied request body is malformed or too large."""


class SessionStore:
    def __init__(self) -> None:
        self._sessions: dict[str, float] = {}
        self._lock = threading.RLock()

    def create(self) -> str:
        token = secrets.token_urlsafe(32)
        with self._lock:
            self._sessions[token] = time.time() + SESSION_TTL
        return token

    def valid(self, token: str | None) -> bool:
        if not token:
            return False
        now = time.time()
        with self._lock:
            expiry = self._sessions.get(token)
            if expiry is None:
                return False
            if expiry < now:
                self._sessions.pop(token, None)
                return False
            return True

    def revoke(self, token: str | None) -> None:
        if token:
            with self._lock:
                self._sessions.pop(token, None)


class LoginLimiter:
    def __init__(self) -> None:
        self._failed: dict[str, list[float]] = {}
        self._lock = threading.RLock()

    def allowed(self, key: str) -> bool:
        now = time.time()
        with self._lock:
            entries = [t for t in self._failed.get(key, []) if t > now - FAIL_WINDOW]
            self._failed[key] = entries
            return len(entries) < MAX_FAILED_PER_WINDOW

    def failure(self, key: str) -> None:
        with self._lock:
            self._failed.setdefault(key, []).append(time.time())


class DirectorConsole:
    def __init__(self, controller: Any, pin: str, root: Path) -> None:
        if not pin or not pin.isdigit() or len(pin) < 6 or len(pin) > 12:
            raise ValueError("HRF_DIRECTOR_PIN must be a 6-12 digit PIN.")
        self.controller = controller
        self.pin = pin
        self.root = root.resolve()
        self.workspace = StudioWorkspace(resolve_data_root(self.root))
        self.sessions = SessionStore()
        self.limiter = LoginLimiter()
        self._generation_lock = threading.RLock()
        self._generation_requests: dict[str, dict[str, str]] = {}
        self._readiness_lock = threading.RLock()
        self._readiness_cache: tuple[float, dict[str, Any]] | None = None
        self._autopoll_stop = threading.Event()
        self._autopoll_thread = threading.Thread(target=self._poll_loop, daemon=True)
        self._autopoll_thread.start()

    def _poll_loop(self) -> None:
        while not self._autopoll_stop.wait(2.5):
            try:
                for take in self._active_takes():
                    try:
                        self.controller.advance(take["take_id"])
                    except Exception:
                        pass
            except Exception:
                pass

    def stop(self) -> None:
        self._autopoll_stop.set()
        if self._autopoll_thread.is_alive():
            self._autopoll_thread.join(timeout=1.0)

    def _active_takes(self) -> list[dict[str, Any]]:
        conn = self.controller.store.connection
        with self.controller.store._lock:
            rows = conn.execute(
                "SELECT take_id FROM takes WHERE status IN ('SUBMITTED','RUNNING') ORDER BY created_at"
            ).fetchall()
        return [self.controller.get_take(row["take_id"]) for row in rows]

    def list_films(self) -> list[dict[str, Any]]:
        conn = self.controller.store.connection
        with self.controller.store._lock:
            rows = conn.execute("SELECT film_id FROM films ORDER BY film_id").fetchall()
        return [{"film_id": row["film_id"]} for row in rows]

    def list_takes(self, film_id: str | None = None) -> list[dict[str, Any]]:
        conn = self.controller.store.connection
        with self.controller.store._lock:
            if film_id:
                rows = conn.execute(
                    "SELECT take_id FROM takes WHERE film_id=? ORDER BY scene_id,shot_id,take_number",
                    (film_id,),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT take_id FROM takes ORDER BY updated_at DESC LIMIT 200"
                ).fetchall()
        return [self.controller.get_take(row["take_id"]) for row in rows]

    def status(self) -> dict[str, Any]:
        adapter = type(self.controller.adapter).__name__
        return {
            "service": APP_NAME,
            "controller": "online",
            "backend_adapter": adapter,
            "mock_mode": adapter == "MockComfyUIAdapter",
            "real_generation_enabled": adapter != "MockComfyUIAdapter",
            "approval_required": True,
            "auto_export_approved": bool(self.controller.auto_export_approved),
            "export_manager": self.controller.export_manager is not None,
            "server_time": time.time(),
        }

    def check_for_updates(self) -> dict[str, Any]:
        """Check official LTX metadata without installing or downloading assets."""
        from updates.check import check_updates

        return check_updates(self.root, state_root=resolve_data_root(self.root))

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            loader.validate_required_mappings(
                workflow,
                mapping,
                {"prompt": "HIS RISEN read-only preflight", "duration": 8, "seed": 0},
            )

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            readiness = self.real_shot_readiness()
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            loader.validate_required_mappings(
                workflow,
                mapping,
                {
                    "prompt": "HIS RISEN read-only preflight",
                    "duration": 8,
                    "seed": 0,
                    "width": 2560,
                    "height": 1440,
                    "fps": 24,
                },
            )

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p", "4K"}:
            raise ValueError("Select a supported resolution before submitting.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            readiness = self.real_shot_readiness()
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p", "4K"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p", "4K"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p", "4K"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p", "4K"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p", "4K"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def shot_template(self) -> dict[str, Any]:
        """Return the validated starter specification used by the Director form."""
        template_path = self.root / "config" / "test_shot.json"
        value = json.loads(template_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("shot template must be a JSON object")
        value["generation_mode"] = "TEXT_TO_VIDEO"
        value["shot_type"] = "SINGLE-SHOT"
        return value

    def real_shot_readiness(self, force: bool = False) -> dict[str, Any]:
        """Read-only preflight. It never queues a job or downloads anything."""
        now = time.monotonic()
        with self._readiness_lock:
            if not force and self._readiness_cache and now - self._readiness_cache[0] < 15:
                return dict(self._readiness_cache[1])

        adapter = self.controller.adapter
        if type(adapter).__name__ == "MockComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": True,
                "reason": "Mock Mode is active. Real submissions are locked until a secured ComfyUI endpoint is configured.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        if type(adapter).__name__ != "RealComfyUIAdapter":
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": "The active controller adapter is not the verified ComfyUI production adapter.",
                "workflow": "L25-T2V-SINGLE",
            }
            with self._readiness_lock:
                self._readiness_cache = (time.monotonic(), result)
            return dict(result)

        try:
            data_root_text = os.environ.get("HRF_DATA_DIR", "").strip()
            if not data_root_text:
                raise ValueError("Persistent controller storage is not configured. Attach a durable Render volume and set HRF_DATA_DIR before enabling real shots.")
            configured_data_root = Path(data_root_text)
            if not configured_data_root.is_absolute():
                raise ValueError("HRF_DATA_DIR must be an absolute path on an attached durable volume.")
            data_root = configured_data_root.resolve()
            if not data_root.is_dir():
                raise ValueError("HRF_DATA_DIR does not exist or is not a directory.")
            database_path = getattr(self.controller.store, "path", None)
            if database_path is None or not Path(database_path).resolve().is_relative_to(data_root):
                raise ValueError("The controller SQLite database is not located inside HRF_DATA_DIR.")
            mount_path = data_root
            while mount_path != mount_path.parent and not mount_path.is_mount():
                mount_path = mount_path.parent
            if not mount_path.is_mount() or mount_path == Path("/"):
                raise ValueError("HRF_DATA_DIR is not backed by a mounted persistent volume; ephemeral filesystem storage is not safe for real-shot submissions.")
            presets_path = self.root / "workflows" / "real_presets.json"
            presets = json.loads(presets_path.read_text(encoding="utf-8"))
            config = presets.get("L25-T2V-SINGLE") if isinstance(presets, dict) else None
            if not isinstance(config, dict) or config.get("ready") is not True:
                raise ValueError("The verified LTX-2.5 T2V workflow is not installed and approved. Real presets remain safely disabled.")

            from workflows.loader import WorkflowLoader
            loader = WorkflowLoader(self.root)
            workflow = loader.load(config["workflow_file"])
            mapping_path = (self.root / config["mapping_file"]).resolve()
            if not mapping_path.is_relative_to(self.root) or not mapping_path.is_file():
                raise ValueError("The T2V mapping file is missing or outside the controller package.")
            mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
            if not isinstance(mapping, dict):
                raise ValueError("The T2V mapping must be a JSON object.")
            required_values = {
                "prompt": "HIS RISEN read-only preflight",
                "duration": 8,
                "seed": 0,
                "width": 2560,
                "height": 1440,
                "fps": 24,
            }
            missing_mappings = [
                key for key in required_values
                if not isinstance(mapping.get(key), dict) or mapping[key].get("required") is not True
            ]
            if missing_mappings:
                raise ValueError(
                    "The exported T2V mapping must explicitly require these director controls: "
                    + ", ".join(missing_mappings)
                )
            loader.validate_required_mappings(workflow, mapping, required_values)

            node_types = {
                node.get("class_type")
                for node in workflow.values()
                if isinstance(node, dict) and isinstance(node.get("class_type"), str)
            }
            if not node_types:
                raise ValueError("The exported T2V API workflow contains no ComfyUI node classes.")

            stats = adapter.http._request_json("GET", "/system_stats", timeout=3)
            if not isinstance(stats, dict):
                raise ValueError("ComfyUI /system_stats returned an invalid response.")
            devices = stats.get("devices")
            devices = devices if isinstance(devices, list) else []
            cuda_devices = [
                device for device in devices
                if isinstance(device, dict)
                and str(device.get("type", "")).lower() == "cuda"
                and isinstance(device.get("vram_total"), (int, float))
            ]
            eligible = [
                device for device in cuda_devices
                if device["vram_total"] >= 32 * 1024 ** 3
            ]
            if not eligible:
                raise ValueError("ComfyUI is reachable, but no CUDA GPU with at least 32 GiB VRAM was detected.")

            object_info = adapter.http._request_json("GET", "/object_info", timeout=5)
            if not isinstance(object_info, dict):
                raise ValueError("ComfyUI /object_info returned an invalid response.")
            missing_nodes = sorted(node_types - set(object_info))
            if missing_nodes:
                raise ValueError("ComfyUI is missing required workflow node classes: " + ", ".join(missing_nodes[:8]))

            gpu = max(eligible, key=lambda device: device["vram_total"])
            result = {
                "enabled": True,
                "mock_mode": False,
                "reason": "The T2V API workflow, required node classes, remote ComfyUI endpoint and CUDA GPU passed read-only preflight.",
                "workflow": "L25-T2V-SINGLE",
                "comfyui_reachable": True,
                "persistent_storage_ready": True,
                "persistent_storage_mount": str(mount_path),
                "gpu_name": str(gpu.get("name", "CUDA GPU")),
                "gpu_vram_gib": round(gpu["vram_total"] / (1024 ** 3), 1),
                "supported_modes": ["TEXT_TO_VIDEO"],
                "submission_requires_director_confirmation": True,
                "note": "A successful preflight does not prove the selected model weights load or that a video renders. The first real shot remains the acceptance test.",
            }
        except Exception as exc:
            result = {
                "enabled": False,
                "mock_mode": False,
                "reason": f"Real submission preflight is blocked: {type(exc).__name__}: {str(exc)[:240]}",
                "workflow": "L25-T2V-SINGLE",
            }

        with self._readiness_lock:
            self._readiness_cache = (time.monotonic(), result)
        return dict(result)

    def submit_real_shot(self, specification: dict[str, Any], request_id: str) -> dict[str, Any]:
        """Submit exactly one explicitly approved T2V shot; retries are idempotent."""
        if not isinstance(request_id, str):
            raise ValueError("request_id must be a UUIDv4 string.")
        try:
            parsed_request_id = uuid.UUID(request_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUIDv4 string.") from exc
        if parsed_request_id.version != 4:
            raise ValueError("request_id must be a UUIDv4 string.")
        if not isinstance(specification, dict):
            raise ValueError("specification must be a JSON object.")

        spec = json.loads(json.dumps(specification, ensure_ascii=False))
        if spec.get("generation_mode") != "TEXT_TO_VIDEO":
            raise ValueError("The first real-shot submission path currently accepts TEXT_TO_VIDEO only.")
        if spec.get("shot_type") != "SINGLE-SHOT":
            raise ValueError("The first real-shot submission path currently accepts SINGLE-SHOT only.")
        if spec.get("input_image") or spec.get("frame_conditioning") or spec.get("continuation_source"):
            raise ValueError("Image conditioning and continuation are not enabled in the first T2V submission path.")
        if spec.get("aspect_ratio", "16:9") != "16:9":
            raise ValueError("The first real T2V submission path currently supports 16:9 only.")
        if spec.get("resolution") not in {"720p", "1080p", "1440p"}:
            raise ValueError("Select a supported resolution before submitting.")
        if type(spec.get("duration")) is not int or not 1 <= spec["duration"] <= 20:
            raise ValueError("The first real T2V path accepts whole-number durations from 1 to 20 seconds only.")
        if type(spec.get("frame_rate")) is not int or not 1 <= spec["frame_rate"] <= 60:
            raise ValueError("Frame rate must be a whole number between 1 and 60 fps.")
        if type(spec.get("seed")) is not int or spec["seed"] < 0:
            raise ValueError("A nonnegative integer seed is required by the approved T2V workflow mapping.")

        validate_specification(spec, self.root)
        payload_hash = hashlib.sha256(
            json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._generation_lock:
            existing = self._generation_requests.get(request_id)
            if existing:
                if existing["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(existing["take_id"])
                message = (
                    "This request is still PENDING. It was not submitted again automatically; inspect ComfyUI queue/history before taking further action."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            durable = self.controller.store.get_submission_request(request_id)
            if durable:
                if durable["payload_hash"] != payload_hash:
                    raise ValueError("This request_id was already used with a different shot specification.")
                take = self.controller.get_take(durable["take_id"])
                self._generation_requests[request_id] = {
                    "payload_hash": payload_hash,
                    "take_id": durable["take_id"],
                }
                message = (
                    "A previous attempt reserved this shot but left it PENDING. It was not re-queued to avoid a duplicate GPU job; inspect ComfyUI queue/history before deciding what to do next."
                    if take.get("status") == "PENDING"
                    else "The existing durable submission was returned; no second GPU job was created."
                )
                return {"created": False, "reused": True, "take": take, "message": message}

            active_take_id = self.controller.store.active_take_for_shot(
                spec["film_id"], spec["scene_id"], spec["shot_id"]
            )
            if active_take_id:
                active_take = self.controller.get_take(active_take_id)
                active_snapshot = active_take.get("snapshot") if isinstance(active_take, dict) else None
                active_spec = active_snapshot.get("specification") if isinstance(active_snapshot, dict) else None
                if not isinstance(active_spec, dict):
                    raise ValueError(
                        f"Shot {active_take_id} is already awaiting generation/review. Its saved specification could not be safely compared."
                    )
                active_hash = hashlib.sha256(
                    json.dumps(active_spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                ).hexdigest()
                if active_hash == payload_hash:
                    self._generation_requests[request_id] = {
                        "payload_hash": payload_hash,
                        "take_id": active_take_id,
                    }
                    return {
                        "created": False,
                        "reused": True,
                        "take": active_take,
                        "message": "An existing take for this shot was found. No additional ComfyUI job was created.",
                    }
                raise ValueError(
                    f"Shot {active_take_id} is already pending, running or awaiting Director review. Review it before submitting a different specification for the same shot ID."
                )

            readiness = self.real_shot_readiness(force=True)
            if not readiness.get("enabled"):
                raise ValueError(str(readiness.get("reason", "Real shot submission is locked by preflight.")))

            take, created = self.controller.generate(
                spec,
                submission_request_id=request_id,
                submission_payload_hash=payload_hash,
                return_created=True,
            )
            take_id = take.get("take_id") if isinstance(take, dict) else None
            if not isinstance(take_id, str) or not take_id:
                raise RuntimeError("Controller did not return a valid take_id after submission.")
            self._generation_requests[request_id] = {
                "payload_hash": payload_hash,
                "take_id": take_id,
            }
            while len(self._generation_requests) > 256:
                self._generation_requests.pop(next(iter(self._generation_requests)))
            message = (
                "An existing durable submission was returned; no second GPU job was created."
                if not created
                else "Real T2V shot accepted by the controller. Monitor its progress and review the output before approval."
            )
            return {
                "created": created,
                "reused": not created,
                "take": take,
                "message": message,
            }

    def create_mock_test(self) -> dict[str, Any]:
        if type(self.controller.adapter).__name__ != "MockComfyUIAdapter":
            raise ValueError("Mock Test is available only while the console is in Mock Mode.")

        # Reuse an active/reviewable mock take instead of accidentally creating a
        # second job when the Director double-clicks the test button.
        existing = self.list_takes(MOCK_TEST_FILM_ID)
        active = [
            t
            for t in existing
            if t["status"] in {"SUBMITTED", "RUNNING", "COMPLETED"}
            and t["scene_id"] == MOCK_TEST_SCENE_ID
            and t["shot_id"] == MOCK_TEST_SHOT_ID
        ]
        if active:
            latest = max(active, key=lambda t: (t["take_number"], t["updated_at"]))
            return {"created": False, "reused": True, "take": latest}

        spec_path = self.root / "config" / "test_shot.json"
        spec = json.loads(spec_path.read_text(encoding="utf-8"))
        spec.update(
            {
                "film_id": MOCK_TEST_FILM_ID,
                "scene_id": MOCK_TEST_SCENE_ID,
                "shot_id": MOCK_TEST_SHOT_ID,
                "generation_mode": "TEXT_TO_VIDEO",
                "duration": 8,
                "resolution": "1440p",
                "aspect_ratio": "16:9",
                "frame_rate": 24,
                "quality_preset": "Mock lifecycle verification",
            }
        )
        take = self.controller.generate(spec)
        return {
            "created": True,
            "reused": False,
            "take": take,
            "message": "Mock generation submitted. No real LTX/ComfyUI service was called.",
        }

    def take_review_video(self, take_id: str) -> tuple[str, Path | str] | None:
        take = self.controller.get_take(take_id)
        if take.get("status") not in {"COMPLETED", "APPROVED"}:
            return None

        if take.get("status") == "APPROVED":
            try:
                records = self.controller.export_status(take_id)
            except Exception:
                records = []
            for record in records:
                if record.get("status") == "VERIFIED" and record.get("kind") == "video" and record.get("path"):
                    path = Path(record["path"]).resolve()
                    workspace = self.controller.export_manager.workspace_root.resolve()
                    try:
                        path.relative_to(workspace)
                    except ValueError:
                        continue
                    if path.is_file():
                        return "file", path

        metadata = take.get("output_metadata") or {}
        media_files = metadata.get("media_files") if isinstance(metadata, dict) else None
        if not isinstance(media_files, list):
            return None
        for media in media_files:
            if not isinstance(media, dict) or media.get("kind") != "video":
                continue
            source_path = media.get("source_path")
            if source_path:
                path = Path(source_path).resolve()
                try:
                    path.relative_to(self.root)
                except ValueError:
                    continue
                if path.is_file():
                    return "file", path
            url = media.get("url")
            if isinstance(url, str) and url.startswith(("http://", "https://")):
                return "url", url
        return None


INDEX_HTML = Path(__file__).with_name("studio_control_room.html").read_text(encoding="utf-8")


class Handler(BaseHTTPRequestHandler):
    server_version = "HIS-RISEN-Director-Console/0.2"

    def _console(self) -> DirectorConsole:
        return self.server.console  # type: ignore[attr-defined]

    def _cookie_token(self) -> str | None:
        raw = self.headers.get("Cookie", "")
        for part in raw.split(";"):
            key, _, value = part.strip().partition("=")
            if key == COOKIE_NAME:
                return value
        return None

    def _authed(self) -> bool:
        return self._console().sessions.valid(self._cookie_token())

    def _secure_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; media-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
        )
        if self.headers.get("X-Forwarded-Proto", "http").lower() == "https":
            self.send_header("Strict-Transport-Security", "max-age=31536000; includeSubDomains")

    def _json(self, status: int, payload: Any) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self._secure_headers()
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> Any:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise RequestBodyError("invalid Content-Length") from exc
        if length < 0 or length > MAX_BODY_BYTES:
            raise RequestBodyError("request body is too large")
        raw = self.rfile.read(length) if length else b"{}"
        try:
            return json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise RequestBodyError("invalid JSON request body") from exc

    def _require_auth(self) -> bool:
        if self._authed():
            return True
        self._json(HTTPStatus.UNAUTHORIZED, {"ok": False, "error": "authentication_required"})
        return False

    def _check_origin(self) -> bool:
        origin = self.headers.get("Origin")
        if not origin:
            return True
        parsed = urlparse(origin)
        host = self.headers.get("Host", "")
        if parsed.netloc != host:
            self._json(HTTPStatus.FORBIDDEN, {"ok": False, "error": "origin_not_allowed"})
            return False
        return True

    def do_GET(self) -> None:
        path = urlparse(self.path).path.rstrip("/") or "/"
        try:
            if path == "/":
                body = INDEX_HTML.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self._secure_headers()
                self.end_headers()
                self.wfile.write(body)
                return
            if path == "/health":
                self._json(200, {"ok": True, "service": APP_NAME})
                return
            if not path.startswith("/api/"):
                self._json(404, {"ok": False, "error": "not_found"})
                return
            if path == "/api/status":
                if not self._require_auth():
                    return
                self._json(200, {"ok": True, "data": self._console().status()})
                return
            if not self._require_auth():
                return
            if path == "/api/studio/overview":
                self._json(200, {"ok": True, "data": self._console().workspace.overview()})
                return
            if path == "/api/studio/projects":
                self._json(200, {"ok": True, "data": self._console().workspace.list_projects()})
                return
            if path == "/api/studio/scenes":
                q = parse_qs(urlparse(self.path).query)
                project_id = q.get("project_id", [""])[0]
                self._json(200, {"ok": True, "data": self._console().workspace.list_scenes(project_id)})
                return
            if path == "/api/studio/shots":
                q = parse_qs(urlparse(self.path).query)
                project_id = q.get("project_id", [""])[0]
                scene_id = q.get("scene_id", [""])[0]
                self._json(200, {"ok": True, "data": self._console().workspace.list_shots(project_id, scene_id)})
                return
            if path == "/api/studio/tests":
                q = parse_qs(urlparse(self.path).query)
                project_id = q.get("project_id", [""])[0]
                self._json(200, {"ok": True, "data": self._console().workspace.list_tests(project_id)})
                return
            if path == "/api/studio/assets":
                q = parse_qs(urlparse(self.path).query)
                project_id = q.get("project_id", [""])[0]
                category = q.get("category", [""])[0]
                self._json(200, {"ok": True, "data": self._console().workspace.list_assets(project_id, category)})
                return
            if path == "/api/studio/reviews":
                q = parse_qs(urlparse(self.path).query)
                take_id = q.get("take_id", [""])[0]
                self._json(200, {"ok": True, "data": self._console().workspace.list_reviews(take_id)})
                return
            if path == "/api/studio/reports":
                self._json(200, {"ok": True, "data": self._console().workspace.reports()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/shot-template":
                self._json(200, {"ok": True, "data": self._console().shot_template()})
                return
            if path == "/api/generation-readiness":
                self._json(200, {"ok": True, "data": self._console().real_shot_readiness()})
                return
            if path == "/api/films":
                self._json(200, {"ok": True, "data": self._console().list_films()})
                return
            if path == "/api/takes":
                q = parse_qs(urlparse(self.path).query)
                film_id = q.get("film_id", [None])[0]
                self._json(200, {"ok": True, "data": self._console().list_takes(film_id)})
                return
            if path.startswith("/api/films/") and path.endswith("/readiness"):
                film_id = unquote(path.split("/")[3])
                self._json(200, {"ok": True, "data": self._console().controller.film_readiness(film_id)})
                return
            if path.startswith("/api/takes/") and path.endswith("/preview"):
                take_id = unquote(path.split("/")[3])
                preview = self._console().take_review_video(take_id)
                if not preview:
                    self._json(404, {"ok": False, "error": "video_preview_not_available"})
                    return
                kind, target = preview
                if kind == "file":
                    self._send_file(Path(target), "video/mp4")
                    return
                # URL proxying is intentionally reserved for configured controller
                # output URLs; it is never accepted from a Director text field.
                try:
                    retriever = self._console().controller.export_manager.retriever
                    with retriever.open_remote(str(target), timeout=30) as response:
                        self.send_response(200)
                        self.send_header("Content-Type", response.headers.get("Content-Type", "video/mp4"))
                        length = response.headers.get("Content-Length")
                        if length:
                            self.send_header("Content-Length", length)
                        self.send_header("Cache-Control", "private, max-age=30")
                        self._secure_headers()
                        self.end_headers()
                        while chunk := response.read(1024 * 1024):
                            self.wfile.write(chunk)
                except Exception:
                    self._json(502, {"ok": False, "error": "video_preview_upstream_failed"})
                return
            self._json(404, {"ok": False, "error": "not_found"})
        except Exception as exc:
            self._json(500, {"ok": False, "error": f"{type(exc).__name__}: {exc}"})

    def do_POST(self) -> None:
        path = urlparse(self.path).path.rstrip("/") or "/"
        try:
            if path == "/api/login":
                key = self.client_address[0]
                if not self._console().limiter.allowed(key):
                    self._json(429, {"ok": False, "error": "too_many_attempts"})
                    return
                body = self._read_json()
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                presented = str(body.get("pin", ""))
                if not secrets.compare_digest(presented, self._console().pin):
                    self._console().limiter.failure(key)
                    self._json(401, {"ok": False, "error": "invalid_pin"})
                    return
                token = self._console().sessions.create()
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                secure = "; Secure" if self.headers.get("X-Forwarded-Proto", "http").lower() == "https" else ""
                self.send_header("Set-Cookie", f"{COOKIE_NAME}={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_TTL}{secure}")
                self._secure_headers()
                body_bytes = b'{"ok":true}'
                self.send_header("Content-Length", str(len(body_bytes)))
                self.end_headers()
                self.wfile.write(body_bytes)
                return
            if path == "/api/logout":
                self._console().sessions.revoke(self._cookie_token())
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                secure = "; Secure" if self.headers.get("X-Forwarded-Proto", "http").lower() == "https" else ""
                self.send_header("Set-Cookie", f"{COOKIE_NAME}=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict{secure}")
                self._secure_headers()
                body_bytes = b'{"ok":true}'
                self.send_header("Content-Length", str(len(body_bytes)))
                self.end_headers()
                self.wfile.write(body_bytes)
                return
            if not self._check_origin():
                return
            if not self._require_auth():
                return

            body = self._read_json()
            if path.startswith("/api/studio/") and not self.headers.get("Origin"):
                self._json(HTTPStatus.FORBIDDEN, {"ok": False, "error": "origin_required"})
                return
            if path == "/api/studio/projects":
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                self._json(201, {"ok": True, "data": self._console().workspace.create_project(body)})
                return
            if path == "/api/studio/scenes":
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                self._json(201, {"ok": True, "data": self._console().workspace.create_scene(body)})
                return
            if path == "/api/studio/shots":
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                self._json(201, {"ok": True, "data": self._console().workspace.create_shot(body)})
                return
            if path == "/api/studio/tests":
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                self._json(201, {"ok": True, "data": self._console().workspace.create_test(body)})
                return
            if path == "/api/studio/assets":
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                self._json(201, {"ok": True, "data": self._console().workspace.create_asset(body)})
                return
            if path == "/api/studio/reviews":
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                self._json(201, {"ok": True, "data": self._console().workspace.create_review(body)})
                return
            status_parts = path.split("/")
            if len(status_parts) == 6 and status_parts[1:3] == ["api", "studio"] and status_parts[5] == "status" and status_parts[3] in {"projects", "scenes", "shots", "tests"}:
                resource = {"projects": "project", "scenes": "scene", "shots": "shot", "tests": "test"}[status_parts[3]]
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                result = self._console().workspace.update_status(resource, unquote(status_parts[4]), body.get("status"))
                self._json(200, {"ok": True, "data": result})
                return
            if path == "/api/shots/generate":
                # Browsers must send the same-origin Origin header for this
                # state-changing endpoint; SameSite=Strict is an additional layer.
                if not self.headers.get("Origin"):
                    self._json(HTTPStatus.FORBIDDEN, {"ok": False, "error": "origin_required"})
                    return
                if not isinstance(body, dict) or set(body) != {"request_id", "specification", "cost_acknowledged"}:
                    raise ValueError("shot submission requires request_id, specification and cost_acknowledged")
                if body["cost_acknowledged"] is not True:
                    raise ValueError("director cost acknowledgement is required before real generation")
                if not isinstance(body["specification"], dict):
                    raise ValueError("specification must be a JSON object")
                result = self._console().submit_real_shot(body["specification"], body["request_id"])
                self._json(202, {"ok": True, "data": result})
                return
            if path == "/api/updates/check":
                if body not in ({}, None):
                    raise ValueError("update check does not accept configuration; it only reads official metadata")
                self._json(200, {"ok": True, "data": self._console().check_for_updates()})
                return
            if path == "/api/mock-test":
                if body not in ({}, None):
                    raise ValueError("mock test does not accept configuration; it uses the fixed safe fixture")
                self._json(200, {"ok": True, "data": self._console().create_mock_test()})
                return
            if path.startswith("/api/takes/") and path.endswith("/approve"):
                take_id = unquote(path.split("/")[3])
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                result = self._console().controller.director_approve(take_id, auto_export=bool(body.get("auto_export", True)))
                self._json(200, {"ok": True, "data": result})
                return
            if path.startswith("/api/takes/") and path.endswith("/reject"):
                take_id = unquote(path.split("/")[3])
                if not isinstance(body, dict):
                    raise ValueError("request body must be an object")
                result = self._console().controller.director_reject(take_id, str(body.get("reason", "")).strip())
                self._json(200, {"ok": True, "data": result})
                return
            if path.startswith("/api/takes/") and path.endswith("/regenerate"):
                if body not in ({}, None):
                    raise ValueError("regeneration does not accept a request body")
                take_id = unquote(path.split("/")[3])
                result = self._console().controller.regenerate(take_id)
                self._json(200, {"ok": True, "data": result})
                return
            if path.startswith("/api/takes/") and path.endswith("/export"):
                if body not in ({}, None):
                    raise ValueError("export does not accept a request body")
                take_id = unquote(path.split("/")[3])
                result = self._console().controller.export_approved(take_id)
                self._json(200, {"ok": True, "data": result})
                return
            self._json(404, {"ok": False, "error": "not_found"})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except ValidationError as exc:
            self._json(422, {"ok": False, "error": "validation_error", "details": list(exc.errors)})
        except RequestBodyError as exc:
            self._json(413 if "too large" in str(exc) else 400, {"ok": False, "error": str(exc)})
        except Exception as exc:
            self._json(409, {"ok": False, "error": f"{type(exc).__name__}: {exc}"})

    def _send_file(self, path: Path, content_type: str) -> None:
        if not path.is_file():
            self._json(404, {"ok": False, "error": "file_not_found"})
            return
        size = path.stat().st_size
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(size))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Cache-Control", "private, max-age=30")
        self._secure_headers()
        self.end_headers()
        with path.open("rb") as handle:
            while chunk := handle.read(1024 * 1024):
                self.wfile.write(chunk)

    def log_message(self, fmt: str, *args: object) -> None:
        return


def main() -> None:
    parser = argparse.ArgumentParser(description=APP_NAME)
    parser.add_argument("--host", default=os.environ.get("HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "8080")))
    parser.add_argument("--backend", choices=["mock", "comfyui"], default=None)
    args = parser.parse_args()

    root = Path(__file__).resolve().parent
    pin = os.environ.get("HRF_DIRECTOR_PIN", "").strip()
    controller = build_controller(root, backend=args.backend)
    console = DirectorConsole(controller, pin, root)
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    server.console = console  # type: ignore[attr-defined]
    print(f"{APP_NAME} listening on http://{args.host}:{args.port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        console.stop()
        controller.close()
        server.server_close()


if __name__ == "__main__":
    main()
