from __future__ import annotations

import os
from pathlib import Path


def resolve_data_root(project_root: Path) -> Path:
    """Resolve durable application data outside the extracted application directory.

    HRF_DATA_DIR should point to an attached persistent volume (for example
    /var/data). Setting this variable does not itself make a filesystem durable.
    """
    raw = os.environ.get("HRF_DATA_DIR", "").strip()
    if not raw:
        return Path(project_root).resolve()
    candidate = Path(raw).expanduser()
    if not candidate.is_absolute():
        raise ValueError("HRF_DATA_DIR must be an absolute path to an attached persistent volume")
    candidate.mkdir(parents=True, exist_ok=True)
    return candidate.resolve()
