from __future__ import annotations

from pathlib import Path
import ipaddress
import os
from typing import Any
from urllib.parse import urlsplit

from adapters.mock import MockComfyUIAdapter
from comfyui.adapter import RealComfyUIAdapter
from config.runtime import load_runtime
from config.data_paths import resolve_data_root
from controller.service import Controller
from exports import ApprovedOutputExportManager, FileOutputRetriever
from profiles.registry import ProfileRegistry
from storage.sqlite_store import SQLiteStore
from workflows.registry import WorkflowRegistry
from workflows.capability_registry import LTX25CapabilityRegistry


def validate_comfyui_base_url(base_url: str) -> str:
    """Require HTTPS for remote ComfyUI endpoints; allow HTTP only on loopback."""
    try:
        parsed = urlsplit(base_url)
        _ = parsed.port  # Access also validates malformed port values.
    except ValueError as exc:
        raise ValueError("ComfyUI base URL contains an invalid port or URL component") from exc
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("ComfyUI base URL must be an absolute HTTP(S) URL")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("ComfyUI base URL must not contain credentials, query parameters, or fragments")
    host = parsed.hostname.lower()
    try:
        loopback = host == "localhost" or ipaddress.ip_address(host).is_loopback
    except ValueError:
        loopback = host == "localhost"
    if parsed.scheme == "http" and not loopback:
        raise ValueError("remote ComfyUI endpoints must use HTTPS; plain HTTP is allowed only for loopback")
    return base_url.rstrip("/")


def build_controller(root: Path | None = None, backend: str | None = None) -> Controller:
    project_root = root.resolve() if root is not None else Path(__file__).resolve().parents[1]
    runtime = load_runtime(project_root)
    selected_backend = backend or str(runtime.get("backend", "mock"))
    if selected_backend not in {"mock", "comfyui"}:
        raise ValueError(f"unsupported controller backend: {selected_backend}")

    data_root = resolve_data_root(project_root)
    comfy: dict[str, Any] = {}
    base_url = ""
    headers: dict[str, str] = {}
    if selected_backend == "comfyui":
        raw_comfy = runtime.get("comfyui", {})
        if not isinstance(raw_comfy, dict):
            raise ValueError("runtime.comfyui must be an object")
        comfy = raw_comfy
        base_url = os.environ.get("HRF_COMFYUI_BASE_URL", str(comfy.get("base_url", ""))).strip()
        if not base_url:
            raise ValueError("HRF_COMFYUI_BASE_URL or runtime.comfyui.base_url is required for the comfyui backend")
        base_url = validate_comfyui_base_url(base_url)
        raw_headers = comfy.get("headers") if isinstance(comfy.get("headers"), dict) else {}
        headers = {str(key): str(value) for key, value in raw_headers.items()}
        api_key = os.environ.get("HRF_COMFYUI_API_KEY", "").strip()
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"

    profiles = ProfileRegistry(
        project_root / "profiles" / "characters.json",
        project_root / "profiles" / "voices.json",
        data_root,
    )
    workflows = WorkflowRegistry(project_root / "workflows" / "presets.json")
    capabilities = LTX25CapabilityRegistry(project_root / "workflows" / "ltx25_capabilities.json")
    store = SQLiteStore(data_root / "storage" / "controller.sqlite3")

    workspace_setting = Path(str(runtime.get("workspace_root", "outputs/production"))).expanduser()
    workspace_root = workspace_setting if workspace_setting.is_absolute() else data_root / workspace_setting
    retriever = (
        FileOutputRetriever(headers=headers, allowed_base_url=base_url)
        if selected_backend == "comfyui"
        else FileOutputRetriever()
    )
    export_manager = ApprovedOutputExportManager(
        project_root,
        store,
        retriever,
        workspace_root,
    )

    if selected_backend == "mock":
        adapter = MockComfyUIAdapter(project_root)
    else:
        adapter = RealComfyUIAdapter(
            project_root,
            base_url,
            timeout=float(comfy.get("request_timeout_seconds", 30)),
            job_timeout=float(comfy.get("job_timeout_seconds", 3600)),
            headers=headers,
            asset_root=data_root,
        )

    return Controller(
        project_root,
        profiles,
        workflows,
        store,
        adapter,
        capability_registry=capabilities,
        export_manager=export_manager,
        auto_export_approved=bool(runtime.get("auto_export_approved", False)),
        asset_root=data_root,
    )
