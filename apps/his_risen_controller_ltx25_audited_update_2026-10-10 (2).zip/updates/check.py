from __future__ import annotations
import json, urllib.request, urllib.error
from pathlib import Path

SOURCES = {
  "ltx_github_releases": "https://api.github.com/repos/Lightricks/LTX-2/releases/latest",
  "ltx_docs_compatibility": "https://docs.ltx.io/open-source-model/reference/workflow-asset-compatibility",
  "ltx_api_changelog": "https://docs.ltx.io/api-changelog",
  "ltx_diffusers_model": "https://huggingface.co/api/models/Lightricks/LTX-2.5-Diffusers",
}

def check_updates(root: Path, timeout: float = 8.0) -> dict:
    manifest_path = root / "workflows" / "ltx25_capabilities.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    results = []
    for name, url in SOURCES.items():
        req = urllib.request.Request(url, headers={"User-Agent":"HIS-RISEN-Controller-Update-Checker/1.0", "Accept":"application/vnd.github+json, application/json, text/html"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as response:
                body = response.read(250000).decode("utf-8", errors="replace")
                results.append({"source":name,"url":url,"reachable":True,"http_status":response.status,"checked":True,"bytes_sampled":len(body),"note":"Source reachable. This check does not automatically interpret or install changes; review official release notes and model cards."})
        except Exception as exc:
            results.append({"source":name,"url":url,"reachable":False,"checked":True,"error":f"{type(exc).__name__}: {exc}"})
    return {"controller_update_check":"check_only_no_changes_applied","manifest_version":manifest.get("manifest_version"),"model_family":manifest.get("model_family"),"automatic_install":False,"downloads_started":False,"gpu_jobs_started":False,"sources":results,"next_step":"Compare source changes against the manifest; require Director approval, backup, compatibility checks and regression tests before applying any update."}
