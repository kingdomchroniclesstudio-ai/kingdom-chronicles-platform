from __future__ import annotations

"""Read-only LTX update discovery with a local observation history.

This module never installs code, changes the capability manifest, downloads model
weights, or starts GPU work. It records only metadata observed from official APIs.
"""

import hashlib
import json
import urllib.error
import urllib.error
import urllib.request
import re
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SOURCES = {
    "ltx_github_releases": "https://api.github.com/repos/Lightricks/LTX-2/releases/latest",
    "ltx_docs_compatibility": "https://docs.ltx.io/open-source-model/reference/workflow-asset-compatibility",
    "ltx_api_changelog": "https://docs.ltx.io/api-changelog",
    "ltx_diffusers_model": "https://huggingface.co/api/models/Lightricks/LTX-2.5-Diffusers",
}

RELEASE_FEED_URL = "https://github.com/Lightricks/LTX-2/releases.atom"

USER_AGENT = "HIS-RISEN-Controller-Update-Checker/1.1"
BASELINE_RELATIVE_PATH = Path("storage") / "update_check_state.json"
OBSERVATIONS_RELATIVE_PATH = Path("storage") / "update_check_observations.json"
MAX_RESPONSE_BYTES = 1_000_000


def _request(url: str, timeout: float) -> tuple[int, bytes, str | None]:
    headers = {"User-Agent": USER_AGENT, "Accept": "application/json, text/html;q=0.9, */*;q=0.8"}
    if url == RELEASE_FEED_URL:
        headers["Accept"] = "application/atom+xml, application/xml;q=0.9, */*;q=0.8"
    if "api.github.com" in url:
        headers["Accept"] = "application/vnd.github+json"
        headers["X-GitHub-Api-Version"] = "2022-11-28"
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            return response.status, response.read(MAX_RESPONSE_BYTES), response.headers.get("Content-Type")
    except urllib.error.HTTPError as api_error:
        if url != SOURCES["ltx_github_releases"] or api_error.code not in {403, 429}:
            raise
        try:
            feed_req = urllib.request.Request(RELEASE_FEED_URL, headers={
                "User-Agent": USER_AGENT,
                "Accept": "application/atom+xml, application/xml;q=0.9, */*;q=0.8",
            })
            with urllib.request.urlopen(feed_req, timeout=timeout) as response:
                feed_body = response.read(MAX_RESPONSE_BYTES)
                feed_type = response.headers.get("Content-Type")
            metadata = _parse_release_atom(feed_body)
        except Exception as fallback_error:
            raise RuntimeError(
                f"GitHub Releases API returned HTTP {api_error.code}; official Atom-feed fallback failed: "
                f"{type(fallback_error).__name__}: {fallback_error}"
            ) from fallback_error
        return 200, json.dumps(metadata).encode("utf-8"), "application/json; fallback=official-atom-feed"


def _parse_release_atom(body: bytes) -> dict[str, Any]:
    namespace = "{http://www.w3.org/2005/Atom}"
    try:
        root = ET.fromstring(body)
    except ET.ParseError as exc:
        raise ValueError(f"GitHub releases Atom feed was not valid XML: {exc}") from exc
    entry = root.find(f"{namespace}entry")
    if entry is None:
        raise ValueError("GitHub releases Atom feed contains no release entry")
    title = (entry.findtext(f"{namespace}title") or "").strip()
    entry_id = (entry.findtext(f"{namespace}id") or "").strip()
    published = (entry.findtext(f"{namespace}published") or entry.findtext(f"{namespace}updated") or "").strip()
    links = entry.findall(f"{namespace}link")
    release_url = next((item.get("href", "").strip() for item in links
                        if item.get("href") and item.get("rel", "alternate") == "alternate"), "")
    release_url = release_url or entry_id
    tag = title.split()[-1] if title else ""
    if not tag or not re.fullmatch(r"v?\d[\w.+-]*", tag):
        for candidate in (release_url, entry_id):
            match = re.search(r"/tag/([^/?#]+)", candidate)
            if match:
                tag = match.group(1)
                break
    if not tag:
        raise ValueError("GitHub releases Atom feed entry did not expose a release tag")
    return {"tag_name": tag, "published_at": published or None,
            "html_url": release_url or "https://github.com/Lightricks/LTX-2/releases", "body": ""}


def _json_object(body: bytes) -> dict[str, Any] | None:
    try:
        value = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def _sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _load_state(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def check_updates(root: Path, timeout: float = 8.0, *, state_root: Path | None = None) -> dict:
    """Check official endpoints and compare API metadata with the last observation.

    Network failures are reported per source. The state file is written only when
    valid release/model metadata is available; manifest and installed assets remain
    untouched. A first observation is never described as a confirmed update.
    """
    root = Path(root)
    manifest_path = root / "workflows" / "ltx25_capabilities.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    baseline_path = root / BASELINE_RELATIVE_PATH
    observation_root = Path(state_root).resolve() if state_root is not None else root
    observations_path = observation_root / OBSERVATIONS_RELATIVE_PATH
    baseline_state = _load_state(baseline_path)
    previous = baseline_state.get("sources", {})
    observations: dict[str, dict[str, Any]] = {}
    results: list[dict[str, Any]] = []

    for name, url in SOURCES.items():
        result: dict[str, Any] = {
            "source": name,
            "url": url,
            "checked": True,
            "reachable": False,
            "purpose": "metadata_discovery" if name in {"ltx_github_releases", "ltx_diffusers_model"} else "reachability_only",
        }
        try:
            status, body, content_type = _request(url, timeout)
            result.update({"reachable": True, "http_status": status, "content_type": content_type, "bytes_sampled": len(body)})
            if content_type and "fallback=official-atom-feed" in content_type:
                result["url"] = RELEASE_FEED_URL
                result["fallback_used"] = "official GitHub releases Atom feed"
                result["note"] = "Used the official public releases Atom feed because the API was rate-limited; comparing release tags only."
            parsed = _json_object(body) if name in {"ltx_github_releases", "ltx_diffusers_model"} else None
            if name == "ltx_github_releases" and parsed is not None:
                tag = parsed.get("tag_name")
                published = parsed.get("published_at")
                html_url = parsed.get("html_url")
                body_text = parsed.get("body") or ""
                fingerprint = _sha256(json.dumps({"tag_name": tag, "published_at": published}, sort_keys=True))
                observation = {"tag_name": tag, "published_at": published, "html_url": html_url, "fingerprint": fingerprint}
                old = previous.get(name, {}) if isinstance(previous, dict) else {}
                if not tag:
                    result["metadata_status"] = "missing_release_tag"
                elif not old.get("tag_name"):
                    result["change_status"] = "first_observation_needs_manual_baseline"
                elif old.get("fingerprint") != fingerprint:
                    result["change_status"] = "release_metadata_differs_from_approved_baseline"
                else:
                    result["change_status"] = "no_change_since_last_check"
                result["release"] = {"tag_name": tag, "published_at": published, "html_url": html_url, "notes_sha256": _sha256(body_text)}
                if tag:
                    observations[name] = observation
            elif name == "ltx_diffusers_model" and parsed is not None:
                revision = parsed.get("sha")
                modified = parsed.get("lastModified")
                fingerprint = _sha256(json.dumps({"sha": revision, "lastModified": modified}, sort_keys=True))
                observation = {"revision": revision, "last_modified": modified, "fingerprint": fingerprint}
                old = previous.get(name, {}) if isinstance(previous, dict) else {}
                if not revision:
                    result["metadata_status"] = "missing_model_revision"
                elif not old.get("revision"):
                    result["change_status"] = "first_observation_needs_manual_baseline"
                elif old.get("fingerprint") != fingerprint:
                    result["change_status"] = "model_metadata_differs_from_approved_baseline"
                else:
                    result["change_status"] = "no_change_since_last_check"
                result["model"] = {"revision": revision, "last_modified": modified}
                if revision:
                    observations[name] = observation
            elif name in {"ltx_github_releases", "ltx_diffusers_model"}:
                result["metadata_status"] = "response_not_valid_json_object"
                result["note"] = "Endpoint responded, but structured metadata could not be read. No update status inferred."
            else:
                result["note"] = "Official documentation endpoint reachable; this checker does not parse page content or infer compatibility changes."
        except Exception as exc:
            result["error"] = f"{type(exc).__name__}: {exc}"
        results.append(result)

    # Compare every check against the bundled approved baseline; observations are diagnostics only.
    if observations:
        try:
            observations_path.parent.mkdir(parents=True, exist_ok=True)
            observations_path.write_text(json.dumps({
                "schema_version": 1,
                "last_checked_at": datetime.now(timezone.utc).isoformat(),
                "sources": observations,
                "note": "Latest observations only; not used as a baseline and not an installed-version manifest.",
            }, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        except OSError as exc:
            results.append({"source": "local_observation_cache", "checked": True, "reachable": None, "error": f"{type(exc).__name__}: {exc}"})

    changes = [r for r in results if r.get("change_status") in {
        "first_observation_needs_manual_baseline",
        "release_metadata_differs_from_approved_baseline",
        "model_metadata_differs_from_approved_baseline",
    }]
    return {
        "controller_update_check": "metadata_discovery_only_no_changes_applied",
        "manifest_version": manifest.get("manifest_version"),
        "model_family": manifest.get("model_family"),
        "automatic_install": False,
        "downloads_started": False,
        "gpu_jobs_started": False,
        "manifest_modified": False,
        "installed_version_confirmed": False,
        "change_candidates_requiring_manual_review": len(changes),
        "sources": results,
        "observation_cache": str(OBSERVATIONS_RELATIVE_PATH).replace("\\", "/"),
        "next_step": "Review any candidate against official release notes, installed asset hashes and compatibility docs. This is not proof that an update is compatible or needed. Director approval, backup, compatibility checks and regression tests remain mandatory before applying changes.",
    }
