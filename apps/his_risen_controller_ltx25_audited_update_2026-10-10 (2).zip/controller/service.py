from __future__ import annotations
import copy
from pathlib import Path
from typing import Any
from adapters.base import GenerationAdapter
from models.specification import GENERATION_MODES, ValidationError,validate_assets,validate_specification
from profiles.registry import ProfileRegistry
from prompts.builder import build_prompt
from storage.sqlite_store import SQLiteStore
from workflows.registry import WorkflowRegistry
from workflows.capability_registry import LTX25CapabilityRegistry
from exports import ApprovedOutputExportManager
class Controller:
    def __init__(self,root:Path,profiles:ProfileRegistry,workflows:WorkflowRegistry,store:SQLiteStore,adapter:GenerationAdapter,export_manager:ApprovedOutputExportManager|None=None,auto_export_approved:bool=False,capability_registry:LTX25CapabilityRegistry|None=None,asset_root:Path|None=None):
        self.root=root.resolve(); self.asset_root=(asset_root or self.root).resolve(); self.profiles=profiles; self.workflows=workflows; self.store=store; self.adapter=adapter; self.export_manager=export_manager; self.auto_export_approved=auto_export_approved
        self.capability_registry=capability_registry or LTX25CapabilityRegistry(self.root / "workflows" / "ltx25_capabilities.json")
    def _continuation_snapshot(self,spec):
        if spec["shot_type"]!="EXTENSION": return None
        source_id=spec["continuation_source"]["take_id"]
        try: source=self.store.get_take(source_id)
        except LookupError as exc: raise ValidationError([f"continuation_source.take_id: source {source_id} does not exist."]) from exc
        if source["film_id"]!=spec["film_id"]: raise ValidationError(["continuation_source.take_id: source must belong to the same film."])
        if source["status"] not in {"COMPLETED","APPROVED"}: raise ValidationError(["continuation_source.take_id: source must be COMPLETED or APPROVED."])
        if not source["output_metadata"]: raise ValidationError(["continuation_source.take_id: source has no output metadata."])
        return {"take_id":source["take_id"],"film_id":source["film_id"],"scene_id":source["scene_id"],"shot_id":source["shot_id"],"status_at_submission":source["status"],"job_id":source["job_id"],"output_metadata":source["output_metadata"]}
    def recommend_generation(self,specification):
        """Return a recommendation only; this method never submits a generation job."""
        spec=copy.deepcopy(specification); validate_specification(spec,self.asset_root); profiles=self.profiles.resolve(spec)
        shot_type=spec["shot_type"]
        if shot_type=="EXTENSION":
            mode="EXTENSION"; reason="Extension is still represented in the controller contract, but the current LTX-2.5 local capability manifest does not mark a native extension preset ready; a version-compatible workflow must be installed and approved first."
        elif spec.get("generation_mode") in {"FIRST_FRAME","FIRST_LAST_FRAME"}:
            mode=spec["generation_mode"]; reason="The Director explicitly selected frame conditioning; no frame asset is created or used implicitly."
        elif spec.get("input_image") or spec.get("generation_mode")=="IMAGE_TO_VIDEO":
            mode="IMAGE_TO_VIDEO"; reason="An explicit input image is present."
        else:
            mode="TEXT_TO_VIDEO"; reason="No explicit frame-conditioning or image-to-video mode was requested."
        character_refs=[]
        for character_id, profile in profiles["characters"].items():
            refs=profile.get("reference_assets",[])
            character_refs.append({"character_id":character_id,"name":profile.get("name"),"reference_assets":[a.get("asset_id") for a in refs if isinstance(a,dict)]})
        workflow=self.workflows.select(spec)
        ltx25_plan=self.capability_registry.recommend(spec,workflow)
        return {"recommended_generation_mode":mode,"reason":reason,"character_reference_options":character_refs,"action_taken":False,"requires_director_authorization":True,"available_generation_modes":sorted(GENERATION_MODES),"ltx25_plan":ltx25_plan}

    def ltx25_capabilities(self):
        return self.capability_registry.summary()

    def generate(self,specification,submission_request_id=None,submission_payload_hash=None,return_created=False):
        spec=copy.deepcopy(specification); validate_specification(spec,self.asset_root); profiles=self.profiles.resolve(spec); workflow=self.workflows.select(spec); continuation=self._continuation_snapshot(spec); ltx25_plan=self.capability_registry.recommend(spec,workflow); snapshot={"specification":spec,"profiles":profiles,"workflow":workflow,"ltx25_plan":ltx25_plan,"prompt":build_prompt(spec,profiles),"continuation":continuation}; reservation=self.store.reserve_take(snapshot,submission_request_id=submission_request_id,submission_payload_hash=submission_payload_hash)
        if submission_request_id is not None:
            take_id,created=reservation
            if not created:
                existing=self.store.get_take(take_id)
                return (existing,False) if return_created else existing
        else:
            take_id=reservation
            created=True
        take=self._submit(take_id)
        return (take,True) if submission_request_id is not None and return_created else take
    def _submit(self,take_id):
        record=self.store.get_take(take_id)
        try: job_id=self.adapter.submit(copy.deepcopy(record["snapshot"]),client_request_id=take_id)
        except Exception as exc: self.store.record_submission_failure(take_id,f"{type(exc).__name__}: {exc}"); raise
        self.store.record_submission(take_id,job_id); return self.store.get_take(take_id)
    def advance(self,take_id):
        record=self.store.get_take(take_id)
        if record["status"] not in {"SUBMITTED","RUNNING"}: raise ValueError("Only SUBMITTED or RUNNING takes may be polled.")
        update=self.adapter.poll(record["job_id"]); self.store.record_update(take_id,update); return self.store.get_take(take_id)
    def director_approve(self,take_id,auto_export:bool|None=None):
        self.store.director_review(take_id,"APPROVED")
        result=self.store.get_take(take_id)
        should_export=self.auto_export_approved if auto_export is None else auto_export
        if should_export and self.export_manager is not None:
            self.export_manager.export_take(take_id)
            result=self.store.get_take(take_id)
        return result
    def director_reject(self,take_id,reason): self.store.director_review(take_id,"REJECTED",reason); return self.store.get_take(take_id)
    def regenerate(self,rejected_take_id):
        parent=self.store.get_take(rejected_take_id)
        if parent["status"]!="REJECTED": raise ValueError("Regeneration requires a REJECTED take.")
        snapshot=copy.deepcopy(parent["snapshot"]); spec=snapshot["specification"]; validate_specification(spec,self.asset_root); self.profiles.ensure_available(snapshot["profiles"]); self.workflows.require(snapshot["workflow"]["preset_id"]); errors=[]; validate_assets(snapshot["profiles"]["reference_assets"],self.asset_root,"saved reference_assets",errors)
        if errors: raise ValidationError(errors)
        self._continuation_snapshot(spec); new_take_id=self.store.reserve_take(snapshot,parent_take_id=rejected_take_id); return self._submit(new_take_id)
    def get_take(self,take_id): return self.store.get_take(take_id)
    def get_progress_events(self,take_id): return self.store.progress_events(take_id)
    def export_approved(self,take_id):
        if self.export_manager is None: raise ValueError("Approved output export is not configured.")
        return self.export_manager.export_take(take_id)
    def export_status(self,take_id):
        if self.export_manager is None: raise ValueError("Approved output export is not configured.")
        return self.export_manager.status(take_id)
    def film_readiness(self,film_id):
        if self.export_manager is None: raise ValueError("Approved output export is not configured.")
        return self.export_manager.film_readiness(film_id)
    def close(self): self.store.close()
