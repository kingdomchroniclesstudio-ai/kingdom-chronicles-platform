from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any


class LTX25CapabilityRegistry:
    """Version-locked, advisory registry for current official LTX-2.5 capabilities."""

    def __init__(self, path: Path):
        self.path = path.resolve()
        self.data = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(self.data, dict) or self.data.get("model_family") != "LTX-2.5":
            raise ValueError("LTX-2.5 capability manifest is invalid")

    def summary(self) -> dict[str, Any]:
        return {
            "manifest_version": self.data["manifest_version"],
            "model_family": self.data["model_family"],
            "base_stack": copy.deepcopy(self.data["base_stack"]),
            "production_profiles": copy.deepcopy(self.data["production_profiles"]),
            "official_workflows": copy.deepcopy(self.data["official_workflows"]),
            "policy": copy.deepcopy(self.data["policy"]),
            "explicitly_not_2_5_default": copy.deepcopy(self.data["explicitly_not_2_5_default"]),
            "api_note": copy.deepcopy(self.data["api_note"]),
            "audit_status": self.data.get("audit_status"),
            "integration_routes": copy.deepcopy(self.data.get("integration_routes", {})),
            "update_policy": copy.deepcopy(self.data.get("update_policy", {})),
        }

    def recommend(self, spec: dict[str, Any], workflow: dict[str, Any]) -> dict[str, Any]:
        shot_type = spec["shot_type"]
        generation_mode = spec.get("generation_mode")

        if generation_mode == "FIRST_LAST_FRAME":
            profile = "FIRST_LAST_FRAME"
            reason = "The Director explicitly selected first/last-frame conditioning."
        elif generation_mode == "FIRST_FRAME":
            profile = "MAIN_DISTILLED_2PASS"
            reason = "The Director explicitly selected a first-frame start state; use the official Image-to-Video path."
        elif generation_mode == "IMAGE_TO_VIDEO" or spec.get("input_image"):
            profile = "MAIN_DISTILLED_2PASS"
            reason = "An explicit source image is present, so the official LTX-2.5 Image-to-Video path is appropriate."
        elif shot_type == "MULTI-SHOT":
            profile = "MAIN_DISTILLED_2PASS"
            reason = "LTX-2.5 native multi-shot is the default connected-scene path."
        elif shot_type == "EXTENSION":
            profile = None
            reason = "Do not pretend the old extension preset is a native LTX-2.5 capability; a version-compatible continuation workflow must be installed and approved first."
        else:
            profile = "MAIN_DISTILLED_2PASS"
            reason = "Default production path uses the LTX-2.5 distilled model with the quality-oriented two-stage stack."

        specialists = []
        if spec.get("reference_assets"):
            specialists.append({
                "profile": "REFERENCE_SHEET_INGREDIENTS",
                "reason": "A reference sheet can improve recurring character, prop, and location consistency; Director authorization is required.",
            })
        action_text = " ".join(str(spec.get(k, "")) for k in ("action", "physical_interaction", "environment", "audio"))
        lower = action_text.lower()
        if any(word in lower for word in ("close-up", "close up", "portrait", "face", "skin", "eyes", "hands", "wounded hand")):
            specialists.append({
                "profile": "REFINE_DETAILS",
                "reason": "The shot emphasizes faces, skin, eyes or hands; the official Refine Details path is a candidate for a post-generation detail pass.",
            })
        if spec.get("resolution") == "4K":
            specialists.append({
                "profile": "NATIVE_TILED_FUSION",
                "reason": "The Director requested 4K; the current LTX-2.5 tiled-fusion workflow provides a dedicated high-resolution finishing path.",
            })
        if any(word in lower for word in ("fight", "fighting", "run", "running", "sprint", "spin", "dance", "jump", "strike", "swing", "pull", "push", "raise", "whip")):
            specialists.append({
                "profile": "MOTION_CONTROL",
                "reason": "The shot contains potentially difficult physical motion; sparse-track Motion Control can be considered if a motion guide is available.",
            })
        if any(word in lower for word in ("water", "river", "rain", "splash", "sea", "surf", "waterfall")):
            specialists.append({
                "profile": "WATER_SIMULATION",
                "reason": "The shot contains water-related motion; the official LTX-2.5 Water Simulation adapter is a candidate for a V2V finishing pass.",
            })
        if any(word in lower for word in ("slow motion", "slow-motion", "slowly", "splash", "punch", "spin", "cloth", "hair")):
            specialists.append({
                "profile": "SLOW_MOTION_CONTROL",
                "reason": "The physical action may benefit from controlled slow-motion; this is a specialist pass, not a default generation mode.",
            })
        return {
            "model_family": "LTX-2.5",
            "recommended_profile": profile,
            "reason": reason,
            "workflow_preset": workflow.get("preset_id"),
            "specialist_candidates": specialists,
            "prompt_enhancer": {
                "available": True,
                "default": "OFF_FOR_APPROVED_DETAILED_PROMPTS",
                "recommend_when": "The prompt is short, rough, or was written for another model.",
                "never_silent": True,
            },
            "quality_stack": {
                "preferred_video_vae": self.data["base_stack"]["video_vae_quality"],
                "fallback_video_vae": self.data["base_stack"]["video_vae_fast"],
                "spatial_upscaler": self.data["base_stack"]["spatial_upscaler"],
                "native_audio": True,
                "auto_duration": True,
            },
            "action_taken": False,
            "requires_director_authorization_for_specialists": True,
        }
