# HIS RISEN FILMS — LTX-2.5 Capability Upgrade

Verified against current official LTX documentation/model repositories on 2026-10-08.

## What changed

The controller now has a version-locked LTX-2.5 capability manifest and planning layer.
It knows the current official LTX-2.5 model stack and specialist workflows without pretending that an uninstalled workflow is ready.

### Main production path

- LTX-2.5 distilled 22B transformer
- LTX-specific Gemma 4 12B text encoder
- Diffusion video VAE for quality
- Audio VAE for synchronized native audio
- 2x latent spatial upscaler for two-stage refinement
- Native multi-shot support
- Optional local Gemma 4 E2B prompt enhancer
- Optional automatic duration prediction

### Premium path

- LTX-2.5 22B dev transformer for guided two-stage pipelines when the Director explicitly wants the higher-resource path.

### Specialist capabilities now recorded

- First Frame / First + Last Frame
- Reference-sheet Ingredients for character / prop / location consistency
- Motion Control
- Refine Details
- Pixel Spatial Upscaler
- Native Tiled Fusion 4K/8K path
- Water Simulation
- Slow Motion Control
- Layout to Render
- SDR to HDR

Specialist adapters are advisory. The controller never silently creates references, switches to a specialist adapter, or claims a workflow is ready.

## Important compatibility boundaries

- LTX-2.3 assets are not silently substituted for LTX-2.5 assets.
- Dub-It and Foley remain LTX-2.3-validated paths in the current documentation and are not treated as LTX-2.5 defaults.
- Existing local ComfyUI workflow placeholders remain `ready: false` until real exported API-format graphs are installed and tested.
- Hosted LTX API generation must use V2 endpoints before the V1 generation retirement date of 2026-10-26 23:59:59 UTC.

## New controller behavior

`recommend_generation` now returns an `ltx25_plan` containing:

- recommended LTX-2.5 production profile
- quality stack
- specialist candidates
- prompt-enhancer guidance
- Director-authorization requirement

Generated take snapshots also store the LTX-2.5 plan so the exact technical plan used for the take is preserved.

New endpoint:

`GET /capabilities/ltx25`

## No real generation was performed by this upgrade package

This upgrade changes the controller's capability knowledge and planning layer. It does not claim that RunPod, ComfyUI, or LTX-2.5 has been connected. A real generation test still requires the RunPod GPU, current ComfyUI-LTXVideo nodes, the required LTX-2.5 model files, and the actual exported workflows.

## Update-checker hardening (2026-10-25)

The update checker now extracts structured metadata from the official Lightricks GitHub release endpoint and the Hugging Face LTX-2.5-Diffusers model API. It fingerprints release notes and model revision metadata, then compares them with a local observation cache at `storage/update_check_state.json`. The cache is not an installed-version manifest. A first observation is deliberately reported as needing a manual baseline; subsequent changes are review candidates only.

Compatibility documentation and API changelog URLs are currently checked for reachability only. This checker does not parse their page contents, validate downloaded assets, prove workflow compatibility, install updates, download model weights, or start GPU work. Human review, backup, compatibility verification, and tests remain required before applying anything.
