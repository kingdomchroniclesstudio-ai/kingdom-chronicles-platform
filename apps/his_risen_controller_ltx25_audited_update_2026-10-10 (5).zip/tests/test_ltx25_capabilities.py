from __future__ import annotations
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from config.bootstrap import build_controller


def fresh_project() -> Path:
    temp = Path(tempfile.mkdtemp(prefix="his-risen-ltx25-capabilities-"))
    project = temp / "project"
    shutil.copytree(ROOT, project, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.sqlite3"))
    for db in project.glob("storage/*.sqlite3"):
        db.unlink()
    return project


class LTX25CapabilityTests(unittest.TestCase):
    def test_manifest_has_current_core_stack_and_specialists(self):
        data = json.loads((ROOT / "workflows" / "ltx25_capabilities.json").read_text(encoding="utf-8"))
        self.assertEqual(data["model_family"], "LTX-2.5")
        self.assertEqual(data["base_stack"]["text_encoder"], "gemma4-12b-with-proj-ltx-2.5-bf16.safetensors")
        self.assertIn("REFERENCE_SHEET_INGREDIENTS", data["production_profiles"])
        self.assertIn("REFINE_DETAILS", data["production_profiles"])
        self.assertIn("WATER_SIMULATION", data["production_profiles"])
        self.assertTrue(data["policy"]["never_silent_specialist_adapter"])

    def test_recommendation_includes_ltx25_plan_without_acting(self):
        project = fresh_project()
        controller = build_controller(project)
        try:
            spec = json.loads((project / "config" / "test_shot.json").read_text(encoding="utf-8"))
            result = controller.recommend_generation(spec)
            plan = result["ltx25_plan"]
            self.assertEqual(plan["model_family"], "LTX-2.5")
            self.assertEqual(plan["recommended_profile"], "MAIN_DISTILLED_2PASS")
            self.assertFalse(plan["action_taken"])
            self.assertTrue(plan["requires_director_authorization_for_specialists"])
        finally:
            controller.close()

    def test_water_and_reference_candidates_are_advisory(self):
        project = fresh_project()
        controller = build_controller(project)
        try:
            spec = json.loads((project / "config" / "test_shot.json").read_text(encoding="utf-8"))
            spec["reference_assets"] = [
                {"asset_id": "REF-WATER", "kind": "video", "path": "refs/mock_test.mp4"}
            ]
            spec["action"] = "Moses stands beside a river as rain and water splash around his feet."
            result = controller.recommend_generation(spec)
            names = {item["profile"] for item in result["ltx25_plan"]["specialist_candidates"]}
            self.assertIn("REFERENCE_SHEET_INGREDIENTS", names)
            self.assertIn("WATER_SIMULATION", names)
            self.assertFalse(result["ltx25_plan"]["action_taken"])
        finally:
            controller.close()

    def test_generate_snapshots_ltx25_plan(self):
        project = fresh_project()
        controller = build_controller(project)
        try:
            spec = json.loads((project / "config" / "test_shot.json").read_text(encoding="utf-8"))
            take = controller.generate(spec)
            self.assertEqual(take["snapshot"]["ltx25_plan"]["model_family"], "LTX-2.5")
            self.assertEqual(take["snapshot"]["ltx25_plan"]["recommended_profile"], "MAIN_DISTILLED_2PASS")
        finally:
            controller.close()


if __name__ == "__main__":
    unittest.main()
