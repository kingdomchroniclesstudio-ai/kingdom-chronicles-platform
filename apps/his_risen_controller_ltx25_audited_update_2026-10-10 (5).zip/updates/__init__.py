"""Safe update-check utilities for HIS RISEN controller."""
