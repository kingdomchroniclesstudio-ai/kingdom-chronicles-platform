from __future__ import annotations

import copy
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from adapters.mock import MockComfyUIAdapter
from config.bootstrap import build_controller
from models.specification import ValidationError


def fresh_project() -> Path:
    temp = Path(tempfile.mkdtemp(prefix="his-risen-phase1-test-"))
    project = temp / "project"
    shutil.copytree(ROOT, project, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.sqlite3"))
    for db in project.glob("storage/*.sqlite3"):
        db.unlink()
    return project


def load_spec(project: Path) -> dict:
    return json.loads((project / "config" / "test_shot.json").read_text(encoding="utf-8"))


class Phase1ControllerTests(unittest.TestCase):
    def tearDown(self):
        # Each test creates its own project/controller and closes explicitly.
        pass

    def test_single_shot_full_lifecycle_and_prompt_preservation(self):
        project = fresh_project()
        controller = build_controller(project)
        try:
            spec = load_spec(project)
            spec["duration"] = 8
            take = controller.generate(spec)
            self.assertEqual(take["status"], "SUBMITTED")
            self.assertEqual(take["snapshot"]["workflow"]["preset_id"], "L25-T2V-SINGLE")
            self.assertEqual((take["revision"], take["take_number"]), (1, 1))

            self.assertEqual((controller.advance(take["take_id"])["status"], controller.get_take(take["take_id"])["progress"]), ("RUNNING", 25))
            self.assertEqual(controller.advance(take["take_id"])["progress"], 75)
            completed = controller.advance(take["take_id"])
            self.assertEqual((completed["status"], completed["progress"]), ("COMPLETED", 100))
            self.assertTrue(completed["output_metadata"]["is_mock"])
            self.assertFalse(completed["output_metadata"]["media_generated"])
            self.assertEqual(completed["output_metadata"]["media_files"], [])
            self.assertIn(spec["action"], completed["snapshot"]["prompt"])
            self.assertIn(spec["continuity"], completed["snapshot"]["prompt"])
            with self.assertRaisesRegex(ValueError, "Only SUBMITTED or RUNNING"):
                controller.advance(take["take_id"])

            approved = controller.director_approve(take["take_id"])
            self.assertEqual(approved["status"], "APPROVED")
            with self.assertRaisesRegex(ValueError, "await Director review"):
                controller.director_approve(take["take_id"])
            self.assertEqual([e["progress"] for e in controller.get_progress_events(take["take_id"])], [0, 0, 25, 75, 100])
        finally:
            controller.close()

    def test_rejection_and_exact_snapshot_regeneration(self):
        project = fresh_project()
        controller = build_controller(project)
        try:
            spec = load_spec(project)
            spec["duration"] = 8
            parent = controller.generate(spec)
            for _ in range(3):
                controller.advance(parent["take_id"])
            parent = controller.director_reject(parent["take_id"], "Motion glitch in the staff interaction.")
            snapshot = copy.deepcopy(parent["snapshot"])

            child = controller.regenerate(parent["take_id"])
            self.assertEqual(child["status"], "SUBMITTED")
            self.assertEqual(child["parent_take_id"], parent["take_id"])
            self.assertEqual(child["parent_rejection_reason"], parent["rejection_reason"])
            self.assertEqual(child["snapshot"], snapshot)
            self.assertEqual((child["revision"], child["take_number"]), (2, 2))
            with self.assertRaisesRegex(ValueError, "Regeneration requires a REJECTED take"):
                controller.regenerate(child["take_id"])
            self.assertEqual(controller.get_take(parent["take_id"])["status"], "REJECTED")
        finally:
            controller.close()

    def test_routing_all_four_workflow_paths(self):
        project = fresh_project()
        controller = build_controller(project)
        try:
            base = load_spec(project)
            base["duration"] = 8
            t2v = controller.generate(base)
            self.assertEqual(t2v["snapshot"]["workflow"]["preset_id"], "L25-T2V-SINGLE")
            for _ in range(3): controller.advance(t2v["take_id"])

            i2v = copy.deepcopy(base)
            i2v["shot_id"] = "SC016-SH005"
            i2v["reference_assets"] = [{"asset_id": "REF-TEST-IMG", "kind": "image", "path": "refs/test_image.bin"}]
            i2v["input_image"] = "REF-TEST-IMG"
            take_i2v = controller.generate(i2v)
            self.assertEqual(take_i2v["snapshot"]["workflow"]["preset_id"], "L25-I2V-SINGLE")
            for _ in range(3): controller.advance(take_i2v["take_id"])

            multi = copy.deepcopy(base)
            multi["shot_id"] = "SC016-SH006"
            multi["shot_type"] = "MULTI-SHOT"
            take_multi = controller.generate(multi)
            self.assertEqual(take_multi["snapshot"]["workflow"]["preset_id"], "L25-MULTI-TESTED")
            for _ in range(3): controller.advance(take_multi["take_id"])

            extension = copy.deepcopy(base)
            extension["shot_id"] = "SC016-SH007"
            extension["shot_type"] = "EXTENSION"
            extension["continuation_source"] = {"take_id": take_multi["take_id"]}
            take_extension = controller.generate(extension)
            self.assertEqual(take_extension["snapshot"]["workflow"]["preset_id"], "L25-CONTINUE-TESTED")
            self.assertEqual(take_extension["snapshot"]["continuation"]["take_id"], take_multi["take_id"])
        finally:
            controller.close()

    def test_validation_blocks_bad_inputs_before_take_creation(self):
        project = fresh_project()
        controller = build_controller(project)
        try:
            spec = load_spec(project)
            spec["duration"] = 8
            bad_cases = [
                (lambda s: s.update(duration=None), "duration: required finite positive number"),
                (lambda s: s.update(unexpected="x"), "unsupported Phase 1 field"),
                (lambda s: s.update(shot_id="SC017-SH001"), "must belong to scene_id"),
                (lambda s: s.update(status="APPROVED"), "submission specification must be READY"),
                (lambda s: s.update(shot_type="BAD"), "must be SINGLE-SHOT, MULTI-SHOT, or EXTENSION"),
                (lambda s: s.update(reference_assets=[{"asset_id": "REF-X", "kind": "image", "path": "../outside"}]), "project-relative"),
            ]
            for mutate, expected in bad_cases:
                candidate = copy.deepcopy(spec)
                mutate(candidate)
                with self.subTest(expected=expected):
                    with self.assertRaisesRegex(ValidationError, expected):
                        controller.generate(candidate)
        finally:
            controller.close()

    def test_sqlite_persistence_and_mock_restart_limitation(self):
        project = fresh_project()
        spec = load_spec(project)
        spec["duration"] = 8
        controller = build_controller(project)
        completed = controller.generate(spec)
        for _ in range(3):
            controller.advance(completed["take_id"])
        controller.close()

        controller2 = build_controller(project)
        try:
            persisted = controller2.get_take(completed["take_id"])
            self.assertEqual(persisted["status"], "COMPLETED")
            self.assertEqual(persisted["progress"], 100)
        finally:
            controller2.close()

        controller3 = build_controller(project)
        pending_spec = copy.deepcopy(spec)
        pending_spec["shot_id"] = "SC016-SH005"
        pending = controller3.generate(pending_spec)
        controller3.advance(pending["take_id"])
        controller3.close()

        controller4 = build_controller(project)
        try:
            running = controller4.get_take(pending["take_id"])
            self.assertEqual((running["status"], running["progress"]), ("RUNNING", 25))
            with self.assertRaisesRegex(LookupError, "Mock job unavailable in this process"):
                controller4.advance(pending["take_id"])
        finally:
            controller4.close()

    def test_mock_submission_idempotency(self):
        adapter = MockComfyUIAdapter()
        request = {"hello": "world"}
        job1 = adapter.submit(request, "REQ-1")
        job2 = adapter.submit(copy.deepcopy(request), "REQ-1")
        self.assertEqual(job1, job2)
        with self.assertRaisesRegex(ValueError, "another request"):
            adapter.submit({"hello": "different"}, "REQ-1")


if __name__ == "__main__":
    unittest.main()
