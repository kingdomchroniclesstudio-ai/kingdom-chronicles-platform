from __future__ import annotations
import json
from typing import Any
def encode(value:Any)->str: return json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False)
def build_prompt(spec:dict[str,Any],profiles:dict[str,Any])->str:
    sections=[]
    def add(label,value): sections.append(f"{label}\n{value if isinstance(value,str) else encode(value)}")
    add("SHOT TYPE",spec["shot_type"]); add("DURATION IN SECONDS",spec["duration"])
    if "visual_style" in spec: add("VISUAL STYLE",spec["visual_style"])
    character_visuals={}
    for character_id,profile in profiles["characters"].items(): character_visuals[character_id]={k:v for k,v in profile.items() if k!="voice_profile_id"}
    if character_visuals: add("REGISTERED CHARACTERS",character_visuals)
    for field,label in (("environment","ENVIRONMENT"),("initial_state","INITIAL STATE"),("action","ACTION"),("physical_interaction","PHYSICAL INTERACTION"),("camera","CAMERA"),("lighting","LIGHTING"),("audio","AUDIO")):
        if field in spec: add(label,spec[field])
    add("DIALOGUE",spec["dialogue"])
    if spec["dialogue"]:
        speaker_voices={}
        for line in spec["dialogue"]:
            character_id=line["character_id"]; voice_id=profiles["characters"][character_id]["voice_profile_id"]
            speaker_voices[character_id]={"voice_profile_id":voice_id,"profile":profiles["voices"][voice_id]}
        add("REGISTERED DIALOGUE VOICES",speaker_voices)
    add("CONTINUITY",spec["continuity"])
    if "constraints" in spec: add("CONSTRAINTS",spec["constraints"])
    if profiles["reference_assets"]: add("REFERENCE ASSETS",profiles["reference_assets"])
    if "input_image" in spec: add("INPUT IMAGE REFERENCE",spec["input_image"])
    if "continuation_source" in spec: add("CONTINUATION SOURCE",spec["continuation_source"])
    return "\n\n".join(sections)
