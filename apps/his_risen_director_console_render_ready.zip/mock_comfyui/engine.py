from __future__ import annotations
import copy,uuid
from typing import Any
from adapters.base import GenerationUpdate
MOCK_NOTICE="MOCK OUTPUT — NO REAL LTX GENERATION PERFORMED"
class MockComfyUI:
    def __init__(self): self._jobs={}
    def submit(self,request:dict[str,Any],client_request_id:str)->str:
        job_id="mock-"+uuid.uuid5(uuid.NAMESPACE_URL,"his-risen-films:"+client_request_id).hex
        existing=self._jobs.get(job_id)
        if existing is not None:
            if existing["request"]!=request: raise ValueError("Mock submission ID reused with another request.")
            return job_id
        self._jobs[job_id]={"request":copy.deepcopy(request),"step":0}; return job_id
    def poll(self,job_id:str)->GenerationUpdate:
        if job_id not in self._jobs: raise LookupError("Mock job unavailable in this process. Mock jobs do not survive adapter restarts; persisted take records remain in SQLite.")
        job=self._jobs[job_id]; job["step"]=min(job["step"]+1,3); progress=(25,75,100)[job["step"]-1]
        if progress<100: return GenerationUpdate(state="RUNNING",progress=progress)
        request=job["request"]
        return GenerationUpdate(state="COMPLETED",progress=100,output_metadata={"notice":MOCK_NOTICE,"is_mock":True,"media_generated":False,"media_files":[],"job_id":job_id,"preset_id":request["workflow"]["preset_id"],"requested_duration_seconds":request["specification"]["duration"]})
