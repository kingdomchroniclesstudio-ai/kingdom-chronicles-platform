from __future__ import annotations
import math
import re
from pathlib import Path
from typing import Any
SHOT_TYPES = frozenset({"SINGLE-SHOT", "MULTI-SHOT", "EXTENSION"})
REQUIRED_FIELDS = frozenset({"film_id", "scene_id", "shot_id", "shot_type", "character_ids", "voice_profile_ids", "environment", "action", "camera", "lighting", "audio", "dialogue", "continuity", "duration", "reference_assets", "status"})
OPTIONAL_FIELDS = frozenset({"visual_style", "initial_state", "physical_interaction", "constraints", "input_image", "continuation_source", "generation_mode", "frame_conditioning"})
GENERATION_MODES = frozenset({"AUTO", "TEXT_TO_VIDEO", "IMAGE_TO_VIDEO", "FIRST_FRAME", "FIRST_LAST_FRAME", "EXTENSION"})
ID_PATTERNS = {"film": r"[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)*", "scene": r"SC[0-9]{3,}", "shot": r"SC[0-9]{3,}-SH[0-9]{3,}", "character": r"CHR-[A-Z0-9]+(?:-[A-Z0-9]+)*", "voice": r"VP-[A-Z0-9]+(?:-[A-Z0-9]+)*", "asset": r"REF-[A-Z0-9]+(?:-[A-Z0-9]+)*", "take": r"[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)*__SC[0-9]{3,}-SH[0-9]{3,}_R[0-9]{3,}_TK[0-9]{3,}"}
class ValidationError(ValueError):
    def __init__(self, errors: list[str]):
        self.errors = tuple(errors)
        super().__init__("\n".join(errors))
def nonempty_text(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())
def valid_id(value: Any, kind: str) -> bool:
    return isinstance(value, str) and re.fullmatch(ID_PATTERNS[kind], value) is not None
def validate_assets(assets: Any, root: Path, label: str, errors: list[str]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    if not isinstance(assets, list):
        errors.append(f"{label}: required list of reference objects.")
        return result
    root = root.resolve()
    for index, asset in enumerate(assets):
        prefix = f"{label}[{index}]"
        if not isinstance(asset, dict):
            errors.append(f"{prefix}: required object.")
            continue
        if set(asset) != {"asset_id", "kind", "path"}:
            errors.append(f"{prefix}: requires exactly asset_id, kind, and path.")
            continue
        asset_id = asset["asset_id"]
        if not valid_id(asset_id, "asset"):
            errors.append(f"{prefix}.asset_id: invalid REF identifier.")
            continue
        if asset_id in result:
            errors.append(f"{prefix}.asset_id: duplicate {asset_id}.")
        kind = asset["kind"]
        if not isinstance(kind, str) or kind not in {"image", "audio", "video"}:
            errors.append(f"{prefix}.kind: must be image, audio, or video.")
        path_text = asset["path"]
        if not nonempty_text(path_text):
            errors.append(f"{prefix}.path: required nonempty local path.")
        else:
            try:
                relative = Path(path_text)
                if relative.is_absolute() or ".." in relative.parts or ":" in path_text or "\\" in path_text:
                    raise ValueError("use a project-relative forward-slash path")
                target = (root / relative).resolve()
                if not target.is_relative_to(root):
                    raise ValueError("path escapes the project root")
                if not target.is_file():
                    raise ValueError("local reference file does not exist")
            except (OSError, ValueError, RuntimeError) as exc:
                errors.append(f"{prefix}.path: {exc}.")
        result[asset_id] = asset
    return result
def validate_specification(spec: Any, root: Path) -> None:
    errors: list[str] = []
    if not isinstance(spec, dict):
        raise ValidationError(["specification: required object."])
    for field in sorted(REQUIRED_FIELDS - spec.keys()): errors.append(f"{field}: missing required field.")
    for field in sorted(spec.keys() - REQUIRED_FIELDS - OPTIONAL_FIELDS): errors.append(f"{field}: unsupported Phase 1 field.")
    for field, kind in (("film_id", "film"), ("scene_id", "scene"), ("shot_id", "shot")):
        if field in spec and not valid_id(spec[field], kind): errors.append(f"{field}: invalid {kind} identifier.")
    if valid_id(spec.get("scene_id"), "scene") and valid_id(spec.get("shot_id"), "shot") and not spec["shot_id"].startswith(spec["scene_id"] + "-"):
        errors.append("shot_id: must belong to scene_id.")
    shot_type = spec.get("shot_type")
    if "shot_type" in spec and (not isinstance(shot_type, str) or shot_type not in SHOT_TYPES): errors.append("shot_type: must be SINGLE-SHOT, MULTI-SHOT, or EXTENSION.")
    for field in ("environment", "action", "camera", "lighting", "audio", "continuity"):
        if field in spec and not nonempty_text(spec[field]): errors.append(f"{field}: required nonempty approved text.")
    for field in ("visual_style", "initial_state", "physical_interaction"):
        if field in spec and not nonempty_text(spec[field]): errors.append(f"{field}: if supplied, must be nonempty text.")
    duration = spec.get("duration")
    if "duration" in spec and (isinstance(duration, bool) or not isinstance(duration, (int, float)) or not math.isfinite(duration) or duration <= 0): errors.append("duration: required finite positive number of seconds.")
    if "status" in spec and spec["status"] != "READY": errors.append("status: submission specification must be READY.")
    generation_mode = spec.get("generation_mode")
    if generation_mode is not None and (not isinstance(generation_mode, str) or generation_mode not in GENERATION_MODES):
        errors.append("generation_mode: must be AUTO, TEXT_TO_VIDEO, IMAGE_TO_VIDEO, FIRST_FRAME, FIRST_LAST_FRAME, or EXTENSION.")
    if generation_mode == "EXTENSION" and shot_type != "EXTENSION":
        errors.append("generation_mode: EXTENSION is permitted only for EXTENSION shots.")
    if shot_type == "EXTENSION" and generation_mode not in (None, "AUTO", "EXTENSION"):
        errors.append("generation_mode: EXTENSION shots may use only AUTO or EXTENSION.")
    frame_conditioning = spec.get("frame_conditioning")
    if frame_conditioning is not None:
        if generation_mode not in {"FIRST_FRAME", "FIRST_LAST_FRAME"}:
            errors.append("frame_conditioning: permitted only with FIRST_FRAME or FIRST_LAST_FRAME generation_mode.")
        elif not isinstance(frame_conditioning, dict):
            errors.append("frame_conditioning: required object.")
        else:
            required_keys = {"first_frame"} if generation_mode == "FIRST_FRAME" else {"first_frame", "last_frame"}
            if set(frame_conditioning) != required_keys:
                errors.append(f"frame_conditioning: requires exactly {', '.join(sorted(required_keys))}.")
            for key in sorted(required_keys):
                frame = frame_conditioning.get(key)
                if not isinstance(frame, dict):
                    errors.append(f"frame_conditioning.{key}: required object.")
                    continue
                if set(frame) - {"asset_id", "description"}:
                    errors.append(f"frame_conditioning.{key}: supported fields are asset_id and description.")
                if not nonempty_text(frame.get("description")):
                    errors.append(f"frame_conditioning.{key}.description: required nonempty text.")
                if "asset_id" in frame and not valid_id(frame["asset_id"], "asset"):
                    errors.append(f"frame_conditioning.{key}.asset_id: invalid REF identifier.")
    elif generation_mode in {"FIRST_FRAME", "FIRST_LAST_FRAME"}:
        errors.append("frame_conditioning: required when generation_mode uses frame conditioning.")
    for field, kind in (("character_ids", "character"), ("voice_profile_ids", "voice")):
        if field not in spec: continue
        values=spec[field]
        if not isinstance(values,list): errors.append(f"{field}: required list."); continue
        seen=set()
        for index,value in enumerate(values):
            if not valid_id(value,kind): errors.append(f"{field}[{index}]: invalid {kind} identifier.")
            elif value in seen: errors.append(f"{field}[{index}]: duplicate {value}.")
            else: seen.add(value)
    if "dialogue" in spec:
        dialogue=spec["dialogue"]
        if not isinstance(dialogue,list): errors.append("dialogue: required list; use [] for no dialogue.")
        else:
            characters=spec.get("character_ids"); characters=characters if isinstance(characters,list) else []
            for index,line in enumerate(dialogue):
                prefix=f"dialogue[{index}]"
                if not isinstance(line,dict): errors.append(f"{prefix}: required object."); continue
                if set(line)!={"character_id","text"}: errors.append(f"{prefix}: requires exactly character_id and text."); continue
                if not valid_id(line["character_id"],"character"): errors.append(f"{prefix}.character_id: invalid identifier.")
                elif line["character_id"] not in characters: errors.append(f"{prefix}.character_id: missing from character_ids.")
                if not nonempty_text(line["text"]): errors.append(f"{prefix}.text: required nonempty dialogue.")
    if "constraints" in spec:
        constraints=spec["constraints"]
        if not isinstance(constraints,list) or any(not nonempty_text(item) for item in constraints): errors.append("constraints: must be a list of nonempty strings.")
    if "reference_assets" in spec: validate_assets(spec["reference_assets"],root,"reference_assets",errors)
    if "input_image" in spec and not valid_id(spec["input_image"],"asset"): errors.append("input_image: must be a REF identifier.")
    if shot_type == "EXTENSION":
        source=spec.get("continuation_source")
        if not isinstance(source,dict) or set(source)!={"take_id"}: errors.append("continuation_source: EXTENSION requires exactly {take_id}.")
        elif not valid_id(source["take_id"],"take"): errors.append("continuation_source.take_id: invalid take identifier.")
    elif "continuation_source" in spec: errors.append("continuation_source: permitted only for EXTENSION.")
    if errors: raise ValidationError(errors)
