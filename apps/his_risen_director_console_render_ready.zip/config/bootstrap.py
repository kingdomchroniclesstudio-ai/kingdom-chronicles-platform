from __future__ import annotations

from pathlib import Path

from adapters.mock import MockComfyUIAdapter
from comfyui.adapter import RealComfyUIAdapter
from config.runtime import load_runtime
from controller.service import Controller
from exports import ApprovedOutputExportManager, FileOutputRetriever
from profiles.registry import ProfileRegistry
from storage.sqlite_store import SQLiteStore
from workflows.registry import WorkflowRegistry


def build_controller(root: Path | None = None, backend: str | None = None) -> Controller:
    project_root = root.resolve() if root is not None else Path(__file__).resolve().parents[1]
    runtime = load_runtime(project_root)
    selected_backend = backend or str(runtime.get("backend", "mock"))
    if selected_backend not in {"mock", "comfyui"}:
        raise ValueError(f"unsupported controller backend: {selected_backend}")

    profiles = ProfileRegistry(
        project_root / "profiles" / "characters.json",
        project_root / "profiles" / "voices.json",
        project_root,
    )
    workflows = WorkflowRegistry(project_root / "workflows" / "presets.json")
    store = SQLiteStore(project_root / "storage" / "controller.sqlite3")

    retriever = FileOutputRetriever()
    export_manager = ApprovedOutputExportManager(
        project_root,
        store,
        retriever,
        project_root / str(runtime.get("workspace_root", "outputs/production")),
    )

    if selected_backend == "mock":
        adapter = MockComfyUIAdapter()
    else:
        comfy = runtime.get("comfyui", {})
        if not isinstance(comfy, dict):
            raise ValueError("runtime.comfyui must be an object")
        base_url = str(comfy.get("base_url", "")).strip()
        if not base_url:
            raise ValueError("runtime.comfyui.base_url is required for the comfyui backend")
        headers = comfy.get("headers") if isinstance(comfy.get("headers"), dict) else None
        adapter = RealComfyUIAdapter(
            project_root,
            base_url,
            timeout=float(comfy.get("request_timeout_seconds", 30)),
            job_timeout=float(comfy.get("job_timeout_seconds", 3600)),
            headers=headers,
        )

    return Controller(
        project_root,
        profiles,
        workflows,
        store,
        adapter,
        export_manager=export_manager,
        auto_export_approved=bool(runtime.get("auto_export_approved", False)),
    )
