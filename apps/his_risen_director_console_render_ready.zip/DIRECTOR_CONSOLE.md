# HIS RISEN FILMS — Mobile Director Console

This build adds a phone-friendly web console in front of the existing HIS RISEN Controller.

## What it does

- Mobile-first Director dashboard.
- PIN-gated login with an HttpOnly session cookie.
- Failed-login rate limiting.
- Shows controller/backend status.
- Shows film/take progress and Director-review queue.
- Approve/reject from the phone.
- Approval can trigger automatic approved-output export.
- Approved video preview is served only after the take is approved and the export is verified.
- Controller automatically polls active generations in the background.
- Works with the existing mock adapter now and the real ComfyUI adapter later.

## Important security rule

Do **not** deploy this publicly without HTTPS. Set `HRF_DIRECTOR_PIN` to a private 6–12 digit PIN. The PIN is read from the environment and is never stored in the source code.

For a production deployment, put this server behind a trusted HTTPS gateway/reverse proxy. The controller/ComfyUI service itself should not be exposed directly to the public internet.

The session cookie is HttpOnly, SameSite=Strict and Secure. Failed login attempts are rate-limited per source address. This is a practical first security layer, not a replacement for a full identity provider/WAF for a high-value production system.

## Run locally in mock mode

```bash
export HRF_DIRECTOR_PIN=your_private_pin
python director_console.py --host 127.0.0.1 --port 8080 --backend mock
```

Open `http://127.0.0.1:8080`.

## Deploy online later

The app is deployment-ready but the public URL is created by the hosting/DNS layer, not by the Python code itself. Example final address:

`https://director.hisrisenfilms.com`

To make that real, a hosting account and the `hisrisenfilms.com` domain/DNS must be controlled by the Director. Those account credentials should never be placed in this repository or sent through chat.

Recommended separation:

```text
Internet
  ↓ HTTPS
Director Console / Controller host
  ↓ private network or authenticated gateway
RunPod ComfyUI
  ↓
LTX-2.5 Fast
```

RunPod can be stopped without taking down the Director Console if the dashboard/controller is hosted separately.

## Current automation boundary

The controller can automatically poll active generations and automatically export an approved take. It **does not automatically approve creative output**. That remains a Director action.

The natural-language Director Command box is intentionally a placeholder in this first console build. It does not execute arbitrary text. A future AI-agent bridge can translate approved natural-language commands into explicit controller API operations.
