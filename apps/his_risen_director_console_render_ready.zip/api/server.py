from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import urlparse

from api.models import APIResponse, DecisionRequest, GenerateRequest
from models.specification import ValidationError


class ControllerHTTPServer:
    def __init__(self, controller: Any, host: str = "127.0.0.1", port: int = 8189):
        self.controller = controller
        self.host = host
        self.port = port
        controller_ref = controller

        class Handler(BaseHTTPRequestHandler):
            server_version = "HIS-RISEN-Controller/0.2"

            def _send_json(self, status: int, payload: dict[str, Any]) -> None:
                body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)

            def _read_json(self) -> Any:
                length = int(self.headers.get("Content-Length", "0"))
                raw = self.rfile.read(length) if length else b""
                if not raw:
                    return None
                return json.loads(raw.decode("utf-8"))

            def _handle(self, method: str) -> None:
                path = urlparse(self.path).path.rstrip("/") or "/"
                try:
                    if method == "GET" and path == "/health":
                        return self._send_json(200, APIResponse(ok=True, data={"service": "his-risen-controller", "status": "ok"}).to_dict())

                    if method == "POST" and path == "/shots/generate":
                        req = GenerateRequest.from_dict(self._read_json())
                        result = controller_ref.generate(req.specification)
                        return self._send_json(200, APIResponse(ok=True, data=result).to_dict())

                    parts = [p for p in path.split("/") if p]
                    if len(parts) == 2 and parts[0] == "takes" and method == "GET":
                        return self._send_json(200, APIResponse(ok=True, data=controller_ref.get_take(parts[1])).to_dict())
                    if len(parts) == 3 and parts[0] == "takes" and parts[2] == "progress" and method == "GET":
                        return self._send_json(200, APIResponse(ok=True, data=controller_ref.get_progress_events(parts[1])).to_dict())
                    if len(parts) == 3 and parts[0] == "takes" and parts[2] == "advance" and method == "POST":
                        return self._send_json(200, APIResponse(ok=True, data=controller_ref.advance(parts[1])).to_dict())
                    if len(parts) == 3 and parts[0] == "takes" and parts[2] == "approve" and method == "POST":
                        body = self._read_json()
                        req = DecisionRequest.from_dict(body)
                        if req.reason is not None:
                            raise ValueError("approval does not accept a reason")
                        return self._send_json(200, APIResponse(ok=True, data=controller_ref.director_approve(parts[1],auto_export=req.auto_export)).to_dict())
                    if len(parts) == 3 and parts[0] == "takes" and parts[2] == "reject" and method == "POST":
                        req = DecisionRequest.from_dict(self._read_json())
                        if req.reason is None:
                            raise ValueError("rejection requires reason")
                        return self._send_json(200, APIResponse(ok=True, data=controller_ref.director_reject(parts[1], req.reason)).to_dict())
                    if len(parts) == 3 and parts[0] == "takes" and parts[2] == "export" and method == "POST":
                        if self._read_json() not in (None, {}):
                            raise ValueError("export does not accept a request body")
                        return self._send_json(200, APIResponse(ok=True, data=controller_ref.export_approved(parts[1])).to_dict())
                    if len(parts) == 3 and parts[0] == "takes" and parts[2] == "exports" and method == "GET":
                        return self._send_json(200, APIResponse(ok=True, data=controller_ref.export_status(parts[1])).to_dict())
                    if len(parts) == 3 and parts[0] == "takes" and parts[2] == "regenerate" and method == "POST":
                        if self._read_json() not in (None, {}):
                            raise ValueError("regeneration does not accept a request body")
                        return self._send_json(200, APIResponse(ok=True, data=controller_ref.regenerate(parts[1])).to_dict())
                    if len(parts) == 2 and parts[0] == "films" and parts[1] and method == "GET":
                        return self._send_json(200, APIResponse(ok=True, data=controller_ref.film_readiness(parts[1])).to_dict())
                    if path == "/" and method == "GET":
                        return self._send_json(200, APIResponse(ok=True, data={"service": "HIS RISEN Controller", "docs": "/health"}).to_dict())
                    return self._send_json(404, APIResponse(ok=False, error="route not found").to_dict())
                except ValidationError as exc:
                    return self._send_json(422, APIResponse(ok=False, error="validation_error", details=list(exc.errors)).to_dict())
                except (LookupError, ValueError, KeyError) as exc:
                    return self._send_json(409, APIResponse(ok=False, error=str(exc)).to_dict())
                except json.JSONDecodeError as exc:
                    return self._send_json(400, APIResponse(ok=False, error=f"invalid JSON: {exc}").to_dict())
                except Exception as exc:
                    return self._send_json(500, APIResponse(ok=False, error=f"internal_error: {type(exc).__name__}: {exc}").to_dict())

            def do_GET(self) -> None:
                self._handle("GET")

            def do_POST(self) -> None:
                self._handle("POST")

            def log_message(self, fmt: str, *args: object) -> None:
                return

        self._server = ThreadingHTTPServer((host, port), Handler)

    @property
    def server_address(self) -> tuple[str, int]:
        return self._server.server_address

    def serve_forever(self) -> None:
        self._server.serve_forever()

    def shutdown(self) -> None:
        self._server.shutdown()
        self._server.server_close()
