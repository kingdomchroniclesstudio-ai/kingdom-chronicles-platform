from __future__ import annotations

import copy
import json
import time
import uuid
from pathlib import Path
from typing import Any

from adapters.base import GenerationAdapter, GenerationUpdate
from comfyui.errors import ComfyUIError, ComfyUIProtocolError
from comfyui.http_client import ComfyUIHTTPClient
from comfyui.output_discovery import discover_outputs
from comfyui.websocket_monitor import ComfyUIWebSocketMonitor, parse_progress_event
from workflows.loader import WorkflowLoader, WorkflowTemplateError


class RealComfyUIAdapter(GenerationAdapter):
    """Production adapter boundary for a real ComfyUI server.

    The controller remains backend-agnostic. Real workflow graphs and their explicit
    node mappings are loaded from project files and can be replaced without changing
    controller logic.
    """

    def __init__(self, root: Path, base_url: str, timeout: float = 30.0, job_timeout: float = 3600.0, headers: dict[str, str] | None = None):
        self.root = root.resolve()
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.job_timeout = job_timeout
        self.http = ComfyUIHTTPClient(self.base_url, timeout=timeout, headers=headers)
        self.monitor = ComfyUIWebSocketMonitor(self.base_url)
        self.loader = WorkflowLoader(self.root)
        self.jobs: dict[str, dict[str, Any]] = {}
        cfg = json.loads((self.root / "workflows" / "real_presets.json").read_text(encoding="utf-8"))
        self._real_presets = cfg

    def _client_id(self, client_request_id: str) -> str:
        return "his-risen-" + uuid.uuid5(uuid.NAMESPACE_URL, client_request_id).hex

    def _workflow_for(self, request: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
        preset_id = request["workflow"]["preset_id"]
        config = self._real_presets.get(preset_id)
        if not isinstance(config, dict):
            raise WorkflowTemplateError(f"no real workflow configuration for preset {preset_id}")
        if config.get("ready") is not True:
            raise WorkflowTemplateError(f"real workflow preset {preset_id} is not installed/approved yet; replace the contract fixture with the exported LTX workflow and set ready=true")
        workflow = self.loader.load(config["workflow_file"])
        mapping_path = self.root / config["mapping_file"]
        mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
        if not isinstance(mapping, dict):
            raise WorkflowTemplateError(f"mapping file must be an object: {mapping_path.name}")
        return workflow, mapping, config

    def _asset_by_id(self, request: dict[str, Any], asset_id: str) -> dict[str, Any]:
        for asset in request["profiles"]["reference_assets"]:
            if asset.get("asset_id") == asset_id:
                return asset
        for character in request["profiles"].get("characters", {}).values():
            for asset in character.get("reference_assets", []):
                if asset.get("asset_id") == asset_id:
                    return asset
        raise WorkflowTemplateError(f"reference asset not found in saved request: {asset_id}")

    def _prepare_assets(self, request: dict[str, Any]) -> dict[str, str]:
        uploaded: dict[str, str] = {}
        for asset in request["profiles"]["reference_assets"]:
            asset_id = asset["asset_id"]
            local_path = (self.root / asset["path"]).resolve()
            result = self.http.upload_file(local_path, subfolder=f"his_risen/{request['specification']['film_id']}", folder_type="input")
            uploaded[asset_id] = result["name"]
        return uploaded

    def _mapping_values(self, request: dict[str, Any], uploaded_assets: dict[str, str]) -> dict[str, Any]:
        spec = request["specification"]
        values: dict[str, Any] = {"prompt": request["prompt"], "duration": spec.get("duration"), "seed": spec.get("seed")}
        if spec.get("input_image"):
            values["input_image"] = uploaded_assets.get(spec["input_image"], spec["input_image"])
        continuation = request.get("continuation")
        if continuation:
            media = (continuation.get("output_metadata") or {}).get("media_files") or []
            if media and isinstance(media[0], dict):
                values["continuation_source"] = media[0].get("filename")
        return values

    def submit(self, request: dict[str, Any], client_request_id: str) -> str:
        workflow, mapping, config = self._workflow_for(request)
        uploaded = self._prepare_assets(request)
        values = self._mapping_values(request, uploaded)
        self.loader.validate_required_mappings(workflow, mapping, values)
        workflow = self.loader.apply_mapping(workflow, mapping, values)
        client_id = self._client_id(client_request_id)
        result = self.http.queue_prompt(workflow, client_id=client_id)
        prompt_id = result["prompt_id"]
        self.jobs[prompt_id] = {"client_request_id": client_request_id, "submitted_at": time.monotonic(), "workflow": workflow, "client_id": client_id, "preset_id": config.get("preset_id", request["workflow"]["preset_id"])}
        return prompt_id

    def _completed_from_history(self, prompt_id: str, history: dict[str, Any]) -> GenerationUpdate | None:
        record = history.get(prompt_id) if isinstance(history, dict) else None
        if not isinstance(record, dict):
            return None
        status = record.get("status", {}) if isinstance(record.get("status", {}), dict) else {}
        messages = status.get("messages", [])
        if status.get("status_str") in {"error", "failed"} or any(isinstance(item, list) and item and item[0] == "execution_error" for item in messages):
            return GenerationUpdate(state="FAILED", progress=0, error="ComfyUI reported execution failure.")
        outputs = discover_outputs(record, view_url_factory=lambda fn, sub, typ: self.http.view_url(fn, sub, typ))
        if outputs and (status.get("completed") is True or status.get("status_str") in {"success", "completed"} or "status" not in record):
            return GenerationUpdate(state="COMPLETED", progress=100, output_metadata={"prompt_id": prompt_id, "is_mock": False, "media_generated": True, "media_files": outputs, "history": record})
        return None

    def poll(self, job_id: str) -> GenerationUpdate:
        job = self.jobs.get(job_id)
        if job is None:
            history = self.http.history(job_id)
            result = self._completed_from_history(job_id, history)
            if result:
                return result
            raise ComfyUIError(f"unknown or unavailable ComfyUI prompt_id: {job_id}")

        elapsed = time.monotonic() - job["submitted_at"]
        if elapsed >= self.job_timeout:
            return GenerationUpdate(state="FAILED", progress=0, error=f"ComfyUI job timed out after {self.job_timeout:g} seconds")

        history = self.http.history(job_id)
        result = self._completed_from_history(job_id, history)
        if result:
            return result

        # WebSocket is used as an auxiliary progress signal. A short timeout or a
        # missing websocket-client dependency does not turn a healthy running job
        # into a false failure; the next poll will consult /history again.
        try:
            events = self.monitor.wait_for_completion(job_id, timeout=min(2.0, max(0.25, self.job_timeout - elapsed)))
            for event in reversed(events):
                parsed = parse_progress_event(event, job_id)
                if parsed and parsed[0] == "FAILED":
                    return GenerationUpdate(state="FAILED", progress=0, error="ComfyUI WebSocket execution_error.")
        except Exception:
            pass

        history = self.http.history(job_id)
        result = self._completed_from_history(job_id, history)
        if result:
            return result
        return GenerationUpdate(state="RUNNING", progress=50)
