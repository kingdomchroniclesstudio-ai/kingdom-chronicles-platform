from __future__ import annotations

import argparse
import hashlib
import json
import os
import secrets
import threading
import time
import uuid
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

from config.bootstrap import build_controller


APP_NAME = "HIS RISEN Director Console"
COOKIE_NAME = "hrf_director_session"
SESSION_TTL = 12 * 60 * 60
MAX_FAILED_PER_WINDOW = 5
FAIL_WINDOW = 5 * 60


class SessionStore:
    def __init__(self) -> None:
        self._sessions: dict[str, float] = {}
        self._lock = threading.RLock()

    def create(self) -> str:
        token = secrets.token_urlsafe(32)
        with self._lock:
            self._sessions[token] = time.time() + SESSION_TTL
        return token

    def valid(self, token: str | None) -> bool:
        if not token:
            return False
        now = time.time()
        with self._lock:
            expiry = self._sessions.get(token)
            if expiry is None:
                return False
            if expiry < now:
                self._sessions.pop(token, None)
                return False
            return True

    def revoke(self, token: str | None) -> None:
        if token:
            with self._lock:
                self._sessions.pop(token, None)


class LoginLimiter:
    def __init__(self) -> None:
        self._failed: dict[str, list[float]] = {}
        self._lock = threading.RLock()

    def allowed(self, key: str) -> bool:
        now = time.time()
        with self._lock:
            entries = [t for t in self._failed.get(key, []) if t > now - FAIL_WINDOW]
            self._failed[key] = entries
            return len(entries) < MAX_FAILED_PER_WINDOW

    def failure(self, key: str) -> None:
        with self._lock:
            self._failed.setdefault(key, []).append(time.time())


class DirectorConsole:
    def __init__(self, controller: Any, pin: str, root: Path) -> None:
        if not pin or not pin.isdigit() or len(pin) < 6 or len(pin) > 12:
            raise ValueError("HRF_DIRECTOR_PIN must be a 6-12 digit PIN.")
        self.controller = controller
        self.pin = pin
        self.root = root.resolve()
        self.sessions = SessionStore()
        self.limiter = LoginLimiter()
        self._autopoll_stop = threading.Event()
        self._autopoll_thread = threading.Thread(target=self._poll_loop, daemon=True)
        self._autopoll_thread.start()

    def _poll_loop(self) -> None:
        while not self._autopoll_stop.wait(2.5):
            try:
                takes = self._active_takes()
                for take in takes:
                    try:
                        self.controller.advance(take["take_id"])
                    except Exception:
                        # A completed/failed state or transient backend condition is
                        # harmless here; the dashboard will expose the persisted state.
                        pass
            except Exception:
                pass

    def stop(self) -> None:
        self._autopoll_stop.set()

    def _active_takes(self) -> list[dict[str, Any]]:
        conn = self.controller.store.connection
        with self.controller.store._lock:
            rows = conn.execute(
                "SELECT take_id FROM takes WHERE status IN ('SUBMITTED','RUNNING') ORDER BY created_at"
            ).fetchall()
        return [self.controller.get_take(row["take_id"]) for row in rows]

    def list_films(self) -> list[dict[str, Any]]:
        conn = self.controller.store.connection
        with self.controller.store._lock:
            rows = conn.execute("SELECT film_id FROM films ORDER BY film_id").fetchall()
        return [{"film_id": row["film_id"]} for row in rows]

    def list_takes(self, film_id: str | None = None) -> list[dict[str, Any]]:
        conn = self.controller.store.connection
        with self.controller.store._lock:
            if film_id:
                rows = conn.execute(
                    "SELECT take_id FROM takes WHERE film_id=? ORDER BY scene_id,shot_id,take_number",
                    (film_id,),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT take_id FROM takes ORDER BY updated_at DESC LIMIT 200"
                ).fetchall()
        return [self.controller.get_take(row["take_id"]) for row in rows]

    def status(self) -> dict[str, Any]:
        adapter = type(self.controller.adapter).__name__
        return {
            "service": APP_NAME,
            "controller": "online",
            "backend_adapter": adapter,
            "real_generation_enabled": adapter != "MockComfyUIAdapter",
            "approval_required": True,
            "auto_export_approved": bool(self.controller.auto_export_approved),
            "export_manager": self.controller.export_manager is not None,
            "server_time": time.time(),
        }

    def take_video_path(self, take_id: str) -> Path | None:
        take = self.controller.get_take(take_id)
        if take.get("status") != "APPROVED":
            return None
        records = self.controller.export_status(take_id)
        for record in records:
            if record.get("status") != "VERIFIED" or record.get("kind") != "video":
                continue
            raw = record.get("path")
            if not raw:
                continue
            path = Path(raw).resolve()
            workspace = self.controller.export_manager.workspace_root.resolve()
            try:
                path.relative_to(workspace)
            except ValueError:
                continue
            if path.is_file():
                return path
        return None


INDEX_HTML = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#090b10">
<title>HIS RISEN Director Console</title>
<style>
:root{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#eef1f5;background:#090b10}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at top,#171c26,#090b10 45%);min-height:100vh}
.wrap{max-width:1100px;margin:auto;padding:18px 14px 50px}.top{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:18px}
.brand{font-weight:800;letter-spacing:.08em}.muted{color:#9aa4b2}.card{background:rgba(20,24,32,.92);border:1px solid #29313d;border-radius:18px;padding:16px;box-shadow:0 12px 40px rgba(0,0,0,.24);margin-bottom:14px}
.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}.stat{padding:14px;border-radius:14px;background:#10151d;border:1px solid #252d38}.stat b{display:block;font-size:24px;margin-top:4px}
.row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.grow{flex:1}.pill{display:inline-flex;padding:5px 9px;border-radius:999px;background:#202735;font-size:12px}.ok{background:#123820;color:#9df3b0}.warn{background:#3a2c0e;color:#ffd98a}.bad{background:#3d1717;color:#ffb0b0}
button,input,textarea,select{font:inherit}button{border:0;border-radius:12px;padding:11px 14px;font-weight:700;cursor:pointer;background:#e9edf2;color:#0b0e13}button.secondary{background:#242c38;color:#eef1f5}button.danger{background:#5a1f25;color:#ffd7da}button.success{background:#145b2a;color:#c7ffd2}
input,textarea,select{width:100%;background:#0c1118;border:1px solid #303947;color:#eef1f5;border-radius:12px;padding:11px;outline:none}textarea{min-height:80px;resize:vertical}.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
.progress{height:10px;background:#252c37;border-radius:99px;overflow:hidden;margin:10px 0}.bar{height:100%;background:#e9edf2;width:0;transition:width .4s}.shot-title{font-size:22px;font-weight:800}.video{width:100%;max-height:560px;background:#000;border-radius:14px;margin-top:12px}
.login{max-width:420px;margin:12vh auto}.pin{font-size:25px;letter-spacing:.25em;text-align:center}.hidden{display:none!important}.small{font-size:13px}.list{display:grid;gap:8px}.item{padding:12px;border:1px solid #29313d;border-radius:13px;background:#10151d}.notice{position:fixed;right:14px;bottom:14px;max-width:340px;background:#eef1f5;color:#0b0e13;padding:12px 14px;border-radius:12px;box-shadow:0 10px 30px #0008;display:none}
@media(max-width:700px){.grid{grid-template-columns:repeat(2,1fr)}.wrap{padding:12px 10px 40px}.top{align-items:flex-start}.shot-title{font-size:19px}}
</style>
</head>
<body>
<div id="login" class="wrap login">
  <div class="card">
    <div class="brand">HIS RISEN FILMS</div><h1>Director Console</h1>
    <p class="muted">Secure access to your production controller.</p>
    <input id="pin" class="pin" type="password" inputmode="numeric" maxlength="12" placeholder="PIN">
    <div class="actions"><button class="grow" onclick="login()">ENTER CONSOLE</button></div>
    <p id="loginMsg" class="small muted"></p>
  </div>
</div>
<div id="app" class="wrap hidden">
  <div class="top"><div><div class="brand">HIS RISEN FILMS</div><div class="muted small">Director Console</div></div><div class="row"><span id="backend" class="pill">Checking…</span><button class="secondary" onclick="logout()">Lock</button></div></div>
  <div class="card"><div class="row"><div class="grow"><h2 id="filmName">Production</h2><div id="filmInfo" class="muted">No production selected.</div></div><button class="secondary" onclick="refreshAll()">Refresh</button></div></div>
  <div class="grid">
    <div class="stat"><span class="muted small">Total takes</span><b id="total">0</b></div>
    <div class="stat"><span class="muted small">Approved</span><b id="approved">0</b></div>
    <div class="stat"><span class="muted small">Waiting review</span><b id="review">0</b></div>
    <div class="stat"><span class="muted small">Rejected</span><b id="rejected">0</b></div>
  </div>
  <div id="current" class="card"><div class="muted">No shot awaiting Director review.</div></div>
  <div class="card"><h3>Director Command</h3><p class="muted small">Use this box for future natural-language controller commands. Creative approval remains yours.</p><textarea id="command" placeholder="Example: Pause production after the current shot."></textarea><div class="actions"><button onclick="sendCommand()">SEND COMMAND</button></div><div id="commandResult" class="small muted"></div></div>
  <div class="card"><h3>Recent production</h3><div id="takes" class="list"><div class="muted">Loading…</div></div></div>
</div>
<div id="notice" class="notice"></div>
<script>
let currentFilm=null,lastStatuses=new Map(),pollHandle=null;
const $=id=>document.getElementById(id);
function note(t){$('notice').textContent=t;$('notice').style.display='block';setTimeout(()=>$('notice').style.display='none',3500)}
async function api(path,opts={}){const r=await fetch('/api'+path,{...opts,headers:{'Content-Type':'application/json',...(opts.headers||{})}});if(r.status===401){showLogin();throw Error('Unauthorized')}const j=await r.json();if(!r.ok)throw Error(j.error||j.details?.join(', ')||'Request failed');return j.data}
async function login(){const pin=$('pin').value;try{await api('/login',{method:'POST',body:JSON.stringify({pin})});$('pin').value='';showApp();await refreshAll()}catch(e){$('loginMsg').textContent='Access denied or temporarily locked.'}}
function showLogin(){clearInterval(pollHandle);$('app').classList.add('hidden');$('login').classList.remove('hidden')}
function showApp(){$('login').classList.add('hidden');$('app').classList.remove('hidden');if(!pollHandle)pollHandle=setInterval(refreshAll,4000)}
async function logout(){await fetch('/api/logout',{method:'POST'});showLogin()}
async function refreshAll(){try{const s=await api('/status');$('backend').textContent=s.real_generation_enabled?'🟢 LTX/ComfyUI':'🟡 MOCK MODE';$('backend').className='pill '+(s.real_generation_enabled?'ok':'warn');const films=await api('/films');if(!currentFilm&&films.length)currentFilm=films[0].film_id;if(currentFilm){$('filmName').textContent=currentFilm;const ready=await api('/films/'+encodeURIComponent(currentFilm)+'/readiness');$('total').textContent=ready.takes_total||0;$('approved').textContent=ready.approved||0;$('review').textContent=ready.pending_or_review||0;$('rejected').textContent=ready.rejected||0;$('filmInfo').textContent=ready.ready_for_editing?'Ready for editing':'Production in progress';const takes=await api('/takes?film_id='+encodeURIComponent(currentFilm));renderTakes(takes);const review=takes.find(t=>t.status==='COMPLETED');renderCurrent(review)}}catch(e){if(e.message!=='Unauthorized')$('filmInfo').textContent=e.message}}
function renderCurrent(t){if(!t){$('current').innerHTML='<div class="muted">No completed shot awaiting Director review.</div>';return}const snap=t.snapshot?.specification||{};const mode=snap.generation_mode||'AUTO';const flf=mode==='FIRST_LAST_FRAME';$('current').innerHTML=`<div class="shot-title">${esc(t.shot_id||'Shot')}</div><div class="row"><span class="pill warn">READY FOR REVIEW</span><span class="pill">${esc(mode)}</span><span class="muted">Take ${esc(String(t.take_number||''))} · ${esc(String(snap.resolution||'resolution pending'))}</span></div><div class="progress"><div class="bar" style="width:${t.progress||100}%"></div></div><div class="muted small">${esc(snap.action||'Review generated shot.')}</div>${flf?'<div class="muted small">First/Last Frame is a specialist mode. Frame assets are used only when explicitly authorized in the shot specification.</div>':''}<video class="video" controls preload="metadata" src="/api/takes/${encodeURIComponent(t.take_id)}/preview"></video><div class="actions"><button class="success" onclick="approve('${esc(t.take_id)}')">✓ APPROVE</button><button class="danger" onclick="reject('${esc(t.take_id)}')">✕ REJECT</button></div>`}
function renderTakes(takes){$('takes').innerHTML=takes.slice(-40).reverse().map(t=>`<div class="item"><div class="row"><div class="grow"><b>${esc(t.shot_id)}</b> <span class="muted">Take ${t.take_number}</span></div><span class="pill ${t.status==='APPROVED'?'ok':t.status==='REJECTED'||t.status==='FAILED'?'bad':t.status==='COMPLETED'?'warn':''}">${esc(t.status)}</span></div><div class="progress"><div class="bar" style="width:${t.progress||0}%"></div></div><div class="muted small">${t.progress||0}% · ${esc(t.updated_at||'')}</div></div>`).join('')||'<div class="muted">No takes yet.</div>'}
async function approve(id){try{await api('/takes/'+encodeURIComponent(id)+'/approve',{method:'POST',body:JSON.stringify({auto_export:true})});note('Approved. Export started/completed.');await refreshAll()}catch(e){note(e.message)}}
async function reject(id){const reason=prompt('Why are you rejecting this take?');if(!reason)return;try{await api('/takes/'+encodeURIComponent(id)+'/reject',{method:'POST',body:JSON.stringify({reason})});note('Rejected and recorded.');await refreshAll()}catch(e){note(e.message)}}
async function sendCommand(){const c=$('command').value.trim();if(!c)return; $('commandResult').textContent='Command interface is reserved for the AI-agent bridge; no action was executed.';$('command').value=''}
function esc(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
refreshAll();
</script>
</body></html>'''


class Handler(BaseHTTPRequestHandler):
    server_version = "HIS-RISEN-Director-Console/0.1"

    def _console(self) -> DirectorConsole:
        return self.server.console  # type: ignore[attr-defined]

    def _cookie_token(self) -> str | None:
        raw = self.headers.get("Cookie", "")
        for part in raw.split(";"):
            k, _, v = part.strip().partition("=")
            if k == COOKIE_NAME:
                return v
        return None

    def _authed(self) -> bool:
        return self._console().sessions.valid(self._cookie_token())

    def _json(self, status: int, payload: Any) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> Any:
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length) if length else b""
        return json.loads(raw.decode("utf-8")) if raw else {}

    def _require_auth(self) -> bool:
        if self._authed():
            return True
        self._json(HTTPStatus.UNAUTHORIZED, {"ok": False, "error": "authentication_required"})
        return False

    def do_GET(self) -> None:
        path = urlparse(self.path).path.rstrip("/") or "/"
        try:
            if path == "/":
                body = INDEX_HTML.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers(); self.wfile.write(body); return
            if path == "/health":
                self._json(200, {"ok": True, "service": APP_NAME}); return
            if not path.startswith("/api/"):
                self._json(404, {"ok": False, "error": "not_found"}); return
            if path == "/api/status":
                if not self._require_auth(): return
                self._json(200, {"ok": True, "data": self._console().status()}); return
            if not self._require_auth(): return
            if path == "/api/films":
                self._json(200, {"ok": True, "data": self._console().list_films()}); return
            if path == "/api/takes":
                q = parse_qs(urlparse(self.path).query)
                film_id = q.get("film_id", [None])[0]
                self._json(200, {"ok": True, "data": self._console().list_takes(film_id)}); return
            if path.startswith("/api/films/") and path.endswith("/readiness"):
                film_id = path.split("/")[3]
                self._json(200, {"ok": True, "data": self._console().controller.film_readiness(film_id)}); return
            if path.startswith("/api/takes/") and path.endswith("/preview"):
                take_id = path.split("/")[3]
                video = self._console().take_video_path(take_id)
                if not video:
                    self._json(404, {"ok": False, "error": "approved_video_not_available"}); return
                self._send_file(video, "video/mp4"); return
            self._json(404, {"ok": False, "error": "not_found"})
        except Exception as exc:
            self._json(500, {"ok": False, "error": f"{type(exc).__name__}: {exc}"})

    def do_POST(self) -> None:
        path = urlparse(self.path).path.rstrip("/") or "/"
        try:
            if path == "/api/login":
                key = self.client_address[0]
                if not self._console().limiter.allowed(key):
                    self._json(429, {"ok": False, "error": "too_many_attempts"}); return
                body = self._read_json(); presented = str(body.get("pin", ""))
                if not secrets.compare_digest(presented, self._console().pin):
                    self._console().limiter.failure(key)
                    self._json(401, {"ok": False, "error": "invalid_pin"}); return
                token = self._console().sessions.create()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                secure = "; Secure" if self.headers.get("X-Forwarded-Proto", "http").lower() == "https" else ""
                self.send_header("Set-Cookie", f"{COOKIE_NAME}={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_TTL}{secure}")
                self.send_header("Content-Length", "11")
                self.end_headers(); self.wfile.write(b'{"ok":true}'); return
            if path == "/api/logout":
                self._console().sessions.revoke(self._cookie_token())
                self.send_response(200)
                secure = "; Secure" if self.headers.get("X-Forwarded-Proto", "http").lower() == "https" else ""
                self.send_header("Set-Cookie", f"{COOKIE_NAME}=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict{secure}")
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", "11")
                self.end_headers(); self.wfile.write(b'{"ok":true}'); return
            if not self._require_auth(): return
            body = self._read_json()
            if path.startswith("/api/takes/") and path.endswith("/approve"):
                take_id = path.split("/")[3]
                result = self._console().controller.director_approve(take_id, auto_export=bool(body.get("auto_export", True)))
                self._json(200, {"ok": True, "data": result}); return
            if path.startswith("/api/takes/") and path.endswith("/reject"):
                take_id = path.split("/")[3]
                result = self._console().controller.director_reject(take_id, str(body.get("reason", "")).strip())
                self._json(200, {"ok": True, "data": result}); return
            if path.startswith("/api/takes/") and path.endswith("/regenerate"):
                take_id = path.split("/")[3]
                result = self._console().controller.regenerate(take_id)
                self._json(200, {"ok": True, "data": result}); return
            self._json(404, {"ok": False, "error": "not_found"})
        except Exception as exc:
            self._json(409, {"ok": False, "error": f"{type(exc).__name__}: {exc}"})

    def _send_file(self, path: Path, content_type: str) -> None:
        size = path.stat().st_size
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(size))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Cache-Control", "private, max-age=60")
        self.end_headers()
        with path.open("rb") as f:
            while chunk := f.read(1024 * 1024):
                self.wfile.write(chunk)

    def log_message(self, fmt: str, *args: object) -> None:
        return


def main() -> None:
    parser = argparse.ArgumentParser(description=APP_NAME)
    parser.add_argument("--host", default=os.environ.get("HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "8080")))
    parser.add_argument("--backend", choices=["mock", "comfyui"], default=None)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    pin = os.environ.get("HRF_DIRECTOR_PIN", "").strip()
    controller = build_controller(root, backend=args.backend)
    console = DirectorConsole(controller, pin, root)
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    server.console = console  # type: ignore[attr-defined]
    print(f"{APP_NAME} listening on http://{args.host}:{args.port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        console.stop(); controller.close(); server.server_close()


if __name__ == "__main__":
    main()
