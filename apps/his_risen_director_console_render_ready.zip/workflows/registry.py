from __future__ import annotations
import copy,json
from pathlib import Path
from typing import Any
from models.specification import ValidationError
PRESET_NAMES=frozenset({"L25-T2V-SINGLE","L25-I2V-SINGLE","L25-MULTI-TESTED","L25-CONTINUE-TESTED"})
class WorkflowRegistry:
    def __init__(self,path:Path):
        with path.open("r",encoding="utf-8") as handle: self.presets=json.load(handle)
        if not isinstance(self.presets,dict): raise ValidationError(["workflow registry: required object."])
        unexpected=self.presets.keys()-PRESET_NAMES
        if unexpected: raise ValidationError([f"workflow registry: unsupported preset {name}." for name in sorted(unexpected)])
    def require(self,preset_id:str)->dict[str,Any]:
        preset=self.presets.get(preset_id)
        if not isinstance(preset,dict): raise ValidationError([f"workflow registry: required preset {preset_id} is missing."])
        if preset.get("preset_id")!=preset_id: raise ValidationError([f"workflow registry: {preset_id} has inconsistent preset_id."])
        return copy.deepcopy(preset)
    def select(self,spec:dict[str,Any])->dict[str,Any]:
        shot_type=spec["shot_type"]
        if shot_type=="SINGLE-SHOT": name="L25-I2V-SINGLE" if "input_image" in spec else "L25-T2V-SINGLE"
        elif shot_type=="MULTI-SHOT": name="L25-MULTI-TESTED"
        elif shot_type=="EXTENSION": name="L25-CONTINUE-TESTED"
        else: raise ValidationError(["shot_type: unsupported production label."])
        return self.require(name)
