from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any


class WorkflowTemplateError(ValueError):
    pass


class WorkflowLoader:
    """Loads ComfyUI API-format workflow JSON and applies explicit node mappings."""

    def __init__(self, root: Path):
        self.root = root.resolve()

    def load(self, workflow_path: str | Path) -> dict[str, Any]:
        path = Path(workflow_path)
        if not path.is_absolute():
            path = self.root / path
        path = path.resolve()
        if not path.is_relative_to(self.root):
            raise WorkflowTemplateError("workflow path must stay inside project root")
        if not path.is_file():
            raise WorkflowTemplateError(f"workflow file does not exist: {path.relative_to(self.root)}")
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise WorkflowTemplateError(f"invalid workflow JSON: {path.name}: {exc}") from exc
        if not isinstance(data, dict) or not data:
            raise WorkflowTemplateError("workflow must be a nonempty API-format object")
        for node_id, node in data.items():
            if not isinstance(node_id, str) or not isinstance(node, dict) or not isinstance(node.get("class_type"), str) or not isinstance(node.get("inputs"), dict):
                raise WorkflowTemplateError(f"invalid API workflow node: {node_id}")
        return data

    def apply_mapping(self, workflow: dict[str, Any], mapping: dict[str, Any], values: dict[str, Any]) -> dict[str, Any]:
        result = copy.deepcopy(workflow)
        for logical_key, rule in mapping.items():
            if logical_key not in values or values[logical_key] is None:
                continue
            if not isinstance(rule, dict) or set(rule) - {"node_id", "input", "required", "coerce"}:
                raise WorkflowTemplateError(f"invalid mapping for {logical_key}")
            node_id = rule.get("node_id")
            input_name = rule.get("input")
            required = bool(rule.get("required", False))
            if not isinstance(node_id, str) or not isinstance(input_name, str):
                raise WorkflowTemplateError(f"mapping for {logical_key} requires node_id and input")
            node = result.get(node_id)
            if not isinstance(node, dict) or not isinstance(node.get("inputs"), dict):
                if required:
                    raise WorkflowTemplateError(f"mapped node {node_id} for {logical_key} is missing")
                continue
            if rule.get("coerce") == "string" and not isinstance(values[logical_key], str):
                value = str(values[logical_key])
            else:
                value = values[logical_key]
            node["inputs"][input_name] = copy.deepcopy(value)
        return result

    def validate_required_mappings(self, workflow: dict[str, Any], mapping: dict[str, Any], values: dict[str, Any]) -> None:
        for logical_key, rule in mapping.items():
            if not isinstance(rule, dict):
                raise WorkflowTemplateError(f"invalid mapping for {logical_key}")
            if rule.get("required") and values.get(logical_key) is not None:
                node_id = rule.get("node_id")
                input_name = rule.get("input")
                if node_id not in workflow:
                    raise WorkflowTemplateError(f"required mapped node {node_id} for {logical_key} is missing")
                if input_name not in workflow[node_id].get("inputs", {}):
                    raise WorkflowTemplateError(f"required mapped input {node_id}.{input_name} for {logical_key} is missing")
