# HIS RISEN Controller Interface

## Local REST API

Start the server with:

    python3 serve.py --port 8189

### Generate a shot

`POST /shots/generate`

Body:

```json
{"specification": {"...": "approved shot specification"}}
```

### Inspect a take

`GET /takes/{take_id}`

### Poll progress

`POST /takes/{take_id}/advance`

### Read progress history

`GET /takes/{take_id}/progress`

### Director review

`POST /takes/{take_id}/approve`

or

`POST /takes/{take_id}/reject`

with:

```json
{"reason": "Director's reason"}
```

### Regenerate

`POST /takes/{take_id}/regenerate`

The controller preserves the original snapshot and creates a new child take.

## CLI

The same core functions are available from `cli.py`:

    python3 cli.py generate config/test_shot.json
    python3 cli.py status TAKE_ID
    python3 cli.py progress TAKE_ID
    python3 cli.py advance TAKE_ID
    python3 cli.py approve TAKE_ID
    python3 cli.py reject TAKE_ID --reason "Director reason"
    python3 cli.py regenerate TAKE_ID
