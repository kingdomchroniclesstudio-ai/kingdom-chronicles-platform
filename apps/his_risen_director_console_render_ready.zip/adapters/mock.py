from __future__ import annotations
from typing import Any
from adapters.base import GenerationAdapter,GenerationUpdate
from mock_comfyui.engine import MockComfyUI
class MockComfyUIAdapter(GenerationAdapter):
    def __init__(self): self._engine=MockComfyUI()
    def submit(self,request:dict[str,Any],client_request_id:str)->str: return self._engine.submit(request,client_request_id)
    def poll(self,job_id:str)->GenerationUpdate: return self._engine.poll(job_id)
